# 按原版 T3 移动端翻译原生界面

2026-11-16。用户否定首轮自创三页导航和大卡片后，按本机上游 `apps/mobile` 重新实现。首轮 `evidence/ui-refresh/` 为旧方案记录，不代表当前界面。阶段三专项仍进行中，M2 未完成。

## 原版到 ArkUI 的对应

| 原版源码（`/tmp/t3code-harmony-upstream/apps/mobile/`） | 当前原生实现 |
| --- | --- |
| `features/home/HomeScreen.tsx`、`features/threads/thread-list-v2-items.tsx` | 紧凑会话行、项目副标题、项目过滤；点击进入对话 |
| `features/layout/workspace/WorkspaceListHeader.android.tsx` | 单行 T3 Code 标题，标题进入环境管理，右侧新会话入口 |
| `features/threads/ThreadHeader.tsx` | 返回列表、会话标题/项目副标题、更多操作；系统返回优先关闭弹层 |
| `features/threads/ThreadComposer.tsx`、`components/ComposerToolbar.tsx` | 单一圆角输入区域、空文本紧凑单行、多行扩展；附件原生菜单、圆形发送控件 |
| `features/threads/PendingApprovalCard.tsx`、`SecretRequestCard.tsx` | 细边框请求卡片、正文和次要说明分层，安全字段保持密码模式 |
| `generated-uniwind-default-theme-variables.json` | 直接使用原版默认深浅色的 screen、foreground、muted、user-bubble、border、prominent-action；输入区域取原版不透明底色 |

不再使用“会话 / 对话 / 连接”选项卡、蓝色大按钮、重复角色标题及首页宣传大卡片。助手正文无额外卡片，用户消息靠右使用原版灰底；代码块提供轻量复制入口。图标为深浅色线形 SVG，ArkUI 原生渲染。

## 保留的能力与适配边界

连接/安全续用/断开/删除、项目/模型选择、新建/打开会话、完整历史与流式回复、工具输出、代码复制、审批/普通回答/敏感输入、停止、附件、未知提交核对均保留。发送回包保护新草稿的修复保留。

环境管理、新会话选择和会话操作用 ArkUI `bindSheet`；附件用 `bindMenu`。新会话仍先选择项目/模型再创建，沿用现有服务流程；没有移植上游完整草稿任务创建器、会话内模型切换或多环境能力。停止任务在会话更多操作中，不根据不完整的运行状态猜测停止/发送按钮切换。未实现功能没有放置空入口。

## 本轮验证

- `./scripts/build.sh`：签名构建通过；没有修改协议、依赖、签名配置或安全存储。
- `node --experimental-strip-types --test tests/*.test.mjs`：47 项通过，包括新草稿保护、失败保留草稿、深浅色正文对比度和系统返回顺序。
- 授权 Mate 60 Pro / ALN-AL80：用临时离线样例实际检查列表、进入对话、单行输入栏、线形图标、新会话原生弹层。修复真机发现的 SVG 填充和弹层内容垂直居中问题。
- 样例仅用于视觉检查，没有连接服务器或提交业务请求。样例代码已移除，最终重新构建、覆盖安装并启动正式包。

真机样例截图：[列表](evidence/ui-translation/list-sample.png)、[对话](evidence/ui-translation/chat-sample.png)、[新会话弹层](evidence/ui-translation/new-session-sample.png)。这些是设备上的原生界面，不是 WebView 或网页预览。

## 未验收

本轮未复验在线发送/审批/附件闭环。新版键盘弹出、深色真机切换、最大字体、屏幕朗读和快速流式/大历史性能未完成专项；不将协议测试或离线样例计作这些验收结果。

无 Git 仓库；上一版页面和请求卡片备份在 `/tmp/t3-harmony-ui-v1-backup/`，临时路径不是持久备份。
