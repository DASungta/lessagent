import { util } from '@kit.ArkTS';
import { T3Client } from './T3Client';
import { SessionStore } from '../storage/SessionStore';
import { EnvironmentStore, ProtectedEnvironmentAssets } from '../storage/EnvironmentStore';
import { EnvironmentDirectory, EnvironmentEntry, EnvironmentAssets, RecoveryReference, environmentDirectory, migrateLegacy, savedSession } from '../protocol/Environment';
import { RecoveryState, RecoveryStorage, SessionStorage, recoveryState, SavedSession } from '../protocol/Core';
import { pairingTarget } from '../protocol/Pairing';

class ScopedRecovery implements RecoveryStorage {
  private registry: EnvironmentRegistry;
  private localId: string;
  constructor(registry: EnvironmentRegistry, localId: string) { this.registry = registry; this.localId = localId; }
  async load(): Promise<RecoveryState | undefined> {
    const entry = this.registry.entry(this.localId);
    const ref = entry.recovery[0];
    return ref ? this.registry.assets.recovery(ref.alias).load() : undefined;
  }
  async save(value: RecoveryState): Promise<void> { await this.registry.saveRecovery(this.localId, value); }
  async clear(): Promise<void> { throw new Error('恢复记录仅能随已核对的环境移除'); }
}

export class EnvironmentRegistry {
  directory: EnvironmentDirectory = { schemaVersion: 2, generation: 0, selectedLocalId: '', entries: [] };
  clients: Map<string, T3Client> = new Map();
  assets: EnvironmentAssets;
  private legacySession: SessionStorage;
  private legacyRecovery: RecoveryStorage;
  onUpdate: () => void = () => {};
  private store: EnvironmentStore;
  private writes: Promise<void> = Promise.resolve();
  constructor(filesDir: string, assets: EnvironmentAssets = new ProtectedEnvironmentAssets(),
    legacySession: SessionStorage = new SessionStore(),
    legacyRecovery: RecoveryStorage = new SessionStore<RecoveryState>('t3-harmony-recovery-v1')) {
    this.store = new EnvironmentStore(filesDir); this.assets = assets;
    this.legacySession = legacySession; this.legacyRecovery = legacyRecovery;
  }
  private write(action: () => Promise<void>): Promise<void> {
    const result = this.writes.then(action);
    this.writes = result.catch(() => {});
    return result;
  }
  private notify(): void {
    // UI failures must never turn a committed directory into a credential rollback.
    try { this.onUpdate(); } catch (_) {}
  }
  private copy(): EnvironmentDirectory { return environmentDirectory(JSON.parse(JSON.stringify(this.directory)) as Object); }
  private async commit(next: EnvironmentDirectory): Promise<void> {
    next.generation = this.directory.generation + 1;
    await this.store.save(next);
    this.directory = next;
    this.notify();
  }
  entry(localId: string): EnvironmentEntry {
    const entry = this.directory.entries.find((e: EnvironmentEntry) => e.localId === localId);
    if (!entry || entry.deleting) throw new Error('环境不存在或正在移除');
    return entry;
  }
  async initialize(): Promise<void> {
    this.directory = await migrateLegacy(this.store, this.assets, this.legacySession, this.legacyRecovery);
    for (const entry of this.directory.entries.slice()) {
      if (entry.deleting) await this.finishRemoval(entry.localId);
      else this.bind(entry);
    }
  }
  private bind(entry: EnvironmentEntry): T3Client {
    const client = new T3Client();
    client.expectedEnvironmentId = entry.environmentId;
    client.store = this.assets.session(entry.credentialRef);
    client.recoveryStore = new ScopedRecovery(this, entry.localId);
    client.onUpdate = () => this.notify();
    this.clients.set(entry.localId, client);
    return client;
  }
  async saveRecovery(localId: string, value: RecoveryState): Promise<void> {
    await this.write(async () => {
      const entry = this.entry(localId);
      const checked = recoveryState(value, entry.base, entry.environmentId);
      if (!checked.threadId) throw new Error('恢复会话标识无效');
      const ref = entry.recovery.find((r) => r.threadId === checked.threadId);
      const alias = ref?.alias || 't3-v2-' + localId + '-recovery-' + util.generateRandomUUID();
      await this.assets.recovery(alias).save(checked);
      const next = this.copy();
      const target = next.entries.find((e: EnvironmentEntry) => e.localId === localId) as EnvironmentEntry;
      const reference: RecoveryReference = { threadId: checked.threadId, alias };
      target.recovery = [reference].concat(target.recovery.filter((r) => r.threadId !== checked.threadId));
      await this.commit(next);
    });
  }
  async add(input: string, code: string): Promise<string> {
    let added = '';
    await this.write(async () => {
      const target = pairingTarget(input, code);
      const localId = util.generateRandomUUID();
      const client = new T3Client();
      const credentialRef = 't3-v2-' + localId + '-session';
      const store = this.assets.session(credentialRef);
      client.store = store;
      client.validateIdentity = (environmentId: string) => {
        if (this.directory.entries.some((e: EnvironmentEntry) => e.environmentId === environmentId)) {
          throw new Error('该环境已添加，请在已有环境中重试或更新配对');
        }
      };
      try {
        await client.connect(target.base, target.code);
        if (!client.ready) throw new Error(client.status);
        const saved = savedSession(await store.load() as SavedSession);
        const entry: EnvironmentEntry = { localId, environmentId: saved.environmentId, base: saved.base,
          label: client.server, enabled: true, kind: 'bearer', credentialRef, recovery: [] };
        const next = this.copy(); next.entries.push(entry); next.selectedLocalId = localId;
        await this.commit(next);
        client.validateIdentity = () => {};
        client.expectedEnvironmentId = entry.environmentId;
        client.recoveryStore = new ScopedRecovery(this, localId);
        client.onUpdate = () => this.notify();
        this.clients.set(localId, client);
        added = localId;
      } catch (error) {
        client.disconnect(); await store.clear(); throw error as Error;
      }
    });
    this.notify();
    return added;
  }
  async select(localId: string): Promise<void> {
    await this.write(async () => {
      this.entry(localId);
      const next = this.copy(); next.selectedLocalId = localId; await this.commit(next);
    });
  }
  async setEnabled(localId: string, enabled: boolean): Promise<void> {
    await this.write(async () => {
      this.entry(localId);
      const next = this.copy();
      const entry = next.entries.find((e: EnvironmentEntry) => e.localId === localId) as EnvironmentEntry;
      entry.enabled = enabled; await this.commit(next);
      if (!enabled) this.clients.get(localId)?.disconnect('环境已停用，服务端任务继续');
    });
    if (enabled) await this.reconnect(localId);
  }
  async reconnect(localId: string, code: string = ''): Promise<void> {
    const entry = this.entry(localId);
    if (!entry.enabled) throw new Error('请先启用环境');
    const client = this.clients.get(localId);
    if (!client) throw new Error('环境尚未初始化');
    await client.connect(entry.base, code);
  }
  async remove(localId: string): Promise<void> {
    await this.write(async () => {
      const entry = this.entry(localId);
      const client = this.clients.get(localId);
      if (client?.mutationPending) throw new Error('请先核对正在提交或结果未知的请求');
      client?.disconnect('正在核对本机环境移除条件');
      // Read every thread, including a non-selected unknown submission, before any destructive step.
      for (const ref of entry.recovery) {
        const state = await this.assets.recovery(ref.alias).load();
        if (!state || recoveryState(state, entry.base, entry.environmentId).pendingId) {
          throw new Error('请先同步原会话并核对未知提交，未移除环境');
        }
      }
      this.clients.get(localId)?.disconnect('正在移除本机环境');
      const next = this.copy();
      const target = next.entries.find((e: EnvironmentEntry) => e.localId === localId) as EnvironmentEntry;
      target.enabled = false; target.deleting = true;
      await this.commit(next); await this.finishRemoval(localId);
    });
  }
  private async finishRemoval(localId: string): Promise<void> {
    const entry = this.directory.entries.find((e: EnvironmentEntry) => e.localId === localId);
    if (!entry?.deleting) throw new Error('环境未进入移除状态');
    for (const ref of entry.recovery) await this.assets.recovery(ref.alias).clear();
    await this.assets.session(entry.credentialRef).clear();
    if (localId === 'legacy-v1') {
      await this.legacySession.clear();
      await this.legacyRecovery.clear();
    }
    this.clients.delete(localId);
    const next = this.copy(); next.entries = next.entries.filter((e: EnvironmentEntry) => e.localId !== localId);
    if (next.selectedLocalId === localId) next.selectedLocalId = next.entries.find((e: EnvironmentEntry) => !e.deleting)?.localId || '';
    await this.commit(next); this.clients.delete(localId);
  }
  suspend(): void { this.clients.forEach((client: T3Client) => client.suspend()); }
  async resume(): Promise<void> {
    for (const entry of this.directory.entries) {
      if (entry.enabled && !entry.deleting) await this.clients.get(entry.localId)?.resume();
    }
  }
}
