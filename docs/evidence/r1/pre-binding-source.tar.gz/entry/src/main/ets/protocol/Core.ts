import { record, text, objects, sequence } from './Wire';

export interface Choice { id: string; label: string; projectId: string; }
export interface ModelChoice { instanceId: string; model: string; label: string; }
export function models(config: Object): ModelChoice[] {
  const result: ModelChoice[] = [];
  for (const value of objects(record(config).providers)) {
    const provider = record(value);
    if (provider.enabled === false || provider.installed === false) continue;
    for (const item of objects(provider.models)) {
      const model = record(item);
      result.push({ instanceId: text(provider.instanceId), model: text(model.slug),
        label: text(provider.instanceId) + ' / ' + text(model.name) });
    }
  }
  return result;
}
export class ShellState {
  projects: Choice[] = [];
  threads: Choice[] = [];
  cursor: number = -1;
  apply(value: Object): void {
    const item = record(value);
    if (item.kind === 'synchronized') return;
    if (item.kind === 'snapshot') {
      // Enrichment snapshots only refresh repository identities, which this picker does not display.
      if (item.resolvedRepositoryIdentityRoots !== undefined) {
        for (const root of objects(item.resolvedRepositoryIdentityRoots)) text(root);
        return;
      }
      const snapshot = record(item.snapshot);
      this.projects = objects(snapshot.projects).filter((p: Object) => !record(p).archivedAt)
        .map((p: Object) => this.choice(p, false));
      this.threads = objects(snapshot.threads).map((t: Object) => this.choice(t, true));
      this.cursor = sequence(snapshot.snapshotSequence);
      return;
    }
    const cursor = sequence(item.sequence);
    if (cursor <= this.cursor) return;
    if (item.kind === 'project.updated') {
      const next = this.choice(item.project, false);
      this.projects = this.projects.filter((p: Choice) => p.id !== next.id);
      if (!record(item.project).archivedAt) this.projects.push(next);
    } else if (item.kind === 'project.removed') {
      this.projects = this.projects.filter((p: Choice) => p.id !== text(item.projectId));
    } else if (item.kind === 'thread.updated') {
      const next = this.choice(item.thread, true);
      this.threads = this.threads.filter((t: Choice) => t.id !== next.id);
      if (item.location === 'active') this.threads.push(next);
    } else if (item.kind === 'thread.removed') {
      if (item.location === 'active') this.threads = this.threads.filter((t: Choice) => t.id !== text(item.threadId));
    } else throw new Error('未知项目流类型');
    this.cursor = cursor;
  }
  private choice(value: Object, thread: boolean): Choice {
    const item = record(value);
    return { id: text(item.id), label: text(item.title), projectId: thread ? text(item.projectId) : text(item.id) };
  }
}

export interface MarkdownBlock { kind: string; text: string; }
// shortcut: block Markdown only; add inline spans and tables when core flow is accepted.
export function markdown(source: string): MarkdownBlock[] {
  const blocks: MarkdownBlock[] = [];
  let code: string[] | undefined = undefined;
  for (const line of source.split('\n')) {
    if (/^\s*```/.test(line)) {
      if (code) { blocks.push({ kind: 'code', text: code.join('\n') }); code = undefined; }
      else code = [];
    } else if (code) code.push(line);
    else if (/^#{1,6} /.test(line)) blocks.push({ kind: 'heading', text: line.replace(/^#+ /, '') });
    else if (/^> /.test(line)) blocks.push({ kind: 'quote', text: line.slice(2) });
    else blocks.push({ kind: 'text', text: line });
  }
  if (code) blocks.push({ kind: 'code', text: code.join('\n') });
  return blocks;
}

export interface Question { id: string; label: string; options: string[]; values: string[]; multi: boolean; required: boolean; custom: boolean; }
export interface ActionCard { id: string; requestId: string; kind: string; label: string; questions: Question[]; enabled: boolean; }
export function cards(requests: Record<string, Object>[], items: Record<string, Object>[]): ActionCard[] {
  const result: ActionCard[] = [];
  for (const item of items) {
    if (item.type === 'secret_request' && item.secretStatus === 'pending') {
      result.push({ id: text(item.id), requestId: '', kind: 'secret', label: text(item.label) + '\n' + text(item.reason), questions: [], enabled: true });
    } else if (item.type === 'approval_request' || item.type === 'user_input_request') {
      const request = requests.find((row: Record<string, Object>) => row.id === item.requestId);
      if (!request || request.status !== 'pending') continue;
      const questions: Question[] = item.type === 'user_input_request' ? objects(item.questions).map((value: Object) => {
        const q = record(value);
        const options = objects(q.options).map(record);
        return { id: text(q.id), label: text(q.header) + ': ' + text(q.question),
          options: options.map((o: Record<string, Object>) => text(o.label) + ' — ' + text(o.description)),
          values: options.map((o: Record<string, Object>) => o.value === undefined ? text(o.label) : text(o.value)),
          multi: q.multiSelect === true, required: q.required !== false, custom: q.allowCustomAnswer !== false };
      }) : [];
      result.push({ id: text(item.id), requestId: text(request.id), kind: item.type === 'user_input_request' ? 'input' : 'approval',
        label: item.type === 'approval_request' ? text(item.requestKind) + '\n' + (typeof item.prompt === 'string' ? item.prompt : '') + '\n' + (typeof item.reason === 'string' ? item.reason : '') : '需要你的回答',
        questions, enabled: record(request.responseCapability).type !== 'not_resumable' });
    }
  }
  return result;
}

export interface SavedSession { base: string; environmentId: string; token: string; expiresAt: number; }
export interface SessionStorage {
  load(): Promise<SavedSession | undefined>;
  save(value: SavedSession): Promise<void>;
  clear(): Promise<void>;
}
export function stopCommand(commandId: string, threadId: string): Object {
  return { type: 'thread.stop', commandId, threadId };
}
export function secretAnswer(threadId: string, turnItemId: string, value: string, decline: boolean): Object {
  return { threadId, turnItemId, answer: decline ? { type: 'decline' } : { type: 'save', secret: value } };
}

export function respondCommand(commandId: string, threadId: string, requestId: string, decision: string, answers: Object): Object {
  if (decision && !['accept', 'decline', 'cancel'].includes(decision)) throw new Error('无效审批决定');
  return { type: 'runtime-request.respond', commandId, threadId, requestId,
    ...(decision ? { decision } : { answers }) };
}

export function answerSelected(answer: Object | undefined, value: string): boolean {
  return Array.isArray(answer) ? answer.includes(value) : answer === value;
}

export function inputAnswers(values: Map<string, Object>): Record<string, Object> {
  return Object.fromEntries(values);
}

// Metadata only: never persist prompts, answers, secrets or signed upload URLs.
export interface RecoveryState {
  base: string; environmentId: string; threadId: string;
  pendingId: string; pendingKind: string;
}
export interface RecoveryStorage {
  load(): Promise<RecoveryState | undefined>;
  save(value: RecoveryState): Promise<void>;
  clear(): Promise<void>;
}
export function recoveryState(value: Object, base: string, environmentId: string): RecoveryState {
  const row = record(value);
  if (row.base !== base || row.environmentId !== environmentId) throw new Error('恢复记录服务器身份不一致');
  const state = { base, environmentId, threadId: text(row.threadId),
    pendingId: typeof row.pendingId === 'string' ? row.pendingId : '',
    pendingKind: typeof row.pendingKind === 'string' ? row.pendingKind : '' };
  if (state.threadId.length > 128 || state.pendingId.length > 128 ||
    !['', 'message', 'create', 'stop', 'response', 'secret'].includes(state.pendingKind) ||
    (!!state.pendingId !== !!state.pendingKind)) throw new Error('恢复记录无效');
  return state;
}

export interface Attachment { type: string; id: string; name: string; mimeType: string; sizeBytes: number; }
export function uploadTarget(value: Object, sizeBytes: number, name: string): { path: string; attachment: Attachment } {
  if (!name.trim() || name.length > 255 || /[\x00-\x1f]/.test(name) || !Number.isSafeInteger(sizeBytes) || sizeBytes < 1 || sizeBytes > 10 * 1024 * 1024) {
    throw new Error('附件名称或大小无效');
  }
  const row = record(value);
  const path = text(row.relativeUrl);
  const id = text(row.attachmentId);
  if (!/^\/api\/attachments\/upload\/[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+$/.test(path) || path.length > 4096 ||
    !/^[a-z0-9_-]{1,128}$/i.test(id) || typeof row.expiresAt !== 'number' || row.expiresAt <= Date.now()) {
    throw new Error('附件上传地址无效或已过期');
  }
  return { path, attachment: { type: 'file', id, name, mimeType: 'application/octet-stream', sizeBytes } };
}
