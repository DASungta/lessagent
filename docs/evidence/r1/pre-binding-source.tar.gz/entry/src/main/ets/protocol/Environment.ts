import { record, serverBase, text } from './Wire';
import { SavedSession, RecoveryState, recoveryState } from './Core';

export interface EnvironmentEntry {
  localId: string; environmentId: string; base: string; label: string;
  enabled: boolean; kind: string; credentialRef: string; deleting?: boolean;
  recovery: RecoveryReference[];
}
export interface RecoveryReference { threadId: string; alias: string; }
export interface EnvironmentDirectory {
  schemaVersion: number; generation: number; selectedLocalId: string;
  entries: EnvironmentEntry[];
}
export interface ValueStore<T> {
  load(): Promise<T | undefined>;
  save(value: T): Promise<void>;
  clear(): Promise<void>;
}
export interface EnvironmentAssets {
  session(alias: string): ValueStore<SavedSession>;
  recovery(alias: string): ValueStore<RecoveryState>;
}
function keys(row: Record<string, Object>, expected: string[]): void {
  if (Object.keys(row).length !== expected.length || Object.keys(row).some((key: string) => !expected.includes(key))) {
    throw new Error('环境目录字段无效');
  }
}
function id(value: Object): string {
  const result = text(value);
  if (!/^[a-zA-Z0-9-]{1,64}$/.test(result)) throw new Error('环境本机标识无效');
  return result;
}
function identity(value: Object): string {
  const result = text(value);
  if (!result || result.length > 256 || /[\u0000-\u001f\u007f]/.test(result)) throw new Error('环境身份无效');
  return result;
}
export function savedSession(value: Object): SavedSession {
  const row = record(value);
  keys(row, ['base', 'environmentId', 'token', 'expiresAt']);
  const base = text(row.base);
  if (serverBase(base) !== base || !text(row.token) || typeof row.expiresAt !== 'number' ||
    !Number.isFinite(row.expiresAt) || row.expiresAt <= 0) throw new Error('安全凭据记录无效');
  return { base, environmentId: identity(row.environmentId), token: text(row.token), expiresAt: row.expiresAt as number };
}
function checkedRecovery(value: Object, base: string, environmentId: string): RecoveryState {
  const row = record(value);
  keys(row, ['base', 'environmentId', 'threadId', 'pendingId', 'pendingKind']);
  text(row.pendingId); text(row.pendingKind);
  const state = recoveryState(row, base, environmentId);
  if (!state.threadId) throw new Error('恢复会话标识无效');
  return state;
}
async function verifyAssets(directory: EnvironmentDirectory, assets: EnvironmentAssets): Promise<void> {
  for (const entry of directory.entries) {
    if (entry.deleting) continue;
    const value = await assets.session(entry.credentialRef).load();
    if (!value) throw new Error('环境凭据记录缺失，未覆盖目录');
    const session = savedSession(value);
    if (session.base !== entry.base || session.environmentId !== entry.environmentId) throw new Error('环境凭据身份不一致');
    for (const ref of entry.recovery) {
      const value = await assets.recovery(ref.alias).load();
      if (!value || checkedRecovery(value, entry.base, entry.environmentId).threadId !== ref.threadId) {
        throw new Error('环境恢复记录缺失或不一致');
      }
    }
  }
}
export function environmentDirectory(value: Object): EnvironmentDirectory {
  const row = record(value);
  keys(row, ['schemaVersion', 'generation', 'selectedLocalId', 'entries']);
  if (row.schemaVersion !== 2 || typeof row.generation !== 'number' || !Number.isSafeInteger(row.generation) ||
    row.generation < 0 || !Array.isArray(row.entries)) throw new Error('环境目录版本或结构无效');
  const entries: EnvironmentEntry[] = [];
  const aliases: string[] = [];
  for (const item of row.entries as Object[]) {
    const entry = record(item);
    keys(entry, ['localId', 'environmentId', 'base', 'label', 'enabled', 'kind', 'credentialRef', 'recovery'].concat(
      Object.keys(entry).includes('deleting') ? ['deleting'] : []));
    if (entry.deleting !== undefined && typeof entry.deleting !== 'boolean') throw new Error('环境删除状态无效');
    const localId = id(entry.localId);
    const base = text(entry.base);
    const environmentId = identity(entry.environmentId);
    if (serverBase(base) !== base || text(entry.label).length > 256 || typeof entry.enabled !== 'boolean' ||
      (entry.deleting === true && entry.enabled !== false) ||
      entry.kind !== 'bearer' || entry.credentialRef !== 't3-v2-' + localId + '-session' || !Array.isArray(entry.recovery) ||
      entries.some((e: EnvironmentEntry) => e.localId === localId || e.environmentId === environmentId)) throw new Error('环境目录条目无效');
    const recovery: RecoveryReference[] = [];
    for (const ref of entry.recovery as Object[]) {
      const r = record(ref);
      keys(r, ['threadId', 'alias']);
      const threadId = text(r.threadId);
      const alias = text(r.alias);
      if (!threadId || threadId.length > 128 || !alias.startsWith('t3-v2-' + localId + '-recovery-') ||
        !/^[a-zA-Z0-9-]{1,200}$/.test(alias) || aliases.includes(alias) ||
        recovery.some((prior: RecoveryReference) => prior.threadId === threadId)) throw new Error('恢复引用无效');
      aliases.push(alias); recovery.push({ threadId, alias });
    }
    const checked: EnvironmentEntry = { localId, environmentId, base, label: text(entry.label), enabled: entry.enabled as boolean,
      kind: 'bearer', credentialRef: text(entry.credentialRef), recovery };
    if (entry.deleting !== undefined) checked.deleting = entry.deleting as boolean;
    entries.push(checked);
  }
  const selectedLocalId = text(row.selectedLocalId);
  if (selectedLocalId && !entries.some((e: EnvironmentEntry) => e.localId === selectedLocalId)) throw new Error('所选环境不存在');
  return { schemaVersion: 2, generation: row.generation as number, selectedLocalId, entries };
}

// Directory commit is the only activation point. Fixed legacy aliases make retries crash-idempotent.
// shortcut: v2 activation awaits the multi-client binding; never run v1 and v2 writers together.
export async function migrateLegacy(directoryStore: ValueStore<EnvironmentDirectory>, assets: EnvironmentAssets,
  legacySession: ValueStore<SavedSession>, legacyRecovery: ValueStore<RecoveryState>): Promise<EnvironmentDirectory> {
  const existing = await directoryStore.load();
  if (existing !== undefined) {
    const checked = environmentDirectory(existing);
    await verifyAssets(checked, assets);
    return checked;
  }
  const source = await legacySession.load();
  const oldRecovery = await legacyRecovery.load();
  const directory: EnvironmentDirectory = { schemaVersion: 2, generation: 1, selectedLocalId: '', entries: [] };
  if (source === undefined) {
    if (oldRecovery !== undefined) throw new Error('存在无对应凭据的恢复记录，请先核对；旧记录已保留');
  } else {
    const session = savedSession(source); // Expiry does not erase environment or pending facts.
    const recovery = oldRecovery !== undefined ? checkedRecovery(oldRecovery, session.base, session.environmentId) : undefined;
    if (recovery && !recovery.threadId) throw new Error('旧恢复会话标识无效，旧记录已保留');
    const entry: EnvironmentEntry = { localId: 'legacy-v1', environmentId: session.environmentId,
      base: session.base, label: session.environmentId, enabled: true, kind: 'bearer',
      credentialRef: 't3-v2-legacy-v1-session', recovery: [] };
    const target = assets.session(entry.credentialRef);
    await target.save(session);
    if (JSON.stringify(await target.load()) !== JSON.stringify(session)) throw new Error('凭据回读校验失败，旧记录已保留');
    if (recovery) {
      const alias = 't3-v2-legacy-v1-recovery-initial';
      const targetRecovery = assets.recovery(alias);
      await targetRecovery.save(recovery);
      if (JSON.stringify(await targetRecovery.load()) !== JSON.stringify(recovery)) throw new Error('恢复记录回读校验失败，旧记录已保留');
      entry.recovery.push({ threadId: recovery.threadId, alias });
    }
    directory.entries.push(entry); directory.selectedLocalId = entry.localId;
  }
  await verifyAssets(directory, assets);
  await directoryStore.save(environmentDirectory(directory));
  return directory;
}
