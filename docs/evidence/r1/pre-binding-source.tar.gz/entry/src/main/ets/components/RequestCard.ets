import { client } from '../services/T3Client';
import { ActionCard, Question, answerSelected, inputAnswers } from '../protocol/Core';

@Component
export struct RequestCard {
  @StorageLink('t3Foreground') @Watch('clearPrivateInput') foreground: boolean = true;
  private clearPrivateInput(): void {
    if (!this.foreground) { this.secretValue = ''; this.answers = new Map(); }
  }
  @Prop card: ActionCard;
  @State secretValue: string = '';
  @State answers: Map<string, Object> = new Map();
  @State busy: boolean = false;
  @State status: string = '';
  @State submitted: boolean = false;

  aboutToDisappear(): void { this.secretValue = ''; this.answers = new Map(); }

  private choose(q: Question, value: string): void {
    if (q.multi) {
      const values = (this.answers.get(q.id) || []) as string[];
      this.answers.set(q.id, values.includes(value) ? values.filter((v: string) => v !== value) : values.concat(value));
    } else this.answers.set(q.id, value);
    this.answers = new Map(this.answers);
  }

  private async submit(decision: string): Promise<void> {
    if (this.busy || this.submitted) return;
    this.busy = true;
    const value = this.secretValue;
    const answers = inputAnswers(this.answers);
    this.secretValue = '';
    this.answers = new Map();
    try {
      if (this.card.kind === 'secret') {
        this.submitted = true;
        await client.secret(this.card.id, value, decision === 'decline');
      }
      else {
        if (this.card.kind === 'input') {
          for (const q of this.card.questions) {
            const answer = answers[q.id];
            if (q.required && (!answer || (Array.isArray(answer) && answer.length === 0))) throw new Error('请回答所有必填问题');
          }
        }
        this.submitted = true;
        await client.respond(this.card.requestId, decision, answers);
      }
      this.status = '已提交，等待服务端更新';
    } catch (error) { this.status = (error as Error).message; }
    finally { this.busy = false; }
  }

  build() {
    Column({ space: 12 }) {
      Text(this.card.kind === 'secret' ? '安全输入' : this.card.kind === 'approval' ? '需要你的许可' : '需要你的回答').fontSize(12).fontColor($r('app.color.muted')).width('100%')
      Text(this.card.label).fontSize(16).fontWeight(FontWeight.Medium).width('100%')
      if (this.card.kind === 'secret') {
        Text('敏感值仅发往专用接口，不进入聊天、草稿或剪贴板。').fontSize(12)
        TextInput({ placeholder: '敏感输入', text: this.secretValue }).type(InputType.Password).enableAutoFill(false)
          .onChange((value: string) => this.secretValue = value)
        Button('安全提交').width('100%').fontSize(14).constraintSize({ minHeight: 44 }).borderRadius(12).backgroundColor($r('app.color.accent')).fontColor($r('app.color.on_accent')).enabled(!this.busy && !this.submitted && this.secretValue.trim().length > 0).onClick(() => this.submit(''))
        Button('拒绝提供').width('100%').fontSize(14).constraintSize({ minHeight: 44 }).borderRadius(12).backgroundColor($r('app.color.canvas')).fontColor($r('app.color.ink')).enabled(!this.busy && !this.submitted).onClick(() => this.submit('decline'))
      } else if (this.card.kind === 'approval') {
        Button('允许本次').width('100%').fontSize(14).constraintSize({ minHeight: 44 }).borderRadius(12).backgroundColor($r('app.color.accent')).fontColor($r('app.color.on_accent')).enabled(this.card.enabled && !this.busy && !this.submitted).onClick(() => this.submit('accept'))
        Button('拒绝本次').width('100%').fontSize(14).constraintSize({ minHeight: 44 }).borderRadius(12).backgroundColor($r('app.color.canvas')).fontColor($r('app.color.ink')).enabled(this.card.enabled && !this.busy && !this.submitted).onClick(() => this.submit('decline'))
      } else {
        ForEach(this.card.questions, (q: Question) => {
          Text(q.label + (q.required ? '（必填）' : '（可选）'))
          ForEach(q.options, (option: string, index: number) => {
            Button((answerSelected(this.answers.get(q.id), q.values[index]) ? '✓ ' : '') + option)
              .width('100%').fontSize(14).constraintSize({ minHeight: 44 }).borderRadius(12)
              .backgroundColor(answerSelected(this.answers.get(q.id), q.values[index]) ? $r('app.color.selected') : $r('app.color.canvas'))
              .fontColor($r('app.color.ink')).accessibilityText(option + (answerSelected(this.answers.get(q.id), q.values[index]) ? '，已选中' : '，未选中'))
              .onClick(() => this.choose(q, q.values[index])).enabled(!this.busy && !this.submitted)
          })
          if (q.custom) {
            TextInput({ placeholder: '回答（仅本次提交）', text: typeof this.answers.get(q.id) === 'string' ? this.answers.get(q.id) as string : '' })
              .enableAutoFill(false).enabled(!this.busy && !this.submitted).onChange((value: string) => { this.answers.set(q.id, q.multi ? [value] : value); this.answers = new Map(this.answers); })
          }
          Text(this.answers.get(q.id) ? '已填写/选择' : '待回答').fontSize(12)
        })
        Button('提交回答').width('100%').fontSize(14).constraintSize({ minHeight: 44 }).borderRadius(12).backgroundColor($r('app.color.accent')).fontColor($r('app.color.on_accent')).enabled(this.card.enabled && !this.busy && !this.submitted).onClick(() => this.submit(''))
      }
      if (!this.card.enabled) { Text('此请求不可恢复，请停止后重新发起任务') }
      if (this.status) { Text(this.status).fontSize(14).width('100%') }
    }.padding(16).width('100%').alignItems(HorizontalAlign.Start)
      .backgroundColor($r('app.color.canvas')).foregroundColor($r('app.color.ink')).borderRadius(18)
      .border({ width: 1, color: $r('app.color.border') })
  }
}
