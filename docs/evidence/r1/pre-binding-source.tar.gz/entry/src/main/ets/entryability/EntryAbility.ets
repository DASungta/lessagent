import { UIAbility } from '@kit.AbilityKit';
import { client } from '../services/T3Client';
import { SessionStore } from '../storage/SessionStore';
import { RecoveryState } from '../protocol/Core';
import { window, KeyboardAvoidMode } from '@kit.ArkUI';

export default class EntryAbility extends UIAbility {
  onWindowStageCreate(stage: window.WindowStage): void {
    client.store = new SessionStore();
    client.recoveryStore = new SessionStore<RecoveryState>('t3-harmony-recovery-v1');
    stage.loadContent('pages/Index').then(() => {
      stage.getMainWindowSync().getUIContext().setKeyboardAvoidMode(KeyboardAvoidMode.RESIZE);
    }).catch(() => {
      client.disconnect('页面加载失败');
    });
  }
  onForeground(): void {
    AppStorage.setOrCreate('t3Foreground', true);
    void client.resume().catch(() => { client.status = '请解锁后安全重连'; client.onUpdate(); });
  }
  onBackground(): void {
    AppStorage.setOrCreate('t3Foreground', false);
    client.suspend();
  }
}
