import test from 'node:test';
import assert from 'node:assert/strict';
import {readFile} from 'node:fs/promises';
import {createRequire} from 'node:module';
const ts=createRequire(import.meta.url)((process.env.DEVECO_HOME || '/Applications/DevEco-Studio.app/Contents')+'/sdk/default/openharmony/ets/build-tools/ets-loader/node_modules/typescript');
const source=await readFile(new URL('../entry/src/main/ets/pages/Index.ets',import.meta.url),'utf8');
const method=source.slice(source.indexOf('  private async send()'),source.indexOf('  private async stop()'));
const code=ts.transpileModule('return class { '+method+' }',{compilerOptions:{target:ts.ScriptTarget.ES2022}}).outputText;
test('send acknowledgement clears only the submitted draft, preserving text typed while waiting',async()=>{
 for(const newer of ['', 'next task']) {
  let resolve;
  const client={send:()=>new Promise(r=>resolve=r)};
  const Page=new Function('client',code)(client);
  const page=new Page();Object.assign(page,{incomingPairing:()=>{},prompt:'original',drafts:new Map([['thread','original']]),draftKey:()=> 'thread'});
  const pending=page.send();
  if(newer) page.prompt=newer;
  resolve();await pending;
  assert.equal(page.prompt,newer);assert.equal(page.busy,false);
 }
});
test('failed send retains the draft and exposes the error',async()=>{
 const Page=new Function('client',code)({send:async()=>{throw Error('offline');}});
 const page=new Page();Object.assign(page,{incomingPairing:()=>{},prompt:'original'});
 await page.send();assert.equal(page.prompt,'original');assert.equal(page.status,'offline');assert.equal(page.busy,false);
});
test('light and dark text pairs meet normal text contrast',async()=>{
 const luminance=hex=>{const rgb=hex.slice(1).match(/../g).map(x=>parseInt(x,16)/255).map(x=>x<=.04045?x/12.92:((x+.055)/1.055)**2.4);return rgb[0]*.2126+rgb[1]*.7152+rgb[2]*.0722;};
 for(const theme of ['base','dark']) {
  const {color}=JSON.parse(await readFile(new URL(`../entry/src/main/resources/${theme}/element/color.json`,import.meta.url),'utf8'));
  const colors=Object.fromEntries(color.map(x=>[x.name,x.value]));
  for(const [fg,bg] of [['ink','canvas'],['muted','canvas'],['ink','surface'],['muted','surface'],['accent','selected'],['on_accent','accent']]) {
   const a=luminance(colors[fg]),b=luminance(colors[bg]);assert.ok((Math.max(a,b)+.05)/(Math.min(a,b)+.05)>=4.5,`${theme} ${fg}/${bg}`);
  }
 }
});
test('native back dismisses the sheet first, then returns to the list',()=>{
 const method=source.slice(source.indexOf('  onBackPress()'),source.indexOf('  private projectOptions()'));
 const compiled=ts.transpileModule('return class { '+method+' }',{compilerOptions:{target:ts.ScriptTarget.ES2022}}).outputText;
 const Page=new Function(compiled)();const page=new Page();
 Object.assign(page,{panelOpen:true,page:'chat'});
 assert.equal(page.onBackPress(),true);assert.equal(page.panelOpen,false);assert.equal(page.page,'chat');
 assert.equal(page.onBackPress(),true);assert.equal(page.page,'sessions');assert.equal(page.onBackPress(),false);
});
test('environment binding scopes colliding thread drafts and clears displayed data before rebinding',()=>{
 const method=source.slice(source.indexOf('  private bindEnvironment()'),source.indexOf('  private async restoreAddress()'));
 const key=source.slice(source.indexOf('  private draftKey()'),source.indexOf('  private async watch('));
 const compiled=ts.transpileModule('return class { '+method+key+' }',{compilerOptions:{target:ts.ScriptTarget.ES2022}}).outputText;
 const entries=[{localId:'a',label:'A',base:'https://a'},{localId:'b',label:'B',base:'https://b'}];
 const a={status:'A',thread:{threadId:'same'},shell:{projects:[],threads:[]}},b={status:'B',thread:{threadId:'same'},shell:{projects:[],threads:[]}};
 const registry={directory:{entries,selectedLocalId:'b'},clients:new Map([['a',a],['b',b]])};
 let bound;
 class Picker {constructor(owner){this.owner=owner}belongsTo(owner){return this.owner===owner}}
 const Page=new Function('bindClient','AttachmentPicker','client',compiled)(v=>bound=v,Picker,b);
 const page=new Page();Object.assign(page,{registry:()=>registry,selectedLocalId:'a',prompt:'draft A',threadId:'same',drafts:new Map(),pickers:new Map(),messages:['private A'],source:{update:()=>{}},panel:'server'});
 page.bindEnvironment();assert.equal(bound,b);assert.equal(page.prompt,'');assert.deepEqual(page.messages,[]);
 page.prompt='draft B';registry.directory.selectedLocalId='a';page.bindEnvironment();assert.equal(page.prompt,'draft A');assert.equal(bound,a);
 assert.equal(page.drafts.get('b\nsame'),'draft B');
});
test('home project filters use scoped identity without inheriting the active chat project',()=>{
 const methods=source.slice(source.indexOf('  private visibleThreads()'),source.indexOf('  private openPanel('));
 const compiled=ts.transpileModule('return class { '+methods+' }',{compilerOptions:{target:ts.ScriptTarget.ES2022}}).outputText;
 const Page=new Function(compiled)();const page=new Page();
 Object.assign(page,{environmentFilter:'',projectFilterId:'',projectFilterLocalId:'',projectId:'same-project',selectedLocalId:'a',scopedProjects:[{localId:'a',id:'same-project',label:'A'},{localId:'b',id:'same-project',label:'B'}],scopedThreads:[{localId:'a',id:'same-thread',projectId:'same-project'},{localId:'b',id:'same-thread',projectId:'same-project'}]});
 assert.deepEqual(page.visibleThreads().map(t=>t.localId),['a','b']);
 page.filterProject(2);assert.deepEqual(page.visibleThreads().map(t=>t.localId),['b']);
 page.environmentFilter='a';page.filterProject(1);assert.deepEqual(page.visibleThreads().map(t=>t.localId),['a']);
 page.filterProject(0);page.environmentFilter='';assert.equal(page.visibleThreads().length,2);
});
