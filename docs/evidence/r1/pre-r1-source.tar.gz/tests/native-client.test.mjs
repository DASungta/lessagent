// Execute the actual NetworkKit adapter with a small fake kit; HAP build checks the SDK types.
import { coreUrl } from './load-core.mjs';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import test from 'node:test';
const require = createRequire(import.meta.url);
const deveco = process.env.DEVECO_HOME || '/Applications/DevEco-Studio.app/Contents';
const ts = require(deveco + '/sdk/default/openharmony/ets/build-tools/ets-loader/node_modules/typescript');
const original = await readFile(new URL('../entry/src/main/ets/services/T3Client.ets', import.meta.url), 'utf8');
const wire = new URL('../entry/src/main/ets/protocol/Wire.ts', import.meta.url).href;
let moduleId = 0;
async function setup(options = {}) {
  const requests = [];
  const frames = [];
  let destroyed = 0;
  let socket;
  const kit = {
    util: { generateRandomUUID: () => 'test-' + Math.random().toString(36).slice(2) },
    http: {
      RequestMethod: { GET: 'GET', POST: 'POST' }, HttpDataType: { STRING: 'string' },
      createHttp: () => ({
        request: async (url, args) => {
          requests.push({ url, args });
          if (args.method === 'POST' && args.extraData === '') {
            throw Object.assign(new Error('Invalid extraData'), { code: 401 });
          }
          let value;
          let status = 200;
          if (url.includes('/api/attachments/upload/')) { return {responseCode:options.uploadStatus ?? 204,result:''}; }
          if (url.endsWith('/.well-known/t3/environment')) {
            if (options.waitMetadata) await options.waitMetadata;
            value = { environmentId: 'env', label: 'Test', serverVersion: 'test', orchestrationProtocolVersion: options.protocol ?? 2 };
          } else if (url.endsWith('/oauth/token')) {
            if (options.authError) status = 401;
            value = { access_token: 'SYNTHETIC_TOKEN', token_type: 'Bearer', expires_in: 3600 };
          } else {
            if (options.ticket404 && url.endsWith('/rpc')) status = 404;
            value = { ticket: 'SYNTHETIC_TICKET' };
          }
          return { responseCode: status, result: JSON.stringify(value) };
        },
        destroy: () => destroyed++
      })
    },
    webSocket: {
      createWebSocket: () => {
        const listeners = {};
        socket = {
          on: (type, callback) => listeners[type] = callback,
          close: async () => true,
          connect: async (url) => {
            if (options.socketError) throw new Error('transport echoed ' + url);
            return true;
          },
          emit: (value) => listeners.message({ code: 0 }, JSON.stringify(value)),
          send: async (frame) => {
            const value = JSON.parse(frame);
            frames.push(value);
            if (value._tag === 'Request') queueMicrotask(() => {
              if (value.tag === 'orchestration.subscribeShell') {
                socket.emit({ _tag: 'Chunk', requestId: value.id, values: [{ kind: 'snapshot', snapshot: { snapshotSequence: 9, projects: [], threads: [] } }] });
              } else if (value.tag === 'orchestration.subscribeThread') {
                socket.emit({ _tag: 'Chunk', requestId: value.id, values: [{ kind: 'snapshot', snapshotSequence: 10,
                  projection: { thread: { id: value.payload.threadId }, messages: options.messages ?? [] } }] });
              } else {
                if (options.dropMutation && value.tag !== 'server.getConfig') return;
                const result = value.tag === 'attachments.createUploadUrl' ? {attachmentId:'pending-test',relativeUrl:options.uploadPath ?? '/api/attachments/upload/signed.token',expiresAt:Date.now()+60000} : value.tag === 'server.getConfig' ? { environment: { environmentId: options.mismatch ? 'other' : 'env' } } : { sequence: 11 };
                socket.emit({ _tag: 'Exit', requestId: value.id, exit: { _tag: 'Success', value: result } });
              }
            });
            return true;
          }
        };
        return socket;
      }
    }
  };
  globalThis.__nativeKit = kit;
  const source = original
    .replace("import { http, webSocket } from '@kit.NetworkKit';", 'const { http, webSocket } = globalThis.__nativeKit;')
    .replace("import { util } from '@kit.ArkTS';", 'const { util } = globalThis.__nativeKit;')
    .replace("import { BusinessError } from '@kit.BasicServicesKit';", '')
    .replace("'../protocol/Wire'", JSON.stringify(wire))
    .replace("'../protocol/Core'", JSON.stringify(coreUrl));
  const compiled = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.ES2022, target: ts.ScriptTarget.ES2022 } }).outputText;
  const { T3Client } = await import('data:text/javascript;base64,' + Buffer.from(compiled + '\n// instance ' + ++moduleId).toString('base64'));
  const client = new T3Client();
  client.recoveryStore = options.recoveryStore;
  return { client, requests, frames, destroyed: () => destroyed, socket: () => socket };
}

test('native adapter runs auth, ticket, identity check, create, subscribe, send and reconnect', async () => {
  const { client, requests, frames, destroyed } = await setup();
  try {
    await client.connect('https://test', 'synthetic credential');
    assert.equal(client.ready, true);
    assert.equal(requests.length, 3);
    assert.equal(destroyed(), 3);
    assert.equal(new URLSearchParams(requests[1].args.extraData).get('subject_token'), 'synthetic credential');
    assert.equal(requests[2].args.header.Authorization, 'Bearer SYNTHETIC_TOKEN');
    assert.equal(requests[1].args.maxRedirects, 0);
    const threadId = await client.newThread('project', 'codex', 'model');
    await client.watch(threadId);
    await new Promise(setImmediate);
    assert.equal(client.thread.cursor, 10);
    assert.ok(frames.some((frame) => frame._tag === 'Ack'));
    await client.send('hello');
    assert.ok(frames.some((frame) => frame.payload?.type === 'message.dispatch'));
    await client.watch('another-thread');
    await new Promise(setImmediate);
    assert.equal(client.thread.threadId, 'another-thread');
    assert.ok(frames.some(frame => frame._tag === 'Interrupt'));
    client.disconnect();
    await client.connect('https://test', 'new synthetic credential');
    await client.watch(threadId);
    await new Promise(setImmediate);
    assert.equal(client.thread.threadId, threadId);
    assert.equal(client.thread.cursor, 10);
  } finally { client.disconnect(); }
});

test('only a ticket 404 falls back to the bare endpoint', async () => {
  const { client, requests } = await setup({ ticket404: true });
  try {
    await client.connect('https://test', 'synthetic');
    assert.equal(client.ready, true);
    assert.ok(requests[3].url.endsWith('/api/auth/websocket-ticket'));
  } finally { client.disconnect(); }
});

test('bad credentials and incompatible versions stop before opening a socket', async () => {
  for (const options of [{ authError: true }, { protocol: 3 }]) {
    const { client, requests, socket } = await setup(options);
    await client.connect('https://test', 'synthetic');
    assert.equal(client.ready, false);
    assert.equal(socket(), undefined);
    assert.match(client.status, options.authError ? /鉴权失败/ : /不兼容/);
    assert.equal(requests.length, options.authError ? 2 : 1);
  }
});

test('socket failures cannot echo tickets into UI diagnostics', async () => {
  const { client } = await setup({ socketError: true });
  await client.connect('https://test', 'synthetic');
  assert.equal(client.ready, false);
  assert.match(client.status, /WebSocket/);
  assert.ok(!client.status.includes('SYNTHETIC_TICKET'));
});

test('identity mismatch blocks a connection', async () => {
  const { client } = await setup({ mismatch: true });
  await client.connect('https://test', 'synthetic');
  assert.equal(client.ready, false);
  assert.match(client.status, /身份不一致/);
});

test('background/disconnect during metadata lookup prevents a stale credential exchange', async () => {
  let release;
  const gate = new Promise((resolve) => { release = resolve; });
  const { client, requests, socket } = await setup({ waitMetadata: gate });
  const connecting = client.connect('https://test', 'synthetic');
  client.disconnect('entered background');
  release();
  await connecting;
  assert.equal(requests.length, 1);
  assert.equal(client.ready, false);
  assert.equal(socket(), undefined);
});

test('secure session reuse does not exchange one-time pairing again; expiry and server mismatch fail closed', async () => {
 const {client,requests}=await setup();
 let saved;
 client.store={load:async()=>saved,save:async v=>{saved=v},clear:async()=>{saved=undefined}};
 try {
  await client.connect('https://test','synthetic');assert.equal(client.ready,true);
  client.disconnect();await client.connect('https://test');assert.equal(client.ready,true);
  assert.equal(requests.filter(r=>r.url.endsWith('/oauth/token')).length,1);
  client.disconnect();await client.connect('https://other');assert.equal(client.ready,false);
  assert.match(client.status,/有效会话/);
  saved.expiresAt=0;await client.connect('https://test');assert.equal(client.ready,false);
  await client.forget();assert.equal(saved,undefined);
 }finally{client.disconnect();}
});

test('responses, secrets and stop use distinct contracts and reject stale requests', async()=>{
 const {client,frames}=await setup();
 try {
  await client.connect('https://test','synthetic');await client.watch('t');await new Promise(setImmediate);
  client.thread.requests=[{id:'r',status:'pending',responseCapability:{type:'live'}}];
  await client.respond('r','accept',{});
  client.thread.requests[0].status='resolved';await assert.rejects(client.respond('r','accept',{}),/失效/);
  client.thread.items=[{id:'s',type:'secret_request',secretStatus:'pending'}];
  await client.secret('s','SYNTHETIC_SECRET',false);await client.stop();
  const secret=frames.find(f=>f.tag==='secrets.answerRequest');
  assert.equal(secret.payload.answer.secret,'SYNTHETIC_SECRET');
  assert.ok(!frames.some(f=>f.payload?.type==='message.dispatch'));
  assert.ok(frames.some(f=>f.payload?.type==='thread.stop'));
 }finally{client.disconnect();}
});

test('unknown message submission requires a fresh snapshot before manual retry',async()=>{
 const {client}=await setup();
 try {
  await client.connect('https://test','synthetic');await client.watch('t');await new Promise(setImmediate);
  client.recovery.pendingId='lost-ack-message';client.recovery.pendingKind='message';
  await assert.rejects(client.send('retry'),/结果未知/);
  await client.watch('t');await new Promise(r=>setTimeout(r,60));
  assert.match(client.status,/结果未知/);
  await assert.rejects(client.send('retry'),/结果未知/);
  await client.acknowledgeUnknown();
  await client.send('manually checked retry');
 }finally{client.disconnect();}
});

test('snapshot confirms a lost acknowledgement by message id without resending',async()=>{
 const {client,frames}=await setup({messages:[{id:'lost-ack',threadId:'t',role:'user',text:'already accepted',streaming:false}]});
 try{
  await client.connect('https://test','synthetic');await client.watch('t');
  client.recovery.pendingId='lost-ack';client.recovery.pendingKind='message';
  await client.watch('t');await new Promise(setImmediate);
  assert.equal(client.recoveredMessageId,'lost-ack');assert.match(client.status,/已接收/);
  assert.equal(frames.filter(f=>f.payload?.type==='message.dispatch').length,0);
 }finally{client.disconnect();}
});

function memoryRecovery(initial) {
 let value=initial;
 return {load:async()=>structuredClone(value),save:async v=>{value=structuredClone(v)},clear:async()=>{value=undefined}};
}
test('process exit restores selected thread and unknown message without replay or persisted body', async()=>{
 const store=memoryRecovery();
 const first=await setup({dropMutation:true,recoveryStore:store});
 await first.client.connect('https://test','synthetic');await first.client.watch('t');await new Promise(setImmediate);
 const sending=first.client.send('PRIVATE PROMPT').catch(()=>{});
 await new Promise(setImmediate);
 const persisted=await store.load();assert.equal(persisted.pendingKind,'message');
 assert.ok(!JSON.stringify(persisted).includes('PRIVATE PROMPT'));
 first.client.disconnect();await sending;
 const next=await setup({recoveryStore:store,messages:[{id:persisted.pendingId,threadId:'t',role:'user',text:'PRIVATE PROMPT',streaming:false}]});
 try {
  await next.client.connect('https://test','synthetic');await new Promise(r=>setTimeout(r,70));
  assert.equal(next.client.thread.threadId,'t');assert.equal(next.client.recoveredMessageId,persisted.pendingId);
  assert.equal(next.frames.filter(f=>f.payload?.type==='message.dispatch').length,0);
  await assert.rejects(next.client.send('again'),/结果未知/);
  await next.client.acknowledgeUnknown();assert.equal((await store.load()).pendingId,'');
 } finally {next.client.disconnect();}
});
test('journal failure and duplicate clicks cannot send modifying frames', async()=>{
 const store=memoryRecovery();const {client,frames}=await setup({recoveryStore:store,dropMutation:true});
 try {
  await client.connect('https://test','synthetic');await client.watch('t');await new Promise(setImmediate);
  store.save=async()=>{throw Error('storage unavailable')};
  await assert.rejects(client.send('blocked'),/storage unavailable/);
  assert.equal(frames.filter(f=>f.payload?.type==='message.dispatch').length,0);
 } finally {client.disconnect();}
});
test('background returns to the same thread using reads only; explicit disconnect stays disconnected',async()=>{
 const {client,frames}=await setup({recoveryStore:memoryRecovery()});
 try {
  await client.connect('https://test','synthetic');await client.watch('t');await new Promise(setImmediate);
  client.suspend();assert.equal(client.ready,false);await client.resume();await new Promise(setImmediate);
  assert.equal(client.thread.threadId,'t');assert.equal(frames.filter(f=>f.tag==='orchestration.dispatchCommand').length,0);
  client.disconnect();await client.resume();assert.equal(client.ready,false);
 }finally{client.disconnect();}
});
test('recovery record cannot cross server identities',async()=>{
 const store=memoryRecovery({base:'https://other',environmentId:'other',threadId:'private',pendingId:'',pendingKind:''});
 const {client,frames}=await setup({recoveryStore:store});
 try {await client.connect('https://test','synthetic');assert.equal(client.ready,false);
 assert.equal(frames.filter(f=>f.tag==='orchestration.subscribeThread').length,0);
 assert.match(client.status,/身份不一致/);}finally{client.disconnect();}
});

test('double click while journal write waits sends only one command',async()=>{
 let release;const gate=new Promise(r=>release=r);const store=memoryRecovery();
 const {client,frames}=await setup({recoveryStore:store});
 try{
  await client.connect('https://test','synthetic');await client.watch('t');await new Promise(setImmediate);
  const save=store.save;store.save=async v=>{await gate;await save(v)};
  const first=client.send('one');await assert.rejects(client.send('two'),/结果未知/);
  release();await first;assert.equal(frames.filter(f=>f.payload?.type==='message.dispatch').length,1);
 }finally{release();client.disconnect();}
});

test('attachment sends exact bytes without bearer forwarding or redirects, and dispatches only on user send',async()=>{
 const {client,frames,requests}=await setup();
 try{
  await client.connect('https://test','synthetic');await client.watch('t');await new Promise(setImmediate);
  const bytes=new Uint8Array([1,2,3]).buffer;await client.upload('test.bin',bytes);
  const upload=requests.find(r=>r.url.includes('/api/attachments/upload/'));
  assert.equal(upload.args.extraData,bytes);assert.equal(upload.args.header.Authorization,undefined);
  assert.equal(upload.args.maxRedirects,0);assert.equal(frames.filter(f=>f.payload?.type==='message.dispatch').length,0);
  await client.send('inspect');assert.equal(frames.find(f=>f.payload?.type==='message.dispatch').payload.attachments[0].id,'pending-test');
  assert.equal(client.attachment,undefined);
 }finally{client.disconnect();}
});
test('invalid signed targets and failed uploads cannot attach or dispatch',async()=>{
 for(const options of [{uploadPath:'https://evil/path'},{uploadStatus:500}]){
  const {client,frames,requests}=await setup(options);
  try{
   await client.connect('https://test','synthetic');await client.watch('t');await new Promise(setImmediate);
   await assert.rejects(client.upload('test.bin',new Uint8Array([1]).buffer));
   assert.equal(client.attachment,undefined);assert.equal(frames.filter(f=>f.payload?.type==='message.dispatch').length,0);
   assert.ok(requests.every(r=>!r.url.includes('evil')));
  }finally{client.disconnect();}
 }
});
