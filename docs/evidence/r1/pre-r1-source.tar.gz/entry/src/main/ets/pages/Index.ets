import { AttachmentPicker } from '../services/AttachmentPicker';
import { client } from '../services/T3Client';
import { ChatMessage } from '../protocol/Wire';
import { Choice, ModelChoice, ActionCard, cards, markdown, MarkdownBlock } from '../protocol/Core';
import { MessageSource } from '../components/MessageSource';
import { RequestCard } from '../components/RequestCard';
import { pasteboard } from '@kit.BasicServicesKit';

@Extend(Button)
function quietButton() {
    .backgroundColor(Color.Transparent).fontColor($r('app.color.ink')).borderRadius(10)
    .fontSize(14).constraintSize({ minHeight: 44 }).padding({ left: 12, right: 12 })
  }

@Extend(Button)
function primaryButton() {
    .backgroundColor($r('app.color.accent')).fontColor($r('app.color.on_accent')).borderRadius(10)
    .fontSize(14).constraintSize({ minHeight: 44 }).padding({ left: 16, right: 16 })
  }


@Entry
@Component
struct Index {
  @State page: string = 'sessions';
  @State showTools: boolean = false;
  @State panelOpen: boolean = false;
  @State panel: string = 'server';
  @State address: string = '';
  @State credential: string = '';
  @State projectId: string = '';
  @State modelIndex: number = 0;
  @State threadId: string = '';
  @State prompt: string = '';
  @State status: string = '未连接';
  @State server: string = '';
  @State ready: boolean = false;
  @State busy: boolean = false;
  @State messages: ChatMessage[] = [];
  @State projects: Choice[] = [];
  @State threads: Choice[] = [];
  @State models: ModelChoice[] = [];
  @State actions: ActionCard[] = [];
  @State tools: string[] = [];
  private picker: AttachmentPicker = new AttachmentPicker();
  @State attachmentName: string = '';
  private source: MessageSource = new MessageSource();
  private scroller: Scroller = new Scroller();
  @State unknown: boolean = false;
  private drafts: Map<string, string> = new Map();

  aboutToAppear(): void {
    client.onUpdate = () => {
      this.status = client.status;
      this.server = client.server;
      this.ready = client.ready;
      this.messages = client.thread ? client.thread.messages.slice() : this.messages;
      if (client.recoveredMessageId && this.messages.some((m: ChatMessage) =>
        m.id === client.recoveredMessageId && m.text === this.prompt)) {
        this.prompt = '';
        this.drafts.delete(this.draftKey());
      }
      this.source.update(this.messages);
      this.attachmentName = client.attachment?.name || '';
      this.unknown = !!client.recovery?.pendingId;
      this.projects = client.shell.projects.slice();
      this.threads = client.shell.threads.slice();
      this.models = client.models.slice();
      this.actions = client.thread ? cards(client.thread.requests, client.thread.items) : [];
      this.tools = client.thread ? client.thread.items.filter((row: Record<string, Object>) =>
        row.type !== 'assistant_message' && row.type !== 'user_message' && row.type !== 'reasoning' &&
        row.type !== 'secret_request' && row.type !== 'user_input_request' && row.type !== 'approval_request')
        .map((row: Record<string, Object>) => String(row.type) + ' · ' + String(row.status) +
          (typeof row.title === 'string' ? ' · ' + row.title : '') +
          (typeof row.input === 'string' ? '\n' + row.input : '') +
          (typeof row.output === 'string' ? '\n' + row.output : '') +
          (row.outputOmitted === true ? '\n工具输出未随快照提供' : '')) : [];
      if (client.thread) {
        this.threadId = client.thread.threadId;
        this.projectId = this.threads.find((t: Choice) => t.id === this.threadId)?.projectId || this.projectId;
      }
    };
    void this.restoreAddress();
  }

  private async restoreAddress(): Promise<void> {
    try {
      const saved = await client.store?.load();
      if (saved && !this.address) { this.address = saved.base; await this.connect(); }
    }
    catch (error) { this.status = (error as Error).message; }
  }

  aboutToDisappear(): void { client.disconnect(); client.onUpdate = () => {}; }

  private async connect(): Promise<void> {
    if (client.recovery && client.recovery.base !== this.address) { this.messages = []; this.source.update([]); }
    this.busy = true;
    const credential = this.credential;
    this.credential = '';
    try { await client.connect(this.address, credential); if (this.ready) this.panelOpen = false; }
    catch (error) { this.status = (error as Error).message; }
    finally { this.busy = false; }
  }

  private draftKey(): string { return this.address + '\n' + this.threadId; }

  private async watch(id: string): Promise<void> {
    this.drafts.set(this.draftKey(), this.prompt);
    this.threadId = id;
    this.prompt = this.drafts.get(this.draftKey()) || '';
    this.busy = true;
    try { await client.watch(id); this.page = 'chat'; this.showTools = false; this.panelOpen = false; }
    catch (error) { this.status = (error as Error).message; }
    finally { this.busy = false; }
  }

  private async newThread(): Promise<void> {
    this.drafts.set(this.draftKey(), this.prompt);
    this.prompt = '';
    this.busy = true;
    try {
      const model = this.models[this.modelIndex];
      if (!model) throw new Error('请选择可用模型');
      const id = await client.newThread(this.projectId, model.instanceId, model.model);
      await this.watch(id);
    } catch (error) { this.status = (error as Error).message; }
    finally { this.busy = false; }
  }

  private async send(): Promise<void> {
    this.busy = true;
    const submitted = this.prompt;
    try { await client.send(submitted); if (this.prompt === submitted) { this.prompt = ''; this.drafts.delete(this.draftKey()); } }
    catch (error) { this.status = (error as Error).message; }
    finally { this.busy = false; }
  }

  private async stop(): Promise<void> {
    this.busy = true;
    try { await client.stop(); this.status = '停止请求已确认'; }
    catch (error) { this.status = (error as Error).message; }
    finally { this.busy = false; }
  }

  private async forget(): Promise<void> {
    try { await client.forget(); this.address = ''; this.threadId = ''; this.prompt = ''; this.messages = []; this.source.update([]); this.picker.clear(); this.drafts.clear(); this.page = 'sessions'; }
    catch (error) { this.status = (error as Error).message; }
  }

  private async attach(retry: boolean): Promise<void> {
    this.busy = true;
    try {
      if (retry) await this.picker.retry(); else await this.picker.choose();
      this.attachmentName = client.attachment?.name || '';
      this.status = '附件已上传，发送指令时附带';
    } catch (error) { this.status = (error as Error).message || '附件选择失败，请重试'; }
    finally { this.busy = false; }
  }

  private async acknowledge(): Promise<void> {
    try { await client.acknowledgeUnknown(); }
    catch (error) { this.status = (error as Error).message; }
  }

  private async copy(value: string): Promise<void> {
    try { await pasteboard.getSystemPasteboard().setData(pasteboard.createData(pasteboard.MIMETYPE_TEXT_PLAIN, value)); }
    catch (_) { this.status = '复制失败'; }
  }

  onBackPress(): boolean {
    if (this.panelOpen) { this.panelOpen = false; return true; }
    if (this.page === 'chat') { this.page = 'sessions'; return true; }
    return false;
  }

  private projectOptions(): SelectOption[] {
    const all: SelectOption = { value: '所有项目' };
    return [all].concat(this.projects.map((p: Choice): SelectOption => { return { value: p.label }; }));
  }

  private openPanel(name: string): void { this.panel = name; this.panelOpen = true; }

  @Builder
  iconButton(icon: Resource, label: string, action: () => void) {
    Button({ type: ButtonType.Normal }) {
      Image(icon).width(21).height(21)
    }.width(44).height(44).backgroundColor(Color.Transparent).borderRadius(22)
      .accessibilityText(label).onClick(action)
  }

  @Builder
  emptyState(title: string, detail: string) {
    Column({ space: 8 }) {
      Text(title).fontSize(20).fontWeight(FontWeight.Medium).textAlign(TextAlign.Center)
      Text(detail).fontSize(14).fontColor($r('app.color.muted')).textAlign(TextAlign.Center)
    }.width('100%').padding(28)
  }

  @Builder
  panelContent() {
    Scroll() {
      Column({ space: 20 }) {
        if (this.panel === 'server') {
          Text('连接环境').fontSize(20).fontWeight(FontWeight.Medium).width('100%')
          Text('连接运行 T3 Code 的电脑或服务器。').fontSize(14).fontColor($r('app.color.muted')).width('100%')
          Column({ space: 8 }) {
            Text('服务器地址').fontSize(13).fontColor($r('app.color.muted')).width('100%')
            TextInput({ placeholder: 'https://your-server', text: this.address }).height(48).borderRadius(10)
              .accessibilityText('服务器地址').enabled(!this.busy && !this.ready)
              .onChange((value: string) => {
                if (value !== this.address) { this.address = value; this.threadId = ''; this.prompt = ''; this.messages = []; this.source.update([]); this.picker.clear(); }
              })
            if (!this.ready) {
              Text('配对凭据').fontSize(13).fontColor($r('app.color.muted')).width('100%')
              TextInput({ placeholder: '已有安全连接可留空', text: this.credential }).height(48).borderRadius(10)
                .type(InputType.Password).enableAutoFill(false).enabled(!this.busy)
                .onChange((value: string) => this.credential = value)
            }
          }.width('100%')
          Text(this.status).fontSize(13).fontColor($r('app.color.muted')).width('100%')
          if (this.server) { Text(this.server).fontSize(12).fontColor($r('app.color.muted')).width('100%') }
          if (!this.ready) {
            Button(this.busy ? '连接中…' : '连接').primaryButton().width('100%')
              .enabled(!this.busy && this.address.trim().length > 0).onClick(() => this.connect())
          } else {
            Button('断开连接').quietButton().width('100%').enabled(!this.busy).onClick(() => client.disconnect())
          }
          Button('删除本机连接').quietButton().fontColor($r('app.color.danger')).enabled(!this.busy && !!this.address)
            .onClick(() => {
              AlertDialog.show({ title: '删除本机连接？', message: '清除本机凭据、草稿和附件选择，保留服务器会话。',
                primaryButton: { value: '取消', action: () => {} },
                secondaryButton: { value: '删除', action: () => { void this.forget(); } } });
            })
        } else if (this.panel === 'new') {
          Text('新会话').fontSize(20).fontWeight(FontWeight.Medium).width('100%')
          Text('项目').fontSize(13).fontColor($r('app.color.muted')).width('100%')
          Select(this.projects.map((p: Choice) => { const option: SelectOption = { value: p.label }; return option; }))
            .value(this.projects.find((p: Choice) => p.id === this.projectId)?.label || '选择项目')
            .onSelect((index: number) => this.projectId = this.projects[index].id).width('100%').enabled(!this.busy)
          Text('模型').fontSize(13).fontColor($r('app.color.muted')).width('100%')
          Select(this.models.map((m: ModelChoice) => { const option: SelectOption = { value: m.label }; return option; }))
            .value(this.models[this.modelIndex]?.label || '选择模型').onSelect((index: number) => this.modelIndex = index)
            .width('100%').enabled(!this.busy)
          Text('模型用于本次新会话。').fontSize(12).fontColor($r('app.color.muted')).width('100%')
          Button(this.busy ? '创建中…' : '创建会话').primaryButton().width('100%')
            .enabled(this.ready && !this.busy && !this.unknown && !!this.projectId && this.models.length > 0).onClick(() => this.newThread())
          if (!this.ready || this.unknown) { Text(this.unknown ? '请先核对上次提交结果。' : '请先连接环境。').fontSize(13).width('100%') }
          Text(this.status).fontSize(12).fontColor($r('app.color.muted')).width('100%')
        } else {
          Text('会话操作').fontSize(20).fontWeight(FontWeight.Medium).width('100%')
          Button('同步会话').quietButton().width('100%').enabled(this.ready && !this.busy).onClick(() => this.watch(this.threadId))
          Button('停止任务').quietButton().width('100%').enabled(this.ready && !this.busy && !this.unknown).onClick(() => this.stop())
          Button('管理连接').quietButton().width('100%').onClick(() => this.panel = 'server')
          Text(this.status).fontSize(13).fontColor($r('app.color.muted')).width('100%')
        }
      }.padding({ left: 24, right: 24, top: 32, bottom: 32 }).width('100%').alignItems(HorizontalAlign.Start)
    }.width('100%').height('100%').align(Alignment.TopStart).backgroundColor($r('app.color.canvas')).foregroundColor($r('app.color.ink'))
  }

  @Builder
  sessionsPage() {
    if (this.threads.length === 0) {
      Column() {
        Blank()
        this.emptyState(this.ready ? '还没有会话' : '添加你的工作环境', this.ready ? '创建新会话，开始处理任务。' : '连接 T3 Code，在手机上继续工作。')
        Button(this.ready ? '新建会话' : '添加环境').primaryButton()
          .onClick(() => this.openPanel(this.ready ? 'new' : 'server'))
        Blank()
      }.layoutWeight(1).width('100%')
    } else {
      List({ space: 0 }) {
        ListItem() {
          Row() {
            Select(this.projectOptions())
              .value(this.projects.find((p: Choice) => p.id === this.projectId)?.label || '所有项目')
              .font({ size: 13 }).backgroundColor(Color.Transparent)
              .onSelect((index: number) => this.projectId = index === 0 ? '' : this.projects[index - 1].id)
            Blank()
            Text(this.ready ? '已连接' : '离线').fontSize(12).fontColor($r('app.color.muted'))
          }.padding({ left: 16, right: 20, bottom: 8 }).width('100%')
        }
        ForEach(this.threads.filter((t: Choice) => !this.projectId || t.projectId === this.projectId), (thread: Choice) => {
          ListItem() {
            Button({ type: ButtonType.Normal }) {
              Row({ space: 12 }) {
                Image($r('app.media.ui_folder')).width(18).height(18)
                Column({ space: 5 }) {
                  Text(thread.label).fontSize(15).fontWeight(FontWeight.Medium).maxLines(2).textOverflow({ overflow: TextOverflow.Ellipsis }).width('100%')
                  Text(this.projects.find((p: Choice) => p.id === thread.projectId)?.label || '项目')
                    .fontSize(12).fontColor($r('app.color.muted')).maxLines(1).width('100%')
                }.layoutWeight(1).alignItems(HorizontalAlign.Start)
                if (thread.id === this.threadId) { Text('•').fontColor($r('app.color.muted')).accessibilityText('当前会话') }
              }.padding({ left: 20, right: 20, top: 16, bottom: 16 })
            }.width('100%').backgroundColor(thread.id === this.threadId ? $r('app.color.surface') : Color.Transparent)
              .fontColor($r('app.color.ink')).borderRadius(0).enabled(!this.busy && (this.ready || thread.id === this.threadId))
              .onClick(() => { if (this.ready) { void this.watch(thread.id); } else { this.page = 'chat'; } })
          }
        }, (thread: Choice) => thread.id)
      }.layoutWeight(1).width('100%')
    }
  }

  @Builder
  chatPage() {
    List({ space: 24, scroller: this.scroller }) {
      if (!this.messages.length) {
        ListItem() { this.emptyState('开始对话', '描述你想完成的任务。') }
      }
      LazyForEach(this.source, (message: ChatMessage) => {
        ListItem() {
          Row() {
            if (message.role === 'user') { Blank().width('10%') }
            Column({ space: 10 }) {
              if (message.streaming) { Text('正在回复…').fontSize(12).fontColor($r('app.color.muted')).width('100%') }
              ForEach(message.attachmentNames || [], (name: string) => { Text('附件 · ' + name).fontSize(13).fontColor($r('app.color.muted')).width('100%') })
              ForEach(markdown(message.text), (block: MarkdownBlock) => {
                Column({ space: 8 }) {
                  if (block.kind === 'code') {
                    Row() {
                      Text('代码').fontSize(12).fontColor($r('app.color.muted'))
                      Blank()
                      Button('复制').quietButton().fontSize(12).onClick(() => this.copy(block.text))
                    }.width('100%')
                  }
                  Text(block.text).width('100%').copyOption(CopyOptions.InApp)
                    .fontFamily(block.kind === 'code' ? 'monospace' : 'sans-serif')
                    .fontSize(block.kind === 'heading' ? 20 : block.kind === 'code' ? 13 : 16)
                    .lineHeight(block.kind === 'heading' ? 28 : block.kind === 'code' ? 20 : 24)
                    .fontWeight(block.kind === 'heading' ? FontWeight.Medium : FontWeight.Normal)
                }.width('100%').padding(block.kind === 'code' ? 12 : 0)
                  .backgroundColor(block.kind === 'code' ? $r('app.color.surface') : Color.Transparent).borderRadius(12)
              })
            }.layoutWeight(1).padding(message.role === 'user' ? 14 : 0)
              .backgroundColor(message.role === 'user' ? $r('app.color.selected') : Color.Transparent).borderRadius(18)
          }.width('100%')
        }
      }, (message: ChatMessage) => JSON.stringify(message))
      if (this.tools.length > 0) {
        ListItem() {
          Button((this.showTools ? '⌄  ' : '›  ') + '工具活动 · ' + this.tools.length).quietButton().fontColor($r('app.color.muted'))
            .onClick(() => this.showTools = !this.showTools)
        }
        if (this.showTools) {
          ForEach(this.tools, (tool: string) => {
            ListItem() { Text(tool).fontSize(13).fontFamily('monospace').copyOption(CopyOptions.InApp).width('100%').padding(12)
              .backgroundColor($r('app.color.surface')).borderRadius(10) }
          })
        }
      }
      ForEach(this.actions, (card: ActionCard) => { ListItem() { RequestCard({ card }) } })
      if (this.unknown) {
        ListItem() {
          Column({ space: 10 }) {
            Text('核对上次提交').fontSize(15).fontWeight(FontWeight.Medium).width('100%')
            Text('同步原会话并核对结果后，才能再次发送。').fontSize(13).fontColor($r('app.color.muted')).width('100%')
            Button('同步会话').quietButton().enabled(this.ready && !this.busy).onClick(() => this.watch(this.threadId))
            Button('已核对提交结果').primaryButton().enabled(this.ready && !this.busy).onClick(() => this.acknowledge())
          }.padding(16).width('100%').border({ width: 1, color: $r('app.color.border') }).borderRadius(16)
        }
      }
    }.width('100%').layoutWeight(1).cachedCount(2).padding({ left: 20, right: 20, top: 16, bottom: 16 })
    Row() {
      if (this.unknown || this.actions.length) {
        Button(this.unknown ? '核对提交结果' : this.actions.length + ' 个请求待处理').quietButton().fontSize(12)
          .onClick((): void => { this.scroller.scrollEdge(Edge.Bottom); })
      }
      Blank()
      this.iconButton($r('app.media.ui_down'), '滚动到最新消息', (): void => { this.scroller.scrollEdge(Edge.Bottom); })
    }.width('100%').padding({ left: 12, right: 12 })
    Column({ space: 0 }) {
      if (this.attachmentName) {
        Text('附件 · ' + this.attachmentName).fontSize(12).fontColor($r('app.color.muted')).width('100%').padding({ left: 16, right: 16, top: 12 })
      }
      Row({ space: 4 }) {
        Button({ type: ButtonType.Normal }) {
          Image($r('app.media.ui_plus')).width(20).height(20)
        }.width(44).height(44).backgroundColor(Color.Transparent).borderRadius(22).accessibilityText('添加附件')
          .bindMenu([
            { value: '选择文件', action: () => { if (this.ready && !this.busy && !this.unknown) void this.attach(false); } },
            { value: '重试上传', action: () => { if (this.ready && !this.busy && !this.unknown) void this.attach(true); } },
            { value: '移除附件', action: () => { if (!this.busy && !this.unknown) { client.attachment = undefined; this.picker.clear(); this.attachmentName = ''; } } }
          ])
      TextArea({ placeholder: '发送消息…', text: this.prompt }).fontSize(15)
        .onChange((value: string) => this.prompt = value).height(this.prompt.length > 60 || this.prompt.includes('\n') ? 96 : 48).layoutWeight(1).padding({ left: 4, right: 4, top: 14, bottom: 10 })
        .backgroundColor(Color.Transparent).accessibilityText('消息输入框')
        if (this.busy) { LoadingProgress().width(20).height(20).color($r('app.color.muted')).accessibilityText('正在提交') }
        Button({ type: ButtonType.Circle }) {
          Image($r('app.media.ui_up')).width(20).height(20)
        }.width(44).height(44).margin(4).backgroundColor($r('app.color.accent')).accessibilityText('发送消息')
          .enabled(this.ready && !this.busy && !this.unknown && this.prompt.trim().length > 0).onClick(() => this.send())
      }.width('100%').padding({ left: 4, right: 4, top: 3, bottom: 3 }).alignItems(VerticalAlign.Bottom)
    }.width('100%').backgroundColor($r('app.color.composer')).borderRadius(27)
      .border({ width: 0.5, color: $r('app.color.border') }).margin({ bottom: 8 })
  }

  build() {
    Column() {
      Row({ space: 4 }) {
        if (this.page === 'chat') {
          this.iconButton($r('app.media.ui_back'), '返回会话列表', () => this.page = 'sessions')
          Column({ space: 2 }) {
            Text(this.threads.find((t: Choice) => t.id === this.threadId)?.label || '新会话').fontSize(16).fontWeight(FontWeight.Medium)
              .maxLines(1).textOverflow({ overflow: TextOverflow.Ellipsis }).width('100%')
            Text(this.projects.find((p: Choice) => p.id === this.projectId)?.label || 'T3 Code').fontSize(12).fontColor($r('app.color.muted'))
              .maxLines(1).width('100%')
          }.layoutWeight(1).alignItems(HorizontalAlign.Start)
          this.iconButton($r('app.media.ui_more'), '会话操作', () => this.openPanel('thread'))
        } else {
          Button({ type: ButtonType.Normal }) {
            Row({ space: 8 }) {
              Text('T3 Code').fontSize(21).fontWeight(FontWeight.Bold)
              Text('⌄').fontSize(16).fontColor($r('app.color.muted'))
            }
          }.height(48).backgroundColor(Color.Transparent).fontColor($r('app.color.ink')).accessibilityText('T3 Code，管理环境')
            .onClick(() => this.openPanel('server'))
          Blank()
          this.iconButton($r('app.media.ui_compose'), '新建会话', () => this.openPanel(this.ready ? 'new' : 'server'))
        }
      }.width('100%').height(56).padding({ left: 12, right: 12 })
      if (this.status !== '会话已同步' && this.status !== '已连接' && this.status !== '未连接') {
        Text(this.status).fontSize(12).fontColor($r('app.color.muted')).maxLines(2).textOverflow({ overflow: TextOverflow.Ellipsis })
          .width('100%').padding({ left: 20, right: 20, bottom: 6 }).accessibilityText('状态：' + this.status)
          .onClick(() => this.openPanel(this.page === 'chat' ? 'thread' : 'server'))
      }
      if (this.page === 'chat') { this.chatPage() } else { this.sessionsPage() }
    }.width('100%').height('100%').padding({ left: 8, right: 8 })
      .backgroundColor($r('app.color.canvas')).foregroundColor($r('app.color.ink'))
      .bindSheet($$this.panelOpen, this.panelContent(), { height: this.panel === 'thread' ? '45%' : '70%', showClose: true, backgroundColor: $r('app.color.canvas') })
  }
}
