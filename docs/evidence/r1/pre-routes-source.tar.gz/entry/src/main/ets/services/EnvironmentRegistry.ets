import { util } from '@kit.ArkTS';
import { T3Client } from './T3Client';
import { SessionStore } from '../storage/SessionStore';
import { EnvironmentStore, ProtectedEnvironmentAssets } from '../storage/EnvironmentStore';
import { EnvironmentDirectory, EnvironmentEntry, EnvironmentAssets, RecoveryReference, environmentDirectory, migrateLegacy, savedSession, pullRequestRoutingAllowed } from '../protocol/Environment';
import { RecoveryState, RecoveryStorage, SessionStorage, recoveryState, SavedSession } from '../protocol/Core';
import { pairingTarget } from '../protocol/Pairing';

class ScopedRecovery implements RecoveryStorage {
  private registry: EnvironmentRegistry;
  private localId: string;
  constructor(registry: EnvironmentRegistry, localId: string) { this.registry = registry; this.localId = localId; }
  async load(): Promise<RecoveryState | undefined> {
    const entry = this.registry.entry(this.localId);
    const ref = entry.recovery[0];
    return ref ? this.registry.assets.recovery(ref.alias).load() : undefined;
  }
  async save(value: RecoveryState): Promise<void> { await this.registry.saveRecovery(this.localId, value); }
  async clear(): Promise<void> { throw new Error('恢复记录仅能随已核对的环境移除'); }
}

export class EnvironmentRegistry {
  directory: EnvironmentDirectory = { schemaVersion: 2, generation: 0, selectedLocalId: '', entries: [] };
  clients: Map<string, T3Client> = new Map();
  assets: EnvironmentAssets;
  private legacySession: SessionStorage;
  private legacyRecovery: RecoveryStorage;
  onUpdate: () => void = () => {};
  initialized: boolean = false;
  private store: EnvironmentStore;
  private writes: Promise<void> = Promise.resolve();
  constructor(filesDir: string, assets: EnvironmentAssets = new ProtectedEnvironmentAssets(),
    legacySession: SessionStorage = new SessionStore(),
    legacyRecovery: RecoveryStorage = new SessionStore<RecoveryState>('t3-harmony-recovery-v1')) {
    this.store = new EnvironmentStore(filesDir); this.assets = assets;
    this.legacySession = legacySession; this.legacyRecovery = legacyRecovery;
  }
  private write(action: () => Promise<void>): Promise<void> {
    const result = this.writes.then(action);
    this.writes = result.catch(() => {});
    return result;
  }
  private notify(): void {
    // UI failures must never turn a committed directory into a credential rollback.
    try { this.onUpdate(); } catch (_) {}
  }
  private copy(): EnvironmentDirectory { return environmentDirectory(JSON.parse(JSON.stringify(this.directory)) as Object); }
  private async commit(next: EnvironmentDirectory): Promise<void> {
    next.generation = this.directory.generation + 1;
    await this.store.save(next);
    this.directory = next;
    this.notify();
  }
  entry(localId: string): EnvironmentEntry {
    const entry = this.directory.entries.find((e: EnvironmentEntry) => e.localId === localId);
    if (!entry || entry.deleting || entry.pendingBase) throw new Error('环境不存在或正在移除');
    return entry;
  }
  async initialize(): Promise<void> {
    this.directory = await migrateLegacy(this.store, this.assets, this.legacySession, this.legacyRecovery);
    for (const entry of this.directory.entries.slice()) {
      if (entry.deleting) await this.finishRemoval(entry.localId);
      else {
        if (entry.pendingBase) await this.finishEdit(entry.localId);
        this.bind(this.entry(entry.localId));
      }
    }
    this.initialized = true;
  }
  private bind(entry: EnvironmentEntry): T3Client {
    const client = new T3Client();
    client.expectedEnvironmentId = entry.environmentId;
    client.store = this.assets.session(entry.credentialRef);
    client.recoveryStore = new ScopedRecovery(this, entry.localId);
    client.onUpdate = () => this.notify();
    this.clients.set(entry.localId, client);
    return client;
  }
  async saveRecovery(localId: string, value: RecoveryState): Promise<void> {
    await this.write(async () => {
      const entry = this.entry(localId);
      const checked = recoveryState(value, entry.base, entry.environmentId);
      if (!checked.threadId) throw new Error('恢复会话标识无效');
      const ref = entry.recovery.find((r) => r.threadId === checked.threadId);
      const alias = ref?.alias || 't3-v2-' + localId + '-recovery-' + util.generateRandomUUID();
      await this.assets.recovery(alias).save(checked);
      const next = this.copy();
      const target = next.entries.find((e: EnvironmentEntry) => e.localId === localId) as EnvironmentEntry;
      const reference: RecoveryReference = { threadId: checked.threadId, alias };
      target.recovery = [reference].concat(target.recovery.filter((r) => r.threadId !== checked.threadId));
      await this.commit(next);
    });
  }
  async add(input: string, code: string): Promise<string> {
    let added = '';
    await this.write(async () => {
      const target = pairingTarget(input, code);
      const known = this.directory.entries.find((e: EnvironmentEntry) => e.base === target.base);
      if (known) {
        const entry = this.entry(known.localId);
        const client = this.clients.get(entry.localId);
        if (!client) throw new Error('环境尚未初始化');
        // A known address may refresh its credential; its pinned identity and recovery aliases stay intact.
        await client.connect(entry.base, target.code);
        if (!client.ready) throw new Error(client.status);
        if (!entry.enabled || this.directory.selectedLocalId !== entry.localId) {
          const next = this.copy();
          const restored = next.entries.find((e: EnvironmentEntry) => e.localId === entry.localId) as EnvironmentEntry;
          restored.enabled = true; next.selectedLocalId = entry.localId;
          try { await this.commit(next); } catch (error) { client.disconnect('连接记录保存失败，请重试'); throw error as Error; }
        }
        added = entry.localId; return;
      }
      const localId = util.generateRandomUUID();
      const client = new T3Client();
      const credentialRef = 't3-v2-' + localId + '-session';
      const store = this.assets.session(credentialRef);
      client.store = store;
      client.validateIdentity = (environmentId: string) => {
        if (this.directory.entries.some((e: EnvironmentEntry) => e.environmentId === environmentId)) {
          throw new Error('该环境已添加，请使用已有地址更新配对；更改地址须从已有环境设置操作');
        }
      };
      try {
        await client.connect(target.base, target.code);
        if (!client.ready) throw new Error(client.status);
        const saved = savedSession(await store.load() as SavedSession);
        const entry: EnvironmentEntry = { localId, environmentId: saved.environmentId, base: saved.base,
          label: client.environmentLabel || client.server, enabled: true, kind: 'bearer', credentialRef, recovery: [] };
        const next = this.copy(); next.entries.push(entry); next.selectedLocalId = localId;
        this.clients.set(localId, client);
        await this.commit(next);
        client.validateIdentity = () => {};
        client.expectedEnvironmentId = entry.environmentId;
        client.recoveryStore = new ScopedRecovery(this, localId);
        client.onUpdate = () => this.notify();
        this.clients.set(localId, client);
        added = localId;
      } catch (error) {
        client.disconnect(); this.clients.delete(localId); await store.clear(); throw error as Error;
      }
    });
    this.notify();
    return added;
  }
  async select(localId: string): Promise<void> {
    await this.write(async () => {
      this.entry(localId);
      if (this.directory.selectedLocalId === localId) return;
      const next = this.copy(); next.selectedLocalId = localId; await this.commit(next);
    });
  }
  async setEnabled(localId: string, enabled: boolean): Promise<void> {
    await this.write(async () => {
      this.entry(localId);
      const next = this.copy();
      const entry = next.entries.find((e: EnvironmentEntry) => e.localId === localId) as EnvironmentEntry;
      entry.enabled = enabled; await this.commit(next);
      if (!enabled) this.clients.get(localId)?.disconnect('环境已停用，服务端任务继续');
    });
    if (enabled) await this.reconnect(localId);
  }
  async reconnect(localId: string, code: string = ''): Promise<void> {
    const entry = this.entry(localId);
    if (!entry.enabled) throw new Error('请先启用环境');
    const client = this.clients.get(localId);
    if (!client) throw new Error('环境尚未初始化');
    await client.connect(entry.base, code);
    if (!client.ready) throw new Error(client.status);
  }
  async edit(localId: string, label: string, address: string): Promise<void> {
    let reconnect = false;
    await this.write(async () => {
      const entry = this.entry(localId);
      const target = pairingTarget(address);
      if (target.code || !label.trim() || label.trim().length > 256) throw new Error('名称或 URL 无效；URL 不应包含配对码');
      const client = this.clients.get(localId);
      if (!client || client.mutationPending) throw new Error('请先核对正在提交或结果未知的请求');
      if (target.base !== entry.base) {
        client.disconnect('正在验证环境地址');
        for (const ref of entry.recovery) {
          const value = await this.assets.recovery(ref.alias).load();
          if (!value || recoveryState(value, entry.base, entry.environmentId).pendingId) throw new Error('请先核对所有未知提交');
        }
        await client.verifyIdentity(target.base);
      }
      const next = this.copy();
      const edited = next.entries.find((e: EnvironmentEntry) => e.localId === localId) as EnvironmentEntry;
      edited.label = label.trim();
      if (target.base !== entry.base) {
        edited.pendingBase = target.base;
        edited.prRouting = undefined; // A changed endpoint revokes client-side PR trust before credentials move.
      }
      await this.commit(next);
      if (edited.pendingBase) { await this.finishEdit(localId); reconnect = edited.enabled; }
    });
    if (reconnect) await this.reconnect(localId);
  }
  private async finishEdit(localId: string): Promise<void> {
    const entry = this.directory.entries.find((e: EnvironmentEntry) => e.localId === localId);
    if (!entry?.pendingBase) throw new Error('没有待完成的地址更新');
    const session = await this.assets.session(entry.credentialRef).load();
    if (!session || session.environmentId !== entry.environmentId || (session.base !== entry.base && session.base !== entry.pendingBase)) {
      throw new Error('地址更新凭据身份不一致');
    }
    const checked = savedSession(session); checked.base = entry.pendingBase;
    await this.assets.session(entry.credentialRef).save(checked);
    for (const ref of entry.recovery) {
      const value = await this.assets.recovery(ref.alias).load();
      if (!value || (value.base !== entry.base && value.base !== entry.pendingBase)) throw new Error('地址更新恢复记录不一致');
      const state = recoveryState(value, value.base, entry.environmentId);
      if (state.pendingId || state.threadId !== ref.threadId) throw new Error('地址更新存在未核对提交');
      state.base = entry.pendingBase; await this.assets.recovery(ref.alias).save(state);
    }
    const next = this.copy();
    const edited = next.entries.find((e: EnvironmentEntry) => e.localId === localId) as EnvironmentEntry;
    edited.base = entry.pendingBase; edited.pendingBase = undefined;
    await this.commit(next);
  }
  async setPullRequestRouting(localId: string, permission: string): Promise<void> {
    await this.write(async () => {
      if (!this.initialized || !['off', 'read', 'read-write'].includes(permission)) throw new Error('PR 路由设置无效或环境目录未就绪');
      this.entry(localId);
      const next = this.copy();
      const entry = next.entries.find((e: EnvironmentEntry) => e.localId === localId) as EnvironmentEntry;
      entry.prRouting = permission === 'off' ? undefined : permission;
      await this.commit(next);
    });
  }
  canRoutePullRequest(originId: string, targetId: string, write: boolean): boolean {
    return this.initialized && pullRequestRoutingAllowed(this.directory, originId, targetId, write);
  }
  async remove(localId: string): Promise<void> {
    await this.write(async () => {
      const entry = this.entry(localId);
      const client = this.clients.get(localId);
      if (client?.mutationPending) throw new Error('请先核对正在提交或结果未知的请求');
      client?.disconnect('正在核对本机环境移除条件');
      // Read every thread, including a non-selected unknown submission, before any destructive step.
      for (const ref of entry.recovery) {
        const state = await this.assets.recovery(ref.alias).load();
        if (!state || recoveryState(state, entry.base, entry.environmentId).pendingId) {
          throw new Error('请先同步原会话并核对未知提交，未移除环境');
        }
      }
      this.clients.get(localId)?.disconnect('正在移除本机环境');
      const next = this.copy();
      const target = next.entries.find((e: EnvironmentEntry) => e.localId === localId) as EnvironmentEntry;
      target.enabled = false; target.deleting = true;
      await this.commit(next); await this.finishRemoval(localId);
    });
  }
  private async finishRemoval(localId: string): Promise<void> {
    const entry = this.directory.entries.find((e: EnvironmentEntry) => e.localId === localId);
    if (!entry?.deleting) throw new Error('环境未进入移除状态');
    for (const ref of entry.recovery) await this.assets.recovery(ref.alias).clear();
    await this.assets.session(entry.credentialRef).clear();
    if (localId === 'legacy-v1') {
      await this.legacySession.clear();
      await this.legacyRecovery.clear();
    }
    this.clients.delete(localId);
    const next = this.copy(); next.entries = next.entries.filter((e: EnvironmentEntry) => e.localId !== localId);
    if (next.selectedLocalId === localId) next.selectedLocalId = next.entries.find((e: EnvironmentEntry) => !e.deleting)?.localId || '';
    await this.commit(next);
  }
  suspend(): void { this.clients.forEach((client: T3Client) => client.suspend()); }
  async resume(): Promise<void> {
    for (const entry of this.directory.entries) {
      if (entry.enabled && !entry.deleting) await this.clients.get(entry.localId)?.resume();
    }
  }
}

export let environments: EnvironmentRegistry | undefined = undefined;
export function prepareEnvironments(filesDir: string): void {
  environments?.suspend();
  environments = new EnvironmentRegistry(filesDir);
}
