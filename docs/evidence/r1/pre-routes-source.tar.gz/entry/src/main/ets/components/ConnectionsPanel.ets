import { LinkedEnvironmentsSection, LinkedEnvironmentGroup } from './LinkedEnvironmentsSection';
import { PullRequestRoutingSettings } from './PullRequestRoutingSettings';
import { EnvironmentEntry } from '../protocol/Environment';

@Component
export struct ConnectionsPanel {
  @Prop entries: EnvironmentEntry[] = [];
  @Prop statuses: Record<string, string> = {};
  @Prop linkedGroups: LinkedEnvironmentGroup[] = [];
  @Prop initialized: boolean = false;
  @State expanded: string = '';
  @State label: string = '';
  @State address: string = '';
  @State busy: boolean = false;
  @State error: string = '';
  onClose: () => void = () => {};
  onAdd: () => void = () => {};
  onInitialize: () => Promise<void> = async () => {};
  onRetry: (id: string) => Promise<void> = async () => {};
  onEnabled: (id: string, enabled: boolean) => Promise<void> = async () => {};
  onEdit: (id: string, label: string, address: string) => Promise<void> = async () => {};
  onRouting: (localId: string, permission: string) => Promise<void> = async () => {};
  onRemove: (id: string) => Promise<void> = async () => {};
  private async perform(action: () => Promise<void>): Promise<void> {
    if (this.busy) return;
    this.busy = true; this.error = '';
    try { await action(); } catch (error) { this.error = (error as Error).message; }
    finally { this.busy = false; }
  }
  private expand(entry: EnvironmentEntry): void {
    this.expanded = this.expanded === entry.localId ? '' : entry.localId;
    this.label = entry.label; this.address = entry.base; this.error = '';
  }
  build() {
    Column({ space: 16 }) {
      Row({ space: 8 }) {
        Button('×').width(44).height(44).backgroundColor(Color.Transparent).fontColor($r('app.color.ink'))
          .accessibilityText('关闭环境').onClick(this.onClose)
        Text('环境').fontSize(20).fontWeight(FontWeight.Medium)
        Blank()
        Button('+').fontSize(24).backgroundColor(Color.Transparent).fontColor($r('app.color.ink'))
          .width(44).height(44).accessibilityText('添加环境').enabled(this.initialized && !this.busy).onClick(this.onAdd)
      }.width('100%')
      Scroll() {
        Column({ space: 16 }) {
      if (!this.initialized) {
        Text('连接记录未加载，请解锁后重试。').fontSize(14).fontColor($r('app.color.muted')).width('100%')
        Button('重试加载').enabled(!this.busy).onClick(() => this.perform(this.onInitialize))
      } else if (!this.entries.length) {
        Text('还没有添加环境').fontSize(15).fontColor($r('app.color.muted')).width('100%')
      }
      ForEach(this.entries.filter((e: EnvironmentEntry) => !e.deleting), (entry: EnvironmentEntry) => {
        Column({ space: 12 }) {
          Row({ space: 8 }) {
            Button({ type: ButtonType.Normal }) {
              Column({ space: 4 }) {
                Text(entry.label).fontSize(16).fontWeight(FontWeight.Medium).maxLines(1).textOverflow({ overflow: TextOverflow.Ellipsis }).width('100%')
                Text(entry.base).fontSize(12).fontColor($r('app.color.muted')).width('100%')
                Text(entry.enabled ? (this.statuses[entry.localId] || '未连接') : '已停用')
                  .fontSize(12).fontColor($r('app.color.muted')).width('100%')
              }.alignItems(HorizontalAlign.Start)
            }.layoutWeight(1).backgroundColor(Color.Transparent).fontColor($r('app.color.ink'))
              .padding(0).enabled(!this.busy).accessibilityText('管理 ' + entry.label).onClick(() => this.expand(entry))
            Toggle({ type: ToggleType.Switch, isOn: entry.enabled }).enabled(!this.busy)
              .accessibilityText('启用 ' + entry.label).onChange((enabled: boolean) => { if (enabled !== entry.enabled) void this.perform(() => this.onEnabled(entry.localId, enabled)); })
            Button(this.expanded === entry.localId ? '⌃' : '⌄').width(44).height(44).backgroundColor(Color.Transparent)
              .fontColor($r('app.color.ink')).enabled(!this.busy).accessibilityText('展开环境详情').onClick(() => this.expand(entry))
          }.width('100%')
          if (this.expanded === entry.localId) {
            Text('名称').fontSize(13).fontColor($r('app.color.muted')).width('100%')
            TextInput({ text: this.label, placeholder: '我的电脑' }).enabled(!this.busy).onChange((v: string) => this.label = v)
            Text('URL').fontSize(13).fontColor($r('app.color.muted')).width('100%')
            TextInput({ text: this.address, placeholder: 'https://your-server' }).enabled(!this.busy).onChange((v: string) => this.address = v)
            Row({ space: 8 }) {
              Button('保存').enabled(!this.busy && !!this.label.trim() && !!this.address.trim())
                .onClick(() => this.perform(async () => { await this.onEdit(entry.localId, this.label, this.address); this.expanded = ''; }))
              Button('重试').enabled(!this.busy && entry.enabled).onClick(() => this.perform(() => this.onRetry(entry.localId)))
              Button('移除').enabled(!this.busy).backgroundColor(Color.Transparent).fontColor($r('app.color.danger'))
                .onClick(() => AlertDialog.show({ title: '移除环境？', message: '移除本机连接与该环境的本机数据，服务端任务继续。',
                  primaryButton: { value: '取消', action: () => {} },
                  secondaryButton: { value: '移除', action: () => { void this.perform(() => this.onRemove(entry.localId)); } } }))
            }.width('100%')
          }
        }.width('100%').padding(16).backgroundColor($r('app.color.surface')).borderRadius(12)
      }, (entry: EnvironmentEntry) => entry.localId)
      LinkedEnvironmentsSection({ groups: this.linkedGroups })
      PullRequestRoutingSettings({ entries: this.entries, initialized: this.initialized, onChange: this.onRouting })
      if (this.error) { Text(this.error).fontSize(13).fontColor($r('app.color.danger')).width('100%') }
        }.width('100%').alignItems(HorizontalAlign.Start)
      }.width('100%').layoutWeight(1)
    }.width('100%').height('100%').alignItems(HorizontalAlign.Start)
  }
}
