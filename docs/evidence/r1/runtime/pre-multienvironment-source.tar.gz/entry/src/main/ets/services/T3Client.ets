import { http, webSocket } from '@kit.NetworkKit';
import { util } from '@kit.ArkTS';
import { BusinessError } from '@kit.BasicServicesKit';
import { bootstrapForm, createThread, record, RpcClient, RpcSender, sendMessage,
  serverBase, socketUrl, text, ThreadState, validateDescriptor } from '../protocol/Wire';

import { ShellState, ModelChoice, models, SavedSession, SessionStorage, stopCommand, secretAnswer, respondCommand, RecoveryState, RecoveryStorage, recoveryState, Attachment, uploadTarget } from '../protocol/Core';

class NativeSender implements RpcSender {
  private socket: webSocket.WebSocket;
  constructor(socket: webSocket.WebSocket) { this.socket = socket; }
  async send(frame: string): Promise<void> {
    try {
      if (!await this.socket.send(frame)) throw new Error('发送失败');
    } catch (_) {
      throw new Error('发送失败');
    }
  }
}

class HttpFailure extends Error {
  status: number;
  constructor(status: number) {
    super(status === 401 || status === 403 ? '鉴权失败或权限不足，请检查配对凭据' :
      status === 426 ? '服务端协议不兼容' : 'HTTP 请求失败（' + status + '）');
    this.status = status;
  }
}

export class T3Client {
  status: string = '未连接';
  server: string = '';
  ready: boolean = false;
  thread: ThreadState | undefined = undefined;
  onUpdate: () => void = () => {};
  private socket: webSocket.WebSocket | undefined = undefined;
  private rpc: RpcClient | undefined = undefined;
  private timer: number = 0;
  private lastInbound: number = 0;
  private generation: number = 0;
  private threadChunk: ((value: Object) => void) | undefined = undefined;
  store: SessionStorage | undefined = undefined;
  shell: ShellState = new ShellState();
  models: ModelChoice[] = [];
  private saved: SavedSession | undefined = undefined;
  recoveryStore: RecoveryStorage | undefined = undefined;
  recovery: RecoveryState | undefined = undefined;
  private mutating: boolean = false;
  private reconciled: boolean = false;
  private resumeWanted: boolean = false;
  private retryTimer: number = 0;
  private retryDelay: number = 1000;
  private notifyTimer: number = 0;

  private notify(): void {
    if (this.notifyTimer) return;
    this.notifyTimer = setTimeout(() => { this.notifyTimer = 0; this.onUpdate(); }, 50);
  }

  suspend(): void {
    const wanted = this.resumeWanted;
    this.disconnect('后台已暂停连接，任务在服务端继续');
    this.resumeWanted = wanted;
  }

  async resume(): Promise<void> {
    if (!this.resumeWanted || this.ready) return;
    const saved = this.store ? await this.store.load() : this.saved;
    if (saved && saved.expiresAt > Date.now()) await this.connect(saved.base);
  }

  private retry(): void {
    if (!this.resumeWanted || !this.saved || this.saved.expiresAt <= Date.now()) return;
    this.retryTimer = setTimeout(() => {
      this.retryTimer = 0;
      void this.resume().catch(() => { this.status = '请解锁后安全重连'; this.onUpdate(); });
    }, this.retryDelay);
    this.retryDelay = Math.min(this.retryDelay * 2, 30000);
  }

  private async saveRecovery(): Promise<void> {
    if (this.recovery && this.recoveryStore) await this.recoveryStore.save(this.recovery);
  }

  async acknowledgeUnknown(): Promise<void> {
    if (this.mutating || !this.reconciled || !this.recovery) throw new Error('请先同步原会话并核对结果');
    const pending = this.recovery;
    this.recovery = { base: pending.base, environmentId: pending.environmentId, threadId: pending.threadId, pendingId: '', pendingKind: '' };
    try { await this.saveRecovery(); } catch (error) { this.recovery = pending; throw error as Error; }
    this.status = '已确认核对，允许手动提交新请求'; this.onUpdate();
  }

  private async mutate(method: string, payload: Object, id: string, kind: string): Promise<void> {
    const rpc = this.requireRpc();
    if (this.mutating || this.recovery?.pendingId) throw new Error('上次提交结果未知，请同步原会话并核对结果');
    if (!this.recovery) throw new Error('请先选择会话');
    this.mutating = true;
    this.reconciled = false;
    this.recovery.pendingId = id; this.recovery.pendingKind = kind;
    try {
      await this.saveRecovery(); // Commit the marker before any modifying request leaves the device.
      if (rpc !== this.rpc) throw new Error('连接已变更，请同步原会话核对');
      await rpc.request(method, payload);
      const pending = this.recovery;
      this.recovery = { base: pending.base, environmentId: pending.environmentId, threadId: pending.threadId, pendingId: '', pendingKind: '' };
      try { await this.saveRecovery(); } catch (error) { this.recovery = pending; throw error as Error; }
    } finally { this.mutating = false; this.onUpdate(); }
  }
  attachment: Attachment | undefined = undefined;
  private attachmentThread: string = '';
  recoveredMessageId: string = '';

  private async httpJson(base: string, path: string, method: http.RequestMethod,
    body: string = '', token: string = ''): Promise<Object> {
    const request = http.createHttp();
    try {
      const headers: Record<string, string> = { 'Accept': 'application/json' };
      if (token) headers['Authorization'] = 'Bearer ' + token;
      if (body) headers['Content-Type'] = 'application/x-www-form-urlencoded';
      const options: http.HttpRequestOptions = {
        method, header: headers, connectTimeout: 10000, readTimeout: 10000,
        usingCache: false, maxRedirects: 0, expectDataType: http.HttpDataType.STRING
      };
      // NetworkKit rejects an explicitly empty POST extraData with parameter error 401.
      if (body) options.extraData = body;
      const response = await request.request(base + path, options);
      if (response.responseCode < 200 || response.responseCode >= 300) throw new HttpFailure(response.responseCode);
      return JSON.parse(response.result as string) as Object;
    } catch (error) {
      if (error instanceof HttpFailure) throw error as Error;
      const code = (error as BusinessError).code;
      const detail = typeof code === 'number' ? '，系统错误码 ' + code : '，响应格式无效';
      throw new Error('HTTP ' + path + ' 失败' + detail);
    } finally {
      request.destroy();
    }
  }

  async connect(address: string, credential: string = ''): Promise<void> {
    this.disconnect();
    this.resumeWanted = true;
    const generation = this.generation;
    const base = serverBase(address);
    this.server = '';
    this.status = '正在鉴权';
    this.onUpdate();
    try {
      const descriptor = validateDescriptor(await this.httpJson(base, '/.well-known/t3/environment', http.RequestMethod.GET));
      if (generation !== this.generation) return;
      const environmentId = text(descriptor.environmentId);
      this.server = text(descriptor.label) + ' · ' + text(descriptor.serverVersion);
      let saved = this.store ? await this.store.load() : this.saved;
      if (generation !== this.generation) return;
      if (credential.trim()) {
        const auth = record(await this.httpJson(base, '/oauth/token', http.RequestMethod.POST, bootstrapForm(credential)));
        if (generation !== this.generation) return;
        if (auth.token_type !== 'Bearer') throw new Error('该服务要求 DPoP，当前仅支持直连 Bearer 鉴权');
        if (typeof auth.expires_in !== 'number' || auth.expires_in <= 0) throw new Error('无效凭据有效期');
        saved = { base, environmentId, token: text(auth.access_token), expiresAt: Date.now() + auth.expires_in * 1000 };
      }
      if (!saved || saved.base !== base || saved.environmentId !== environmentId || saved.expiresAt <= Date.now()) {
        throw new Error('没有此服务器的有效会话，请输入新配对凭据');
      }
      const token = saved.token;
      let ticket: Object;
      try {
        ticket = await this.httpJson(base, '/api/auth/websocket-ticket/rpc', http.RequestMethod.POST, '', token);
      } catch (error) {
        if (generation !== this.generation) return;
        if (!(error instanceof HttpFailure) || error.status !== 404) throw error as Error;
        ticket = await this.httpJson(base, '/api/auth/websocket-ticket', http.RequestMethod.POST, '', token);
      }
      if (generation !== this.generation) return;
      const socket = webSocket.createWebSocket();
      const rpc = new RpcClient(new NativeSender(socket));
      this.socket = socket;
      this.rpc = rpc;
      this.lastInbound = Date.now();
      rpc.onFailure = (message: string) => {
        if (generation !== this.generation) return;
        this.disconnect(message, true);
      };
      socket.on('message', (error, data: string | ArrayBuffer) => {
        if (generation !== this.generation) return;
        if ((error && error.code !== 0) || typeof data !== 'string') {
          rpc.fail('收到无效 WebSocket 消息');
          return;
        }
        this.lastInbound = Date.now();
        rpc.receive(data);
      });
      socket.on('error', () => rpc.fail('WebSocket 连接失败或中断；提交中的请求结果未知，请重连并核对会话'));
      socket.on('close', () => rpc.fail('连接已断开；提交中的任务结果未知，请重连并同步会话'));
      this.status = '正在连接与校验服务器';
      this.onUpdate();
      try {
        if (!await socket.connect(socketUrl(base, text(record(ticket).ticket)))) throw new Error('连接失败');
      } catch (_) {
        throw new Error('WebSocket 连接失败，请检查网络和服务端版本');
      }
      if (generation !== this.generation) return;
      this.timer = setInterval(() => {
        if (Date.now() - this.lastInbound > 15000) rpc.fail('服务端响应超时；请重连并核对任务状态');
        else rpc.ping();
      }, 5000);
      const config = record(await rpc.request('server.getConfig', {}));
      if (text(record(config.environment).environmentId) !== environmentId) throw new Error('服务器身份不一致，已中止连接');
      if (generation !== this.generation) return;
      this.models = config.providers ? models(config) : [];
      if (this.store) await this.store.save(saved);
      if (generation !== this.generation) return;
      this.saved = saved;
      const recovery = this.recoveryStore ? await this.recoveryStore.load() : this.recovery;
      if (generation !== this.generation) return;
      this.recovery = recovery ? recoveryState(recovery, base, environmentId) : undefined;
      this.ready = true;
      this.subscribeShell();
      this.retryDelay = 1000;
      this.status = '已连接';
      this.onUpdate();
      if (this.recovery) await this.watch(this.recovery.threadId);
    } catch (error) {
      if (generation === this.generation) this.disconnect((error as Error).message,
        !!this.saved && ((error as Error).message.startsWith('HTTP ') || (error as Error).message.startsWith('WebSocket')));
    }
  }

  disconnect(message: string = '已断开；提交中的请求结果未知，请重连并同步会话', recover: boolean = false): void {
    this.resumeWanted = recover;
    clearTimeout(this.retryTimer); this.retryTimer = 0;
    clearTimeout(this.notifyTimer); this.notifyTimer = 0;
    this.generation++;
    this.ready = false;
    this.threadChunk = undefined;
    this.shell = new ShellState();
    this.models = [];
    this.thread = undefined;
    clearInterval(this.timer);
    this.timer = 0;
    const rpc = this.rpc;
    const socket = this.socket;
    this.rpc = undefined;
    this.socket = undefined;
    rpc?.fail(message);
    if (socket) void socket.close().catch(() => {});
    this.status = message;
    this.onUpdate();
    if (recover) this.retry();
  }

  async newThread(projectId: string, instanceId: string, model: string): Promise<string> {
    const rpc = this.requireRpc();
    if (this.mutating || this.recovery?.pendingId) throw new Error('请求正在提交，请稍候');
    const previousChunk = this.threadChunk;
    this.threadChunk = undefined;
    if (previousChunk) rpc.cancelStream(previousChunk);
    const threadId = util.generateRandomUUID();
    const command = createThread(util.generateRandomUUID(), threadId, projectId, instanceId, model);
    // Keep the allocated ID even if acknowledgement is lost, so the user can reconcile it.
    this.thread = new ThreadState(threadId);
    this.onUpdate();
    await this.selectRecovery(threadId);
    await this.mutate('orchestration.dispatchCommand', command, threadId, 'create');
    return threadId;
  }

  async watch(threadId: string): Promise<void> {
    if (!threadId.trim()) throw new Error('请输入会话 ID');
    const rpc = this.requireRpc();
    if (this.mutating) throw new Error('请求正在提交，请稍候');
    const previousChunk = this.threadChunk;
    this.threadChunk = undefined;
    if (previousChunk) rpc.cancelStream(previousChunk);
    this.recoveredMessageId = '';
    await this.selectRecovery(threadId.trim());
    if (rpc !== this.rpc) return;
    const state = new ThreadState(threadId.trim());
    this.thread = state;
    this.status = '正在同步会话';
    this.onUpdate();
    const chunk = (value: Object): void => {
      state.apply(value);
      this.status = state.notices || '会话已同步';
      if (record(value).kind === 'snapshot' && this.recovery?.pendingId && !this.mutating &&
        this.recovery.threadId === state.threadId) {
        this.reconciled = true;
        const found = this.recovery.pendingKind === 'message' && state.messages.some((m) => m.id === this.recovery?.pendingId);
        if (found) this.recoveredMessageId = this.recovery.pendingId;
        this.status = found ? '已核实上次指令已接收；请确认核对，不会重复发送' :
          '上次提交结果未知；已同步完整快照，请核对后确认，禁止自动重发';
      }
      this.notify();
    };
    this.threadChunk = chunk;
    void rpc.request('orchestration.subscribeThread', { threadId: state.threadId }, chunk).then(() => {
      if (this.threadChunk === chunk) this.disconnect('会话订阅已结束，请重新连接');
    }).catch((error: Error) => {
      if (this.rpc === rpc && this.threadChunk === chunk) this.disconnect(error.message, true);
    });
  }

  async send(prompt: string): Promise<void> {
    const rpc = this.requireRpc();
    if (!this.thread || this.thread.cursor < 0) throw new Error('请先同步会话');
    const threadId = this.thread.threadId;
    const messageId = util.generateRandomUUID();
    const command = record(sendMessage(util.generateRandomUUID(), threadId, messageId, prompt));
    if (this.attachment && this.attachmentThread === threadId) command.attachments = [this.attachment];

    this.status = '正在提交';
    this.onUpdate();
    await this.mutate('orchestration.dispatchCommand', command, messageId, 'message');
    this.attachment = undefined;
    this.status = '指令已确认，请等待回复';
    this.onUpdate();
  }

  private subscribeShell(): void {
    const rpc = this.requireRpc();
    void rpc.request('orchestration.subscribeShell', {}, (value: Object) => {
      this.shell.apply(value);
      this.onUpdate();
    }).catch(() => { if (this.rpc === rpc) this.disconnect('项目列表同步失败，请重新连接'); });
  }

  async forget(): Promise<void> {
    this.disconnect();
    this.saved = undefined;
    this.recovery = undefined;
    this.attachment = undefined;
    if (this.recoveryStore) await this.recoveryStore.clear();
    if (this.store) await this.store.clear();
  }

  async stop(): Promise<void> {
    if (!this.thread) throw new Error('请先选择会话');
    const id = util.generateRandomUUID();
    await this.mutate('orchestration.dispatchCommand', stopCommand(id, this.thread.threadId), id, 'stop');
  }

  async respond(requestId: string, decision: string, answers: Record<string, Object>): Promise<void> {
    if (!this.thread) throw new Error('请先选择会话');
    const request = this.thread.requests.find((row: Record<string, Object>) => row.id === requestId);
    if (!request || request.status !== 'pending' || record(request.responseCapability).type === 'not_resumable') {
      throw new Error('请求已失效，请同步状态');
    }
    const command = respondCommand(util.generateRandomUUID(), this.thread.threadId, requestId, decision, answers);
    await this.mutate('orchestration.dispatchCommand', command, requestId, 'response');
  }

  async secret(itemId: string, value: string, decline: boolean): Promise<void> {
    if (!this.thread) throw new Error('请先选择会话');
    const item = this.thread.items.find((row: Record<string, Object>) => row.id === itemId);
    if (!item || item.type !== 'secret_request' || item.secretStatus !== 'pending') throw new Error('敏感输入请求已失效');
    if (!decline && !value.trim()) throw new Error('请输入敏感值');
    await this.mutate('secrets.answerRequest', secretAnswer(this.thread.threadId, itemId, value, decline), itemId, 'secret');
  }

  async upload(name: string, bytes: ArrayBuffer): Promise<void> {
    const rpc = this.requireRpc();
    if (!this.thread || !this.saved || this.recovery?.pendingId) throw new Error('请先同步会话并核对未知提交');
    const threadId = this.thread.threadId;
    const base = this.saved.base;
    // Validate local metadata before requesting an upload capability.
    uploadTarget({ relativeUrl: '/api/attachments/upload/validation.token', attachmentId: 'validation', expiresAt: Date.now() + 1000 }, bytes.byteLength, name);
    const result = await rpc.request('attachments.createUploadUrl', { type: 'file', name,
      mimeType: 'application/octet-stream', sizeBytes: bytes.byteLength });
    const target = uploadTarget(result, bytes.byteLength, name);
    const request = http.createHttp();
    try {
      if (rpc !== this.rpc || threadId !== this.thread?.threadId) throw new Error('连接已变更，请重新选择附件');
      const response = await request.request(base + target.path, { method: http.RequestMethod.POST,
        header: { 'Content-Type': 'application/octet-stream' }, extraData: bytes,
        maxRedirects: 0, usingCache: false, connectTimeout: 10000, readTimeout: 60000 });
      if (response.responseCode !== 204) throw new Error('upload rejected');
      if (rpc !== this.rpc || threadId !== this.thread?.threadId) throw new Error('connection changed');
      this.attachment = target.attachment; this.attachmentThread = threadId;
    } catch (_) { throw new Error('附件上传未确认；可重新选择或手动重试，不会自动提交消息'); }
    finally { request.destroy(); }
  }

  private async selectRecovery(threadId: string): Promise<void> {
    if (!this.saved) throw new Error('请先连接服务器');
    if (this.recovery?.pendingId && this.recovery.threadId !== threadId) throw new Error('请先核对原会话的未知提交');
    if (this.recovery?.threadId === threadId) return;
    this.attachment = undefined;
    this.recovery = { base: this.saved.base, environmentId: this.saved.environmentId, threadId,
      pendingId: '', pendingKind: '' };
    await this.saveRecovery();
  }

  private requireRpc(): RpcClient {
    if (!this.ready || !this.rpc) throw new Error('请先连接服务器');
    return this.rpc;
  }
}

export const client = new T3Client();
