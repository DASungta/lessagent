import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
import { coreUrl } from './load-core.mjs';
const ts = createRequire(import.meta.url)((process.env.DEVECO_HOME || '/Applications/DevEco-Studio.app/Contents') + '/sdk/default/openharmony/ets/build-tools/ets-loader/node_modules/typescript');
const source = (await readFile(new URL('../entry/src/main/ets/protocol/Environment.ts', import.meta.url), 'utf8'))
 .replace("'./Core'", JSON.stringify(coreUrl)).replace("'./Wire'", JSON.stringify(new URL('../entry/src/main/ets/protocol/Wire.ts', import.meta.url).href));
const { environmentDirectory, savedSession, migrateLegacy } = await import('data:text/javascript;base64,' + Buffer.from(ts.transpileModule(source, {compilerOptions:{module:ts.ModuleKind.ES2022,target:ts.ScriptTarget.ES2022}}).outputText).toString('base64'));
const session = {base:'https://test',environmentId:'env',token:'SYNTHETIC',expiresAt:1};
const recovery = {base:session.base,environmentId:'env',threadId:'same-thread',pendingId:'unknown',pendingKind:'message'};
function store(value) { return {value, async load(){return structuredClone(this.value)}, async save(v){this.value=structuredClone(v)},async clear(){this.value=undefined}}; }
function setup(){
 const directory=store(),legacy=store(session),oldRecovery=store(recovery),records=new Map();
 const asset=alias=>{if(!records.has(alias))records.set(alias,store());return records.get(alias)};
 return {directory,legacy,oldRecovery,records,assets:{session:asset,recovery:asset},run(){return migrateLegacy(directory,this.assets,legacy,oldRecovery)}};
}
test('expired legacy session and unknown marker survive commit and idempotent restart',async()=>{
 const s=setup();const result=await s.run();assert.equal(result.entries.length,1);
 assert.deepEqual(s.legacy.value,session);assert.deepEqual(s.oldRecovery.value,recovery);
 assert.deepEqual(s.records.get(result.entries[0].credentialRef).value,session);
 assert.deepEqual(s.records.get(result.entries[0].recovery[0].alias).value,recovery);
 assert.deepEqual(await s.run(),result);assert.equal(s.records.size,2);
});
for(const point of ['directory-read','legacy-read','recovery-read','session-write','session-readback','recovery-write','recovery-readback','commit']) {
 test(`migration failure at ${point} preserves v1, retry commits one entry`,async()=>{
  const s=setup();let restore;
  function fail(target,method){const original=target[method];target[method]=async()=>{throw Error('injected')};restore=()=>target[method]=original;}
  if(point==='directory-read')fail(s.directory,'load');
  if(point==='legacy-read')fail(s.legacy,'load');
  if(point==='recovery-read')fail(s.oldRecovery,'load');
  if(point==='session-write')fail(s.assets.session('t3-v2-legacy-v1-session'),'save');
  if(point==='session-readback')fail(s.assets.session('t3-v2-legacy-v1-session'),'load');
  if(point==='recovery-write')fail(s.assets.recovery('t3-v2-legacy-v1-recovery-initial'),'save');
  if(point==='recovery-readback')fail(s.assets.recovery('t3-v2-legacy-v1-recovery-initial'),'load');
  if(point==='commit')fail(s.directory,'save');
  await assert.rejects(s.run());assert.equal(s.directory.value,undefined);
  assert.deepEqual(s.legacy.value,session);assert.deepEqual(s.oldRecovery.value,recovery);
  restore();const result=await s.run();assert.equal(result.entries.length,1);assert.equal(s.records.size,2);
 });
}
test('mismatched, orphan and malformed legacy records remain quarantined without activation',async()=>{
 for(const value of [{...recovery,environmentId:'other'},{...recovery,pendingKind:'future'}, {...recovery,threadId:''}]){
  const s=setup();s.oldRecovery.value=value;await assert.rejects(s.run());assert.equal(s.directory.value,undefined);assert.deepEqual(s.oldRecovery.value,value);
 }
 const s=setup();s.legacy.value=undefined;await assert.rejects(s.run());assert.deepEqual(s.oldRecovery.value,recovery);
 for(const value of [{...session,token:''},{...session,expiresAt:Infinity},{...session,base:'https://test/#token=secret'}])assert.throws(()=>savedSession(value));
});
test('incorrect readback cannot commit, including lost pending marker',async()=>{
 const s=setup();s.assets.recovery('t3-v2-legacy-v1-recovery-initial').load=async()=>({...recovery,pendingId:'',pendingKind:''});
 await assert.rejects(s.run(),/回读/);assert.equal(s.directory.value,undefined);assert.deepEqual(s.oldRecovery.value,recovery);
});
test('schema rejects secrets, duplicate identities, bad references, scope and selection',async()=>{
 const s=setup();const d=await s.run();const entry=d.entries[0];
 const bad=[{...d,token:'secret'},{...d,schemaVersion:3},{...d,generation:-1},{...d,selectedLocalId:'missing'},
 {...d,entries:[entry,entry]}, {...d,entries:[{...entry,credentialRef:'t3-harmony-session-v1'}]},
 {...d,entries:[{...entry,recovery:[{threadId:'t',alias:'t3-v2-other-recovery-x'}]}]},
 {...d,entries:[{...entry,base:'https://user:secret@test'}]}];
 for(const value of bad)assert.throws(()=>environmentDirectory(value));
 const other={...entry,localId:'other',environmentId:'other-env',credentialRef:'t3-v2-other-session',recovery:[{threadId:'same-thread',alias:'t3-v2-other-recovery-uuid'}]};
 assert.equal(environmentDirectory({...d,entries:[entry,other]}).entries.length,2);
});
test('empty committed directory suppresses legacy resurrection',async()=>{
 const s=setup();s.directory.value={schemaVersion:2,generation:2,selectedLocalId:'',entries:[]};
 assert.deepEqual(await s.run(),s.directory.value);assert.equal(s.records.size,0);
});
test('existing directory checks every protected reference; lock or missing records fail closed',async()=>{
 const s=setup();const d=await s.run();
 const r=s.assets.recovery(d.entries[0].recovery[0].alias);
 r.value={...recovery,pendingId:17};await assert.rejects(s.run());
 r.value=recovery;r.load=async()=>{throw Error('locked')};await assert.rejects(s.run(),/locked/);
 const a=s.assets.session(d.entries[0].credentialRef);a.value=undefined;await assert.rejects(s.run(),/缺失/);
 assert.deepEqual(s.directory.value,d);
});
test('JSON null and scalar corruption are never interpreted as missing records',async()=>{
 for(const value of [null, false, 0, '']) {
  const s=setup();s.legacy.value=value;await assert.rejects(s.run());assert.equal(s.directory.value,undefined);
  const r=setup();r.oldRecovery.value=value;await assert.rejects(r.run());assert.equal(r.directory.value,undefined);
  const d=setup();d.directory.value=value;await assert.rejects(d.run());assert.equal(d.directory.value,value);
 }
});
