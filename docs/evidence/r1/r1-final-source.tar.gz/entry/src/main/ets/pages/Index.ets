import { PeerLinkForm } from '../components/PeerLinkForm';
import { LinkMachine, linkReachableAddresses, linkOrigin } from '../protocol/LinkTarget';
import { LinkedEnvironmentGroup } from '../components/LinkedEnvironmentsSection';
import { takePairingLink } from '../services/PairingInbox';
import { pairingTarget } from '../protocol/Pairing';
import { AttachmentPicker } from '../services/AttachmentPicker';
import { client, bindClient, T3Client } from '../services/T3Client';
import { environments, EnvironmentRegistry } from '../services/EnvironmentRegistry';
import { EnvironmentEntry, environmentRoutes, DirectRoute } from '../protocol/Environment';
import { ConnectionsPanel } from '../components/ConnectionsPanel';
import { PairingScanCard } from '../components/PairingScanCard';
import { PairingTarget } from '../protocol/Pairing';
import { ChatMessage } from '../protocol/Wire';
import { Choice, ModelChoice, ActionCard, cards, markdown, MarkdownBlock, LinkRequestView, linkRequests, linkAccessChoices } from '../protocol/Core';
import { MessageSource } from '../components/MessageSource';
import { RequestCard } from '../components/RequestCard';
import { pasteboard } from '@kit.BasicServicesKit';

interface ScopedChoice extends Choice { localId: string; environmentLabel: string; projectLabel: string; }

@Extend(Button)
function quietButton() {
    .backgroundColor(Color.Transparent).fontColor($r('app.color.ink')).borderRadius(10)
    .fontSize(14).constraintSize({ minHeight: 44 }).padding({ left: 12, right: 12 })
  }

@Extend(Button)
function primaryButton() {
    .backgroundColor($r('app.color.accent')).fontColor($r('app.color.on_accent')).borderRadius(10)
    .fontSize(14).constraintSize({ minHeight: 44 }).padding({ left: 16, right: 16 })
  }


@Entry
@Component
struct Index {
  @StorageLink('t3Foreground') @Watch('refreshLinkedOnForeground') appForeground: boolean = true;
  @State linkedGroups: LinkedEnvironmentGroup[] = [];
  private linkedSignature: string = '';
  private linkedGeneration: number = 0;
  @StorageLink('t3PairingRevision') @Watch('incomingPairing') pairingRevision: number = 0;
  private alive: boolean = false;
  @State selectedLocalId: string = '';
  @State environmentFilter: string = '';
  @State scopedThreads: ScopedChoice[] = [];
  @State scopedProjects: ScopedChoice[] = [];
  @State projectFilterId: string = '';
  @State projectFilterLocalId: string = '';
  @State environmentEntries: EnvironmentEntry[] = [];
  @State environmentStatuses: Record<string, string> = {};
  @State loaded: boolean = false;
  private pickers: Map<string, AttachmentPicker> = new Map();
  @State linkItems: LinkRequestView[] = [];
  @State linkMachines: LinkMachine[] = [];
  @State activeLink: LinkRequestView | undefined = undefined;
  @State peerCanAnswer: boolean = false;
  private linkOwner: T3Client | undefined = undefined;
  private linkPermissionKey: string = '';
  private linkPermissionGeneration: number = 0;
  @State page: string = 'sessions';
  @State showTools: boolean = false;
  @State panelOpen: boolean = false;
  @State panel: string = 'server';
  @State address: string = '';
  @State credential: string = '';
  @State routeFor: string = '';
  @State pairingStatus: string = '填写地址与配对码后确认';
  @State projectId: string = '';
  @State modelIndex: number = 0;
  @State threadId: string = '';
  @State prompt: string = '';
  @State status: string = '未连接';
  @State server: string = '';
  @State ready: boolean = false;
  @State busy: boolean = false;
  @State messages: ChatMessage[] = [];
  @State projects: Choice[] = [];
  @State threads: Choice[] = [];
  @State models: ModelChoice[] = [];
  @State actions: ActionCard[] = [];
  @State tools: string[] = [];
  private picker: AttachmentPicker = new AttachmentPicker();
  @State attachmentName: string = '';
  private source: MessageSource = new MessageSource();
  private scroller: Scroller = new Scroller();
  @State unknown: boolean = false;
  private drafts: Map<string, string> = new Map();

  aboutToAppear(): void {
    this.alive = true;
    const update = (): void => {
      if (!this.alive) return;
      this.bindEnvironment();
      this.status = client.status;
      this.server = client.server;
      this.ready = client.ready;
      this.messages = client.thread ? client.thread.messages.slice() : this.messages;
      if (client.recoveredMessageId && this.messages.some((m: ChatMessage) =>
        m.id === client.recoveredMessageId && m.text === this.prompt)) {
        this.prompt = '';
        this.drafts.delete(this.draftKey());
      }
      this.source.update(this.messages);
      this.attachmentName = client.attachment?.name || '';
      this.unknown = !!client.recovery?.pendingId;
      this.projects = client.shell.projects.slice();
      this.threads = client.shell.threads.slice();
      this.models = client.models.slice();
      this.actions = client.thread ? cards(client.thread.requests, client.thread.items) : [];
      try { this.linkItems = client.thread ? linkRequests(client.thread.items, client.thread.threadId) : []; }
      catch (_) { this.linkItems = []; this.status = '环境链接请求格式无效'; }
      const permissionKey = this.selectedLocalId + ':' + String(client.ready) + ':' + this.linkItems.filter((item: LinkRequestView) => item.status === 'pending' && item.visibility === 'local').map((item: LinkRequestView) => item.id).join(',');
      if (permissionKey !== this.linkPermissionKey) { this.linkPermissionKey = permissionKey; void this.refreshPeerPermission(); }
      if (this.activeLink && this.linkOwner === client && !this.busy && this.panel === 'peer-link') {
        const current = this.linkItems.find((item: LinkRequestView) => item.id === this.activeLink?.id);
        if (current && current.status !== 'pending') this.panelOpen = false;
      }
      this.tools = client.thread ? client.thread.items.filter((row: Record<string, Object>) =>
        row.type !== 'assistant_message' && row.type !== 'user_message' && row.type !== 'reasoning' &&
        row.type !== 'link_request' && row.type !== 'secret_request' && row.type !== 'user_input_request' && row.type !== 'approval_request')
        .map((row: Record<string, Object>) => String(row.type) + ' · ' + String(row.status) +
          (typeof row.title === 'string' ? ' · ' + row.title : '') +
          (typeof row.input === 'string' ? '\n' + row.input : '') +
          (typeof row.output === 'string' ? '\n' + row.output : '') +
          (row.outputOmitted === true ? '\n工具输出未随快照提供' : '')) : [];
      if (client.thread) {
        this.threadId = client.thread.threadId;
        this.projectId = this.threads.find((t: Choice) => t.id === this.threadId)?.projectId || this.projectId;
      }
      this.refreshLinkedWhenChanged();
    };
    this.registry().onUpdate = update;
    update();
    void this.restoreAddress();
    this.incomingPairing();
  }

  private incomingPairing(): void {
    if (!this.alive || this.busy) return;
    const target = takePairingLink();
    if (target) {
      this.address = target.base; this.credential = target.code;
      this.pairingStatus = '请确认目标后添加环境'; this.openPanel('connection-new');
    } else {
      const error = AppStorage.get<string>('t3PairingError');
      if (error) { this.credential = ''; this.pairingStatus = error; this.status = error; AppStorage.setOrCreate('t3PairingError', ''); }
    }
  }

  private registry(): EnvironmentRegistry {
    if (!environments) throw new Error('环境目录尚未准备');
    return environments;
  }
  private bindEnvironment(): void {
    const registry = this.registry();
    this.environmentEntries = registry.directory.entries.slice();
    const statuses: Record<string, string> = {};
    registry.clients.forEach((value: T3Client, id: string) => { statuses[id] = value.status; });
    this.environmentStatuses = statuses;
    const threads: ScopedChoice[] = [];
    const projects: ScopedChoice[] = [];
    registry.clients.forEach((value: T3Client, id: string) => {
      const entry = registry.directory.entries.find((e: EnvironmentEntry) => e.localId === id);
      if (!entry || entry.deleting) return;
      value.shell.projects.forEach((project: Choice) => { projects.push({ id: project.id, label: project.label, projectId: project.id, localId: id, environmentLabel: entry.label, projectLabel: project.label }); });
      value.shell.threads.forEach((thread: Choice) => {
        threads.push({ id: thread.id, label: thread.label, projectId: thread.projectId, localId: id,
          environmentLabel: entry.label, projectLabel: value.shell.projects.find((p: Choice) => p.id === thread.projectId)?.label || '项目' });
      });
    });
    this.scopedThreads = threads; this.scopedProjects = projects;
    const localId = registry.directory.selectedLocalId;
    const next = registry.clients.get(localId);
    bindClient(next);
    if (localId !== this.selectedLocalId) {
      this.drafts.set(this.draftKey(), this.prompt);
      this.selectedLocalId = localId;
      this.messages = []; this.source.update([]); this.actions = []; this.tools = [];
      this.projectId = ''; this.modelIndex = 0; this.page = 'sessions';
      this.threadId = next?.thread?.threadId || next?.recovery?.threadId || '';
      this.prompt = this.drafts.get(this.draftKey()) || '';
      if (this.panel !== 'connection-new') this.address = registry.directory.entries.find((e: EnvironmentEntry) => e.localId === localId)?.base || '';
    }
    let picker = this.pickers.get(localId);
    if (!picker || !picker.belongsTo(client)) { picker = new AttachmentPicker(client); this.pickers.set(localId, picker); }
    this.picker = picker;
  }
  private async restoreAddress(): Promise<void> {
    try {
      const registry = this.registry();
      if (!registry.initialized) await registry.initialize();
      if (!this.alive) return;
      this.loaded = true; registry.onUpdate();
      await Promise.all(registry.directory.entries.filter((e: EnvironmentEntry) => e.enabled && !e.deleting)
        .map((e: EnvironmentEntry) => registry.reconnect(e.localId)));
    } catch (error) { this.status = (error as Error).message; }
  }
  aboutToDisappear(): void { this.alive = false; this.linkPermissionGeneration++; this.linkOwner = undefined; this.linkedGeneration++; this.registry().onUpdate = () => {}; }

  private async connect(): Promise<void> {
    if (!this.loaded || this.busy) return;
    this.busy = true;
    const credential = this.credential; this.credential = '';
    this.pairingStatus = '正在连接与校验环境';
    try {
      const target = pairingTarget(this.address, credential);
      if (this.routeFor) await this.registry().addRoute(this.routeFor, target.base, target.code);
      else await this.registry().add(target.base, target.code);
      this.address = target.base; this.routeFor = ''; this.openPanel('server'); void this.loadLinkedEnvironments();
    } catch (error) { this.pairingStatus = (error as Error).message; }
    finally { this.busy = false; this.incomingPairing(); }
  }
  private draftKey(): string { return this.selectedLocalId + '\n' + this.threadId; }

  private async watch(id: string): Promise<void> {
    this.drafts.set(this.draftKey(), this.prompt);
    this.threadId = id;
    this.prompt = this.drafts.get(this.draftKey()) || '';
    this.busy = true;
    try { await client.watch(id); this.page = 'chat'; this.showTools = false; this.panelOpen = false; }
    catch (error) { this.status = (error as Error).message; }
    finally { this.busy = false; this.incomingPairing(); }
  }

  private async newThread(): Promise<void> {
    this.drafts.set(this.draftKey(), this.prompt);
    this.prompt = '';
    this.busy = true;
    try {
      const model = this.models[this.modelIndex];
      if (!model) throw new Error('请选择可用模型');
      const id = await client.newThread(this.projectId, model.instanceId, model.model);
      await this.watch(id);
    } catch (error) { this.status = (error as Error).message; }
    finally { this.busy = false; this.incomingPairing(); }
  }

  private async send(): Promise<void> {
    this.busy = true;
    const submitted = this.prompt;
    try { await client.send(submitted); if (this.prompt === submitted) { this.prompt = ''; this.drafts.delete(this.draftKey()); } }
    catch (error) { this.status = (error as Error).message; }
    finally { this.busy = false; this.incomingPairing(); }
  }

  private async stop(): Promise<void> {
    this.busy = true;
    try { await client.stop(); this.status = '停止请求已确认'; }
    catch (error) { this.status = (error as Error).message; }
    finally { this.busy = false; this.incomingPairing(); }
  }

  private async forget(localId: string): Promise<void> {
    await this.registry().remove(localId);
    this.pickers.get(localId)?.clear(); this.pickers.delete(localId);
    const prefix = localId + '\n';
    this.drafts.forEach((value: string, key: string) => { if (key.startsWith(prefix)) this.drafts.delete(key); });
  }

  private async attach(retry: boolean): Promise<void> {
    this.busy = true;
    try {
      if (retry) await this.picker.retry(); else await this.picker.choose();
      this.attachmentName = client.attachment?.name || '';
      this.status = '附件已上传，发送指令时附带';
    } catch (error) { this.status = (error as Error).message || '附件选择失败，请重试'; }
    finally { this.busy = false; this.incomingPairing(); }
  }

  private async acknowledge(): Promise<void> {
    try { await client.acknowledgeUnknown(); }
    catch (error) { this.status = (error as Error).message; }
  }

  private async copy(value: string): Promise<void> {
    try { await pasteboard.getSystemPasteboard().setData(pasteboard.createData(pasteboard.MIMETYPE_TEXT_PLAIN, value)); }
    catch (_) { this.status = '复制失败'; }
  }

  onBackPress(): boolean {
    if (this.panelOpen && this.panel === 'peer-link' && this.busy) return true;
    if (this.panelOpen) {
      if (this.panel === 'connection-new') { this.panel = 'server'; this.credential = ''; }
      else this.panelOpen = false;
      return true;
    }
    if (this.page === 'chat') { this.page = 'sessions'; return true; }
    return false;
  }

  private async refreshPeerPermission(): Promise<void> {
    const generation = ++this.linkPermissionGeneration; const source = client; this.peerCanAnswer = false;
    if (!source.ready || !this.linkItems.some((item: LinkRequestView) => item.status === 'pending' && item.visibility === 'local')) return;
    try {
      await source.refreshPeerAccess();
      if (source === client && generation === this.linkPermissionGeneration) this.peerCanAnswer = source.canManagePeerAccess();
    } catch (_) {}
  }
  private async openPeerLink(item: LinkRequestView): Promise<void> {
    this.activeLink = item; this.linkOwner = client; this.linkMachines = []; this.openPanel('peer-link');
    const source = this.linkOwner;
    let linkedIds: string[] = [];
    try { linkedIds = (await source.linkedEnvironments()).filter((link) => link.status !== 'expired' && link.expiresAt > Date.now()).map((link) => link.environmentId); }
    catch (_) {}
    if (this.linkOwner !== source || this.activeLink?.id !== item.id) return;
    this.linkMachines = this.registry().directory.entries.filter((entry: EnvironmentEntry) => !entry.deleting && entry.localId !== this.selectedLocalId).map((entry: EnvironmentEntry): LinkMachine => {
      const connection = this.registry().clients.get(entry.localId);
      return { localId: entry.localId, environmentId: entry.environmentId, label: entry.label, connected: !!connection?.ready,
        linked: linkedIds.includes(entry.environmentId), urls: linkReachableAddresses(environmentRoutes(entry).map((route: DirectRoute) => route.base).concat(connection?.directAddresses || [])) };
    });
  }
  private async declinePeerLink(item: LinkRequestView): Promise<void> {
    if (this.busy) return; const source = client; this.busy = true;
    try { await source.answerLinkRequest(item.id, { type: 'decline' }); }
    catch (_) { this.status = '无法答复链接请求，请同步原会话核对结果'; }
    finally { this.busy = false; this.peerCanAnswer = source === client && source.canManagePeerAccess(); this.incomingPairing(); }
  }
  private peerOutcome(item: LinkRequestView): string {
    if (item.status === 'pending') return '等待在原会话中答复';
    if (item.status === 'linked') return '已链接 ' + (item.linkedLabel || linkOrigin(item.url) || '环境') +
      (item.linkedAccess ? ' · ' + (linkAccessChoices.find((choice) => choice.value === item.linkedAccess)?.label || item.linkedAccess) : '');
    if (item.status === 'declined') return '已拒绝';
    if (item.status === 'failed') return '无法链接：' + (item.failure || '目标环境拒绝');
    return '请求已结束';
  }

  private async filterEnvironment(index: number): Promise<void> {
    const entries = this.environmentEntries.filter((e: EnvironmentEntry) => !e.deleting);
    this.environmentFilter = index === 0 ? '' : entries[index - 1].localId;
    this.projectFilterId = ''; this.projectFilterLocalId = '';
    if (this.environmentFilter) {
      try { await this.registry().select(this.environmentFilter); }
      catch (error) { this.status = (error as Error).message; }
    }
  }
  private async openScopedThread(thread: ScopedChoice): Promise<void> {
    try {
      await this.registry().select(thread.localId);
      await this.watch(thread.id);
    } catch (error) { this.status = (error as Error).message; }
  }

  private environmentOptions(): SelectOption[] {
    const all: SelectOption = { value: '所有环境' };
    return [all].concat(this.environmentEntries.filter((e: EnvironmentEntry) => !e.deleting)
      .map((e: EnvironmentEntry): SelectOption => { return { value: e.label }; }));
  }

  private visibleThreads(): ScopedChoice[] {
    return this.scopedThreads.filter((t: ScopedChoice) => (!this.environmentFilter || t.localId === this.environmentFilter) &&
      (!this.projectFilterId || (t.localId === this.projectFilterLocalId && t.projectId === this.projectFilterId)));
  }
  private projectChoices(): ScopedChoice[] {
    return this.scopedProjects.filter((p: ScopedChoice) => !this.environmentFilter || p.localId === this.environmentFilter);
  }
  private projectOptions(): SelectOption[] {
    const all: SelectOption = { value: '所有项目' };
    return [all].concat(this.projectChoices().map((p: ScopedChoice): SelectOption => { return { value: p.label }; }));
  }
  private filterProject(index: number): void {
    const project = index > 0 ? this.projectChoices()[index - 1] : undefined;
    this.projectFilterId = project?.id || ''; this.projectFilterLocalId = project?.localId || '';
  }

  private openPanel(name: string): void {
    this.panel = name; this.panelOpen = true;
    this.linkedSignature = ''; this.linkedGeneration++;
    this.refreshLinkedWhenChanged();
  }
  private refreshLinkedOnForeground(): void {
    this.linkedSignature = ''; this.linkedGeneration++;
    this.refreshLinkedWhenChanged();
  }
  private refreshLinkedWhenChanged(): void {
    if (!this.appForeground || !this.panelOpen || this.panel !== 'server') return;
    const registry = this.registry();
    const signature = registry.directory.entries.map((entry: EnvironmentEntry) =>
      entry.localId + ':' + entry.label + ':' + String(entry.enabled) + ':' + String(entry.deleting) + ':' + String(registry.clients.get(entry.localId)?.ready)).join('\n');
    if (signature === this.linkedSignature) return;
    this.linkedSignature = signature; void this.loadLinkedEnvironments();
  }
  private async loadLinkedEnvironments(): Promise<void> {
    const generation = ++this.linkedGeneration;
    const registry = this.registry();
    const groups = await Promise.all(registry.directory.entries.filter((entry: EnvironmentEntry) => entry.enabled && !entry.deleting && !entry.pendingBase)
      .map(async (entry: EnvironmentEntry): Promise<LinkedEnvironmentGroup | undefined> => {
        try {
          const connection = registry.clients.get(entry.localId);
          if (!connection?.ready) return undefined;
          await connection.refreshPeerAccess();
          if (!connection.canListPeerLinks()) return undefined;
          return { localId: entry.localId, label: entry.label, links: await connection.linkedEnvironments() };
        } catch (_) { return undefined; }
      }));
    if (generation !== this.linkedGeneration || !this.appForeground || !this.panelOpen || this.panel !== 'server') return;
    const visible: LinkedEnvironmentGroup[] = [];
    for (const group of groups) if (group) visible.push(group);
    this.linkedGroups = visible;
  }

  @Builder
  iconButton(icon: Resource, label: string, action: () => void) {
    Button({ type: ButtonType.Normal }) {
      Image(icon).width(21).height(21)
    }.width(44).height(44).backgroundColor(Color.Transparent).borderRadius(22)
      .accessibilityText(label).onClick(action)
  }

  @Builder
  emptyState(title: string, detail: string) {
    Column({ space: 8 }) {
      Text(title).fontSize(20).fontWeight(FontWeight.Medium).textAlign(TextAlign.Center)
      Text(detail).fontSize(14).fontColor($r('app.color.muted')).textAlign(TextAlign.Center)
    }.width('100%').padding(28)
  }

  @Builder
  panelContent() {
    if (this.panel === 'peer-link' && this.activeLink && this.linkOwner) {
      PeerLinkForm({ request: this.activeLink, machines: this.linkMachines, connection: this.linkOwner,
        onClose: () => { this.panelOpen = false; },
        onBusy: (busy: boolean) => { this.busy = busy; if (!busy) { this.peerCanAnswer = this.linkOwner === client && !!this.linkOwner?.canManagePeerAccess(); this.incomingPairing(); } } })
    } else if (this.panel === 'server') {
          ConnectionsPanel({ entries: this.environmentEntries, linkedGroups: this.linkedGroups, statuses: this.environmentStatuses, initialized: this.loaded,
            onClose: () => { this.panelOpen = false; this.credential = ''; },
            onAdd: () => { this.routeFor = ''; this.address = ''; this.credential = ''; this.pairingStatus = '填写地址与配对码后确认'; this.panel = 'connection-new'; },
            onAddRoute: (id: string) => { this.routeFor = id; this.address = ''; this.credential = ''; this.pairingStatus = '为当前环境添加连接路径'; this.panel = 'connection-new'; },
            onInitialize: () => this.restoreAddress(),
            onRetry: (id: string) => this.registry().reconnect(id),
            onEnabled: (id: string, enabled: boolean) => this.registry().setEnabled(id, enabled),
            onEdit: (id: string, label: string, address: string) => this.registry().edit(id, label, address),
            onRemove: (id: string) => this.forget(id),
            onReorderRoutes: (id: string, references: string[]) => this.registry().reorderRoutes(id, references),
            onRemoveRoute: (id: string, reference: string) => this.registry().removeRoute(id, reference),
            onRouting: (id: string, permission: string) => this.registry().setPullRequestRouting(id, permission) })
        .padding(24).width('100%').height('100%').foregroundColor($r('app.color.ink'))
    } else if (this.panel === 'connection-new') {
      Column({ space: 16 }) {

          Row() {
            Button('‹').quietButton().accessibilityText('返回环境').onClick(() => { this.panel = 'server'; this.credential = ''; this.routeFor = ''; })
            Text(this.routeFor ? '添加路径' : '添加环境').fontSize(20).fontWeight(FontWeight.Medium).layoutWeight(1)
            Button(this.busy ? '…' : '✓').quietButton().accessibilityText(this.routeFor ? '确认添加路径' : '确认添加环境')
              .enabled(this.loaded && !this.busy && !!this.address.trim()).onClick(() => this.connect())
          }.width('100%')
        Scroll() {
          Column({ space: 20 }) {
          PairingScanCard({ active: this.panelOpen && this.panel === 'connection-new' && !this.busy,
            onTarget: (target: PairingTarget) => { this.address = target.base; this.credential = target.code; this.pairingStatus = this.routeFor ? '请确认目标后添加连接路径' : '请确认目标后添加环境'; } })
          Text('或手动输入').fontSize(14).fontColor($r('app.color.muted')).width('100%')
          Text('地址').fontSize(13).fontColor($r('app.color.muted')).width('100%')
          TextInput({ placeholder: 'https://your-server', text: this.address }).height(48).borderRadius(10)
            .accessibilityText('服务器地址').enabled(!this.busy).onChange((value: string) => this.address = value)
          Text('配对码').fontSize(13).fontColor($r('app.color.muted')).width('100%')
          TextInput({ placeholder: 'Code', text: this.credential }).height(48).borderRadius(10)
            .type(InputType.Password).enableAutoFill(false).enabled(!this.busy).onChange((value: string) => this.credential = value)
          Text(this.pairingStatus).fontSize(13).fontColor($r('app.color.muted')).width('100%')
          }.width('100%').alignItems(HorizontalAlign.Start)
        }.width('100%').layoutWeight(1)
      }.padding(24).width('100%').height('100%').foregroundColor($r('app.color.ink'))
    } else {
      Scroll() {
        Column({ space: 20 }) {
if (this.panel === 'new') {
          Text('新会话').fontSize(20).fontWeight(FontWeight.Medium).width('100%')
          Text('项目').fontSize(13).fontColor($r('app.color.muted')).width('100%')
          Select(this.projects.map((p: Choice) => { const option: SelectOption = { value: p.label }; return option; }))
            .value(this.projects.find((p: Choice) => p.id === this.projectId)?.label || '选择项目')
            .onSelect((index: number) => this.projectId = this.projects[index].id).width('100%').enabled(!this.busy)
          Text('模型').fontSize(13).fontColor($r('app.color.muted')).width('100%')
          Select(this.models.map((m: ModelChoice) => { const option: SelectOption = { value: m.label }; return option; }))
            .value(this.models[this.modelIndex]?.label || '选择模型').onSelect((index: number) => this.modelIndex = index)
            .width('100%').enabled(!this.busy)
          Text('模型用于本次新会话。').fontSize(12).fontColor($r('app.color.muted')).width('100%')
          Button(this.busy ? '创建中…' : '创建会话').primaryButton().width('100%')
            .enabled(this.ready && !this.busy && !this.unknown && !!this.projectId && this.models.length > 0).onClick(() => this.newThread())
          if (!this.ready || this.unknown) { Text(this.unknown ? '请先核对上次提交结果。' : '请先连接环境。').fontSize(13).width('100%') }
          Text(this.status).fontSize(12).fontColor($r('app.color.muted')).width('100%')
        } else {
          Text('会话操作').fontSize(20).fontWeight(FontWeight.Medium).width('100%')
          Button('同步会话').quietButton().width('100%').enabled(this.ready && !this.busy).onClick(() => this.watch(this.threadId))
          Button('停止任务').quietButton().width('100%').enabled(this.ready && !this.busy && !this.unknown).onClick(() => this.stop())
          Button('管理连接').quietButton().width('100%').onClick(() => this.panel = 'server')
          Text(this.status).fontSize(13).fontColor($r('app.color.muted')).width('100%')
        }
        }.padding({ left: 24, right: 24, top: 32, bottom: 32 }).width('100%').alignItems(HorizontalAlign.Start)
      }.width('100%').height('100%').align(Alignment.TopStart).foregroundColor($r('app.color.ink'))
    }
  }

  @Builder
  sessionsPage() {
    if (this.scopedThreads.length === 0) {
      Column() {
        Blank()
        this.emptyState(this.ready ? '还没有会话' : '添加你的工作环境', this.ready ? '创建新会话，开始处理任务。' : '连接 T3 Code，在手机上继续工作。')
        Button(this.ready ? '新建会话' : '添加环境').primaryButton()
          .onClick(() => this.openPanel(this.ready ? 'new' : 'server'))
        Blank()
      }.layoutWeight(1).width('100%')
    } else {
      List({ space: 0 }) {
        ListItem() {
          Row() {
            Select(this.environmentOptions())
              .value(this.environmentEntries.find((e: EnvironmentEntry) => e.localId === this.environmentFilter)?.label || '所有环境')
              .onSelect((index: number) => { if (!this.busy) void this.filterEnvironment(index); }).enabled(!this.busy)
            Select(this.projectOptions())
              .value(this.projectChoices().find((p: ScopedChoice) => p.localId === this.projectFilterLocalId && p.id === this.projectFilterId)?.label || '所有项目')
              .font({ size: 13 }).backgroundColor(Color.Transparent)
              .onSelect((index: number) => this.filterProject(index))
            Blank()
            Text(this.ready ? '已连接' : '离线').fontSize(12).fontColor($r('app.color.muted'))
          }.padding({ left: 16, right: 20, bottom: 8 }).width('100%')
        }
        ForEach(this.visibleThreads(), (thread: ScopedChoice) => {
          ListItem() {
            Button({ type: ButtonType.Normal }) {
              Row({ space: 12 }) {
                Image($r('app.media.ui_folder')).width(18).height(18)
                Column({ space: 5 }) {
                  Text(thread.label).fontSize(15).fontWeight(FontWeight.Medium).maxLines(2).textOverflow({ overflow: TextOverflow.Ellipsis }).width('100%')
                  Text(thread.projectLabel + (this.environmentEntries.length > 1 ? ' · ' + thread.environmentLabel : ''))
                    .fontSize(12).fontColor($r('app.color.muted')).maxLines(1).width('100%')
                }.layoutWeight(1).alignItems(HorizontalAlign.Start)
                if (thread.localId === this.selectedLocalId && thread.id === this.threadId) { Text('•').fontColor($r('app.color.muted')).accessibilityText('当前会话') }
              }.padding({ left: 20, right: 20, top: 16, bottom: 16 })
            }.width('100%').backgroundColor(thread.localId === this.selectedLocalId && thread.id === this.threadId ? $r('app.color.surface') : Color.Transparent)
              .fontColor($r('app.color.ink')).borderRadius(0).enabled(!this.busy)
              .onClick(() => { void this.openScopedThread(thread); })
          }
        }, (thread: ScopedChoice) => thread.localId + ':' + thread.id)
      }.layoutWeight(1).width('100%')
    }
  }

  @Builder
  chatPage() {
    List({ space: 24, scroller: this.scroller }) {
      if (!this.messages.length) {
        ListItem() { this.emptyState('开始对话', '描述你想完成的任务。') }
      }
      LazyForEach(this.source, (message: ChatMessage) => {
        ListItem() {
          Row() {
            if (message.role === 'user') { Blank().width('10%') }
            Column({ space: 10 }) {
              if (message.streaming) { Text('正在回复…').fontSize(12).fontColor($r('app.color.muted')).width('100%') }
              ForEach(message.attachmentNames || [], (name: string) => { Text('附件 · ' + name).fontSize(13).fontColor($r('app.color.muted')).width('100%') })
              ForEach(markdown(message.text), (block: MarkdownBlock) => {
                Column({ space: 8 }) {
                  if (block.kind === 'code') {
                    Row() {
                      Text('代码').fontSize(12).fontColor($r('app.color.muted'))
                      Blank()
                      Button('复制').quietButton().fontSize(12).onClick(() => this.copy(block.text))
                    }.width('100%')
                  }
                  Text(block.text).width('100%').copyOption(CopyOptions.InApp)
                    .fontFamily(block.kind === 'code' ? 'monospace' : 'sans-serif')
                    .fontSize(block.kind === 'heading' ? 20 : block.kind === 'code' ? 13 : 16)
                    .lineHeight(block.kind === 'heading' ? 28 : block.kind === 'code' ? 20 : 24)
                    .fontWeight(block.kind === 'heading' ? FontWeight.Medium : FontWeight.Normal)
                }.width('100%').padding(block.kind === 'code' ? 12 : 0)
                  .backgroundColor(block.kind === 'code' ? $r('app.color.surface') : Color.Transparent).borderRadius(12)
              })
            }.layoutWeight(1).padding(message.role === 'user' ? 14 : 0)
              .backgroundColor(message.role === 'user' ? $r('app.color.selected') : Color.Transparent).borderRadius(18)
          }.width('100%')
        }
      }, (message: ChatMessage) => JSON.stringify(message))
      if (this.tools.length > 0) {
        ListItem() {
          Button((this.showTools ? '⌄  ' : '›  ') + '工具活动 · ' + this.tools.length).quietButton().fontColor($r('app.color.muted'))
            .onClick(() => this.showTools = !this.showTools)
        }
        if (this.showTools) {
          ForEach(this.tools, (tool: string) => {
            ListItem() { Text(tool).fontSize(13).fontFamily('monospace').copyOption(CopyOptions.InApp).width('100%').padding(12)
              .backgroundColor($r('app.color.surface')).borderRadius(10) }
          })
        }
      }
      ForEach(this.actions, (card: ActionCard) => { ListItem() { RequestCard({ card }) } }, (card: ActionCard) => this.selectedLocalId + ':' + card.id)
      ForEach(this.linkItems, (item: LinkRequestView) => {
        ListItem() {
          if (item.status === 'pending' && item.visibility === 'local') {
            Column({ space: 12 }) {
              Text(item.url || item.environmentId ? '将 ' + (linkOrigin(item.url) || '目标环境') + ' 链接到此环境' : '将一台机器链接到此环境').fontSize(16).fontWeight(FontWeight.Medium).width('100%')
              if (item.reason.trim()) { Text(item.reason).fontSize(14).width('100%') }
              if (this.peerCanAnswer) {
                Button(item.url || item.environmentId ? '审阅链接…' : '选择机器…').primaryButton().width('100%').enabled(!this.busy && !this.unknown).onClick(() => this.openPeerLink(item))
                Button('拒绝').quietButton().enabled(!this.busy && !this.unknown).onClick(() => this.declinePeerLink(item))
              } else { Text('只有管理此环境访问权限的连接才能答复此请求。').fontSize(13).fontColor($r('app.color.muted')).width('100%') }
            }.padding(16).width('100%').border({ width: 1, color: $r('app.color.border') }).borderRadius(20)
          } else { Text(this.peerOutcome(item)).fontSize(13).fontColor($r('app.color.muted')).width('100%') }
        }
      }, (item: LinkRequestView) => this.selectedLocalId + ':' + item.id)
      if (this.unknown) {
        ListItem() {
          Column({ space: 10 }) {
            Text('核对上次提交').fontSize(15).fontWeight(FontWeight.Medium).width('100%')
            Text('同步原会话并核对结果后，才能再次发送。').fontSize(13).fontColor($r('app.color.muted')).width('100%')
            Button('同步会话').quietButton().enabled(this.ready && !this.busy).onClick(() => this.watch(this.threadId))
            Button('已核对提交结果').primaryButton().enabled(this.ready && !this.busy).onClick(() => this.acknowledge())
          }.padding(16).width('100%').border({ width: 1, color: $r('app.color.border') }).borderRadius(16)
        }
      }
    }.width('100%').layoutWeight(1).cachedCount(2).padding({ left: 20, right: 20, top: 16, bottom: 16 })
    Row() {
      if (this.unknown || this.actions.length) {
        Button(this.unknown ? '核对提交结果' : this.actions.length + ' 个请求待处理').quietButton().fontSize(12)
          .onClick((): void => { this.scroller.scrollEdge(Edge.Bottom); })
      }
      Blank()
      this.iconButton($r('app.media.ui_down'), '滚动到最新消息', (): void => { this.scroller.scrollEdge(Edge.Bottom); })
    }.width('100%').padding({ left: 12, right: 12 })
    Column({ space: 0 }) {
      if (this.attachmentName) {
        Text('附件 · ' + this.attachmentName).fontSize(12).fontColor($r('app.color.muted')).width('100%').padding({ left: 16, right: 16, top: 12 })
      }
      Row({ space: 4 }) {
        Button({ type: ButtonType.Normal }) {
          Image($r('app.media.ui_plus')).width(20).height(20)
        }.width(44).height(44).backgroundColor(Color.Transparent).borderRadius(22).accessibilityText('添加附件')
          .bindMenu([
            { value: '选择文件', action: () => { if (this.ready && !this.busy && !this.unknown) void this.attach(false); } },
            { value: '重试上传', action: () => { if (this.ready && !this.busy && !this.unknown) void this.attach(true); } },
            { value: '移除附件', action: () => { if (!this.busy && !this.unknown) { client.attachment = undefined; this.picker.clear(); this.attachmentName = ''; } } }
          ])
      TextArea({ placeholder: '发送消息…', text: this.prompt }).fontSize(15)
        .onChange((value: string) => this.prompt = value).height(this.prompt.length > 60 || this.prompt.includes('\n') ? 96 : 48).layoutWeight(1).padding({ left: 4, right: 4, top: 14, bottom: 10 })
        .backgroundColor(Color.Transparent).accessibilityText('消息输入框')
        if (this.busy) { LoadingProgress().width(20).height(20).color($r('app.color.muted')).accessibilityText('正在提交') }
        Button({ type: ButtonType.Circle }) {
          Image($r('app.media.ui_up')).width(20).height(20)
        }.width(44).height(44).margin(4).backgroundColor($r('app.color.accent')).accessibilityText('发送消息')
          .enabled(this.ready && !this.busy && !this.unknown && this.prompt.trim().length > 0).onClick(() => this.send())
      }.width('100%').padding({ left: 4, right: 4, top: 3, bottom: 3 }).alignItems(VerticalAlign.Bottom)
    }.width('100%').backgroundColor($r('app.color.composer')).borderRadius(27)
      .border({ width: 0.5, color: $r('app.color.border') }).margin({ bottom: 8 })
  }

  build() {
    Column() {
      Row({ space: 4 }) {
        if (this.page === 'chat') {
          this.iconButton($r('app.media.ui_back'), '返回会话列表', () => this.page = 'sessions')
          Column({ space: 2 }) {
            Text(this.threads.find((t: Choice) => t.id === this.threadId)?.label || '新会话').fontSize(16).fontWeight(FontWeight.Medium)
              .maxLines(1).textOverflow({ overflow: TextOverflow.Ellipsis }).width('100%')
            Text(this.projects.find((p: Choice) => p.id === this.projectId)?.label || 'T3 Code').fontSize(12).fontColor($r('app.color.muted'))
              .maxLines(1).width('100%')
          }.layoutWeight(1).alignItems(HorizontalAlign.Start)
          this.iconButton($r('app.media.ui_more'), '会话操作', () => this.openPanel('thread'))
        } else {
          Button({ type: ButtonType.Normal }) {
            Row({ space: 8 }) {
              Text('T3 Code').fontSize(21).fontWeight(FontWeight.Bold)
              Text('⌄').fontSize(16).fontColor($r('app.color.muted'))
            }
          }.height(48).backgroundColor(Color.Transparent).fontColor($r('app.color.ink')).accessibilityText('T3 Code，管理环境')
            .onClick(() => this.openPanel('server'))
          Blank()
          this.iconButton($r('app.media.ui_compose'), '新建会话', () => this.openPanel(this.ready ? 'new' : 'server'))
        }
      }.width('100%').height(56).padding({ left: 12, right: 12 })
      if (this.status !== '会话已同步' && this.status !== '已连接' && this.status !== '未连接') {
        Text(this.status).fontSize(12).fontColor($r('app.color.muted')).maxLines(2).textOverflow({ overflow: TextOverflow.Ellipsis })
          .width('100%').padding({ left: 20, right: 20, bottom: 6 }).accessibilityText('状态：' + this.status)
          .onClick(() => this.openPanel(this.page === 'chat' ? 'thread' : 'server'))
      }
      if (this.page === 'chat') { this.chatPage() } else { this.sessionsPage() }
    }.width('100%').height('100%').padding({ left: 8, right: 8 })
      .backgroundColor($r('app.color.canvas')).foregroundColor($r('app.color.ink'))
      .bindSheet($$this.panelOpen, this.panelContent(), { height: this.panel === 'thread' ? '45%' : '70%', showClose: this.panel !== 'server' && this.panel !== 'connection-new' && this.panel !== 'peer-link',
        onWillDismiss: (action: DismissSheetAction) => { if (this.panel !== 'peer-link' || !this.busy) action.dismiss(); }, backgroundColor: $r('app.color.canvas') })
  }
}
