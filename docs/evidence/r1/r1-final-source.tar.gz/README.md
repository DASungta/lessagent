# T3 Code Harmony

基于 ArkTS + ArkUI 的 T3 Code 鸿蒙原生客户端。

本目录为独立的鸿蒙 Stage 应用工程。第一阶段 M1 已通过 Mate 70 Pro 和专用测试机 Mate 60 Pro（均为系统 7/API 26）的真机验收：签名安装、真实服务鉴权、会话创建、实时/完整回复和原会话断线恢复均已验证。当前尚未初始化 Git 仓库。

- 当前完整迁移计划：[docs/full-mobile-migration-plan.md](docs/full-mobile-migration-plan.md)（整个原版移动端，连接模块优先）
- R1 实现与真机验收：[docs/r1-progress.md](docs/r1-progress.md)（v1→v2 真实升级、多环境/多路径、扫码、深链、锁屏恢复、HTTPS 配对及 C05 已通过专用 Mate 60 Pro 实机路径；原版 B01 视觉对照仍受设备取证条件阻塞）
- R0 实施入口与交付状态：[docs/r0-delivery.md](docs/r0-delivery.md)（固定基线、89 路由、能力矩阵；原版视觉与关键依赖真验仍有阻塞）
- 历史开发规划：[docs/development-plan.md](docs/development-plan.md)
- 第一阶段实施、构建与验收：[docs/phase-one.md](docs/phase-one.md)
- 第二阶段核心客户端：[docs/phase-two.md](docs/phase-two.md)
- 第三阶段恢复与原生体验：[docs/phase-three.md](docs/phase-three.md)
- T3 Code 官方仓库：https://github.com/pingdotgg/t3code
- 用户 fork：https://github.com/DASungta/t3code

目标是通过鸿蒙原生界面连接现有 T3 Code 服务端，在手机上管理项目、会话和 Agent 任务。Agent 继续在电脑或服务器运行。

页面、导航、聊天、Markdown、代码块与 Diff 以 ArkUI 原生实现为目标，不以 WebView 或 React Native 页面替代原生体验。

当前使用 DevEco Studio 6.1.1 / API 24，阶段二已实现安全连接续用、项目/会话/模型选择、历史与流式回复、工具状态、审批/输入/停止及基础代码块展示，已在 Mate 60 Pro 通过代码修改、审批、结果与追问主闭环，并验证单选输入、敏感输入和停止任务。

```sh
./scripts/build.sh
node --experimental-strip-types --test tests/*.test.mjs
```

本轮通过 USB 反向转发连接现有 T3 0.1.9 服务。临时联调凭据已撤销，使用时需生成新配对凭据。阶段三已实施安全恢复元数据、未知提交保护、懒渲染、原生键盘/主题适配和单文件附件，已验证 USB 断线及锁屏/进程恢复；专项验收仍进行中，M2 尚未宣布完成。详见第三阶段记录及其未测边界。

R1 功能迁移已完成到当前客户端范围：目录与秘密分离、v1→v2 迁移、独立环境实例、同 ID 隔离、多路由、扫码/深链、锁屏拒绝、C05 批准/拒绝/撤销和 PR 路由权限均经过真实设备与服务回读。原版 B01 的视觉/交互对照仍需 T3 Device 访问与原版运行能力；IPv6 与 Tailnet 实网组合也仍不能由现有证据声明通过。

原生界面改造与验证边界见 [UI 改造记录](docs/ui-refresh.md)。
