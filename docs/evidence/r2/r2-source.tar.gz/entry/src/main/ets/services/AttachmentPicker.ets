import { picker, fileIo, fileUri } from '@kit.CoreFileKit';
import { client, T3Client } from './T3Client';

// shortcut: a single document in memory; use streaming before raising the 10 MiB client cap.
export class AttachmentPicker {
  private owner: T3Client;
  constructor(owner: T3Client = client) { this.owner = owner; }
  belongsTo(owner: T3Client): boolean { return this.owner === owner; }
  private uri: string = '';
  private scope: string = '';
  private currentScope(): string {
    const recovery = this.owner.recovery;
    return recovery ? recovery.base + '\n' + recovery.environmentId + '\n' + recovery.threadId : '';
  }
  async choose(): Promise<void> {
    const scope = this.currentScope();
    const options = new picker.DocumentSelectOptions();
    options.maxSelectNumber = 1;
    const selected = await new picker.DocumentViewPicker().select(options);
    if (!selected.length) return;
    this.uri = selected[0];
    this.scope = scope;
    await this.retry();
  }
  clear(): void { this.uri = ''; this.scope = ''; }
  async retry(): Promise<void> {
    if (!this.uri || this.scope !== this.currentScope()) throw new Error('请在当前会话重新选择附件');
    const file = await fileIo.open(this.uri, fileIo.OpenMode.READ_ONLY);
    try {
      const size = (await fileIo.stat(file.fd)).size;
      if (size < 1 || size > 10 * 1024 * 1024) throw new Error('请选择 1 字节至 10 MiB 的文件');
      const bytes = new ArrayBuffer(size);
      let offset = 0;
      while (offset < size) {
        const chunk = new ArrayBuffer(size - offset);
        const count = await fileIo.read(file.fd, chunk);
        if (count <= 0) throw new Error('文件读取不完整，请重新选择');
        new Uint8Array(bytes).set(new Uint8Array(chunk, 0, count), offset);
        offset += count;
      }
      if (this.scope !== this.currentScope()) throw new Error('会话已变更，请重新选择附件');
      await this.owner.upload(new fileUri.FileUri(this.uri).name, bytes);
      this.clear();
    } finally { await fileIo.close(file); }
  }
}
