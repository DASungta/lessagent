import { fileIo } from '@kit.CoreFileKit';
import { BusinessError } from '@kit.BasicServicesKit';

export interface WorkspacePreferences {
  schemaVersion: number;
  projectGroupingMode: string;
  environmentFilter: string;
  projectFilterKey: string;
  threadSortOrder: string;
  archivedSortOrder: string;
  workingShelfEnabled: boolean;
  workingShelfExpanded: boolean;
  snoozedShelfExpanded: boolean;
  settledShelfExpanded: boolean;
}

export function defaultWorkspacePreferences(): WorkspacePreferences {
  return {
    schemaVersion: 1, projectGroupingMode: 'repository', environmentFilter: '', projectFilterKey: '',
    threadSortOrder: 'updated_at', archivedSortOrder: 'newest', workingShelfEnabled: true,
    workingShelfExpanded: false, snoozedShelfExpanded: false, settledShelfExpanded: true
  };
}

export function workspacePreferences(value: Object): WorkspacePreferences {
  const row = value as Record<string, Object>;
  if (row === null || typeof row !== 'object' || Array.isArray(value) || row.schemaVersion !== 1) {
    throw new Error('R3 偏好版本无效');
  }
  const mode = typeof row.projectGroupingMode === 'string' ? row.projectGroupingMode : '';
  if (!['repository', 'repository_path', 'separate'].includes(mode)) throw new Error('项目分组方式无效');
  const sort = typeof row.threadSortOrder === 'string' ? row.threadSortOrder : '';
  if (!['updated_at', 'created_at'].includes(sort)) throw new Error('会话排序方式无效');
  const archived = typeof row.archivedSortOrder === 'string' ? row.archivedSortOrder : '';
  if (!['newest', 'oldest'].includes(archived)) throw new Error('归档排序方式无效');
  const env = typeof row.environmentFilter === 'string' ? row.environmentFilter : '';
  const project = typeof row.projectFilterKey === 'string' ? row.projectFilterKey : '';
  if (env.length > 256 || project.length > 512) throw new Error('列表过滤条件无效');
  return {
    schemaVersion: 1, projectGroupingMode: mode, environmentFilter: env, projectFilterKey: project,
    threadSortOrder: sort, archivedSortOrder: archived,
    workingShelfEnabled: row.workingShelfEnabled !== false,
    workingShelfExpanded: row.workingShelfExpanded === true,
    snoozedShelfExpanded: row.snoozedShelfExpanded === true,
    settledShelfExpanded: row.settledShelfExpanded !== false
  };
}

export class WorkspacePrefsStore {
  private path: string;
  constructor(filesDir: string) { this.path = filesDir + '/r3-preferences.json'; }
  async load(): Promise<WorkspacePreferences> {
    try {
      return workspacePreferences(JSON.parse(fileIo.readTextSync(this.path)) as Object);
    } catch (error) {
      if ((error as BusinessError).code === 13900002) return defaultWorkspacePreferences();
      throw new Error('R3 偏好记录不可读或损坏，已使用默认值');
    }
  }
  async save(value: WorkspacePreferences): Promise<void> {
    const checked = workspacePreferences(value);
    const content = JSON.stringify(checked);
    const temporary = this.path + '.tmp';
    const file = fileIo.openSync(temporary, fileIo.OpenMode.CREATE | fileIo.OpenMode.READ_WRITE | fileIo.OpenMode.TRUNC);
    try {
      fileIo.writeSync(file.fd, content);
      fileIo.fsyncSync(file.fd);
    } finally { fileIo.closeSync(file); }
    if (fileIo.readTextSync(temporary) !== content) throw new Error('R3 偏好回读校验失败');
    fileIo.renameSync(temporary, this.path);
  }
}

export let workspacePrefs: WorkspacePreferences = defaultWorkspacePreferences();
export let workspacePrefsStore: WorkspacePrefsStore | undefined = undefined;

export async function prepareWorkspacePreferences(filesDir: string): Promise<void> {
  workspacePrefsStore = new WorkspacePrefsStore(filesDir);
  try { workspacePrefs = await workspacePrefsStore.load(); }
  catch (_) { workspacePrefs = defaultWorkspacePreferences(); }
}

export function saveWorkspacePreferences(): void {
  if (!workspacePrefsStore) return;
  const snapshot = workspacePreferences(JSON.parse(JSON.stringify(workspacePrefs)) as Object);
  void workspacePrefsStore.save(snapshot).catch(() => {});
}
