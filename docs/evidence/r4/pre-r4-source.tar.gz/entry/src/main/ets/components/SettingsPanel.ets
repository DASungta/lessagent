@Component
export struct SettingsPanel {
  @Prop groupingMode: string = 'repository';
  @Prop projectCount: number = 0;
  @Prop archivedCount: number = 0;
  @Prop environmentCount: number = 0;
  onBack: () => void = () => {};
  onEnvironments: () => void = () => {};
  onProjects: () => void = () => {};
  onArchive: () => void = () => {};
  onGrouping: (mode: string) => void = () => {};

  @Builder
  row(title: string, detail: string, value: string, action: () => void) {
    Button({ type: ButtonType.Normal }) {
      Row({ space: 10 }) {
        Column({ space: 3 }) {
          Text(title).fontSize(15).fontWeight(FontWeight.Medium).width('100%')
          Text(detail).fontSize(11).fontColor($r('app.color.muted')).width('100%')
        }.layoutWeight(1).alignItems(HorizontalAlign.Start)
        Text(value).fontSize(12).fontColor($r('app.color.muted'))
        Text('›').fontSize(18).fontColor($r('app.color.muted'))
      }.width('100%').padding(14)
    }.width('100%').backgroundColor($r('app.color.surface')).borderRadius(12).onClick(action)
  }
  @Builder
  choice(title: string, detail: string, value: string) {
    Button({ type: ButtonType.Normal }) {
      Row({ space: 8 }) {
        Text(this.groupingMode === value ? '●' : '○').fontSize(16)
          .fontColor(this.groupingMode === value ? $r('app.color.primary') : $r('app.color.muted'))
        Column({ space: 2 }) {
          Text(title).fontSize(14).fontWeight(FontWeight.Medium).width('100%')
          Text(detail).fontSize(11).fontColor($r('app.color.muted')).width('100%')
        }.layoutWeight(1).alignItems(HorizontalAlign.Start)
      }.width('100%').padding({ left: 14, right: 14, top: 12, bottom: 12 })
    }.width('100%').backgroundColor(Color.Transparent).onClick(() => this.onGrouping(value))
  }

  build() {
    Column({ space: 0 }) {
      Row({ space: 6 }) {
        Button('‹').width(44).height(44).backgroundColor(Color.Transparent).fontColor($r('app.color.ink'))
          .fontSize(26).accessibilityText('返回会话').onClick(this.onBack)
        Text('设置').fontSize(20).fontWeight(FontWeight.Medium).layoutWeight(1)
      }.width('100%').padding({ left: 8, right: 12, top: 8, bottom: 6 })
      Scroll() {
        Column({ space: 14 }) {
          Text('连接与项目').fontSize(12).fontColor($r('app.color.muted')).width('100%')
          this.row('环境', '连接、路径与 T3 Connect', String(this.environmentCount), this.onEnvironments)
          this.row('项目', '概览、名称、固定、归档和 checkout', String(this.projectCount), this.onProjects)
          this.row('归档会话', '恢复或删除已归档会话', String(this.archivedCount), this.onArchive)
          Text('项目分组').fontSize(12).fontColor($r('app.color.muted')).width('100%')
          Column({ space: 0 }) {
            this.choice('按仓库分组', '同一个仓库的多个 checkout 合并显示。', 'repository')
            Divider().color($r('app.color.border')).margin({ left: 14, right: 14 })
            this.choice('按仓库路径分组', 'monorepo 的不同路径保持分开。', 'repository_path')
            Divider().color($r('app.color.border')).margin({ left: 14, right: 14 })
            this.choice('保持独立', '每个工作区单独显示。', 'separate')
          }.width('100%').backgroundColor($r('app.color.surface')).borderRadius(12)
          Text('项目分组使用本机偏好；会话固定/活跃顺序由服务端保存。')
            .fontSize(11).lineHeight(16).fontColor($r('app.color.muted')).width('100%').padding({ left: 4 })
        }.width('100%').alignItems(HorizontalAlign.Start).padding({ left: 16, right: 16, bottom: 20 })
      }.width('100%').layoutWeight(1)
    }.width('100%').height('100%').foregroundColor($r('app.color.ink')).backgroundColor($r('app.color.canvas'))
  }
}
