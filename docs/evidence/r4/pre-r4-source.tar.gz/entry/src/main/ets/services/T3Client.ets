import { http, webSocket } from '@kit.NetworkKit';
import { util } from '@kit.ArkTS';
import { BusinessError } from '@kit.BasicServicesKit';
import { bootstrapForm, createThread, record, RpcClient, RpcSender, sendMessage,
  serverBase, socketUrl, text, ThreadState, validateDescriptor } from '../protocol/Wire';

import { ShellState, ModelChoice, models, SavedSession, SessionStorage, stopCommand, secretAnswer, respondCommand, RecoveryState, RecoveryStorage, recoveryState, Attachment, uploadTarget, PeerLinkView, peerAccessGranted, peerLinkViews, LinkAnswer, linkAnswerPayload, peerPairingScopes } from '../protocol/Core';
import { applyAuthAccessEvent, AuthAccess } from '../protocol/Cloud';
import { capability, objectBool, objectText, offeredProvidersFrom, sessionAllows,
  snoozeSettingsFrom, SnoozePresetSetting } from '../protocol/Projects';

class NativeSender implements RpcSender {
  private socket: webSocket.WebSocket;
  constructor(socket: webSocket.WebSocket) { this.socket = socket; }
  async send(frame: string): Promise<void> {
    try {
      if (!await this.socket.send(frame)) throw new Error('发送失败');
    } catch (_) {
      throw new Error('发送失败');
    }
  }
}

class HttpFailure extends Error {
  status: number;
  constructor(status: number) {
    super(status === 401 || status === 403 ? '鉴权失败或权限不足，请检查配对凭据' :
      status === 426 ? '服务端协议不兼容' : 'HTTP 请求失败（' + status + '）');
    this.status = status;
  }
}

interface PeerPairingPayload { label: string; scopes: string[]; }
interface EmptyPayload { }
interface NamePayload { name: string; }
interface ThreadIdPayload { threadId: string; }
interface PathPayload { partialPath: string; }
interface RepositoryPayload { provider: string; repository: string; }
interface ProjectIdPayload { projectId: string; }

export interface CloudEndpoint { httpBaseUrl: string; wsBaseUrl: string; providerKind: string; }

export interface CloudTransport {
  environmentId: string;
  label: string;
  endpoint(): Promise<CloudEndpoint>;
  requestJson(path: string, method: http.RequestMethod, body?: string, json?: boolean): Promise<Object>;
  socketUrl(): Promise<string>;
  renew(): Promise<number>;
  reset(): Promise<void>;
}

export class T3Client {
  status: string = '未连接';
  expectedEnvironmentId: string = '';
  recoveryBase: string = '';
  reconnectSavedRoutes: (() => Promise<void>) | undefined = undefined;
  private connectionsPending: number = 0;
  get connectionPending(): boolean { return this.connectionsPending > 0; }
  get connectedBase(): string { return this.activeBase(); }
  validateIdentity: (environmentId: string) => void = () => {};
  server: string = '';
  environmentLabel: string = '';
  private peerAccessState: Object | undefined = undefined;
  private offersPeerLinks: boolean = false;
  private peerAccessGeneration: number = 0;
  cloud: CloudTransport | undefined = undefined;
  private cloudBase: string = '';
  private cloudEnvironmentId: string = '';
  private cloudRenewal: number = 0;
  requireDeviceApproval: boolean = false;
  authAccess: AuthAccess = { pairingLinks: [], devices: [] };
  authAccessLoaded: boolean = false;
  private accessChunk: ((value: Object) => void) | undefined = undefined;
  private accessListener: (() => void) | undefined = undefined;
  directAddresses: string[] = [];
  ready: boolean = false;
  thread: ThreadState | undefined = undefined;
  onUpdate: () => void = () => {};
  private socket: webSocket.WebSocket | undefined = undefined;
  private rpc: RpcClient | undefined = undefined;
  private timer: number = 0;
  private lastInbound: number = 0;
  private generation: number = 0;
  private threadChunk: ((value: Object) => void) | undefined = undefined;
  store: SessionStorage | undefined = undefined;
  shell: ShellState = new ShellState();
  models: ModelChoice[] = [];
  capabilities: Record<string, Object> = {};
  serverSettings: Record<string, Object> = {};
  platform: string = '';
  newProjectsRoot: string = '';
  scratchWorkspaceRoot: string = '';
  addProjectBaseDirectory: string = '';
  ghqCloneLayout: boolean = false;
  snoozePresets: SnoozePresetSetting[] = snoozeSettingsFrom(undefined);
  offeredSourceControlProviders: Record<string, boolean> = {};
  sessionAccess: Object | undefined = undefined;
  private saved: SavedSession | undefined = undefined;
  recoveryStore: RecoveryStorage | undefined = undefined;
  recovery: RecoveryState | undefined = undefined;
  private mutating: boolean = false;
  get mutationPending(): boolean { return this.mutating || !!this.recovery?.pendingId; }
  get submitting(): boolean { return this.mutating; }
  private reconciled: boolean = false;
  private resumeWanted: boolean = false;
  private retryTimer: number = 0;
  private retryDelay: number = 1000;
  private notifyTimer: number = 0;

  private notify(): void {
    if (this.notifyTimer) return;
    this.notifyTimer = setTimeout(() => { this.notifyTimer = 0; this.onUpdate(); }, 50);
  }

  generationValue(): number { return this.generation; }
  canScope(scope: string): boolean | undefined { return sessionAllows(this.sessionAccess, scope); }
  supports(name: string): boolean { return capability({ capabilities: this.capabilities }, name); }
  canCreateProject(): boolean {
    return this.ready && this.canScope('orchestration:operate') !== false;
  }
  canReadFiles(): boolean {
    return this.ready && this.canScope('filesystem:read') !== false;
  }
  canWriteSourceControl(): boolean {
    return this.ready && this.canScope('source-control:write') !== false;
  }
  async refreshSessionAccess(): Promise<void> {
    if (!this.ready || !this.activeBase()) return;
    const rpc = this.rpc;
    const generation = this.generation;
    try {
      const value = record(await this.httpJson(this.activeBase(), '/api/auth/session', http.RequestMethod.GET,
        '', this.saved?.token || '', false, !!this.cloud));
      if (rpc !== this.rpc || generation !== this.generation) return;
      this.sessionAccess = value;
    } catch (_) {
      if (rpc === this.rpc && generation === this.generation) this.sessionAccess = undefined;
    }
    this.onUpdate();
  }
  async rpcRequest(method: string, payload: Object, timeoutMs: number = 15000,
    fatalTimeout: boolean = true): Promise<Object> {
    const rpc = this.requireRpc();
    const generation = this.generation;
    const value = await rpc.request(method, payload, undefined, timeoutMs, fatalTimeout);
    if (rpc !== this.rpc || generation !== this.generation) throw new Error('连接已变更，请刷新后核对结果');
    return value;
  }
  watchRpcStream(method: string, payload: Object, onItem: (value: Object) => void): (value: Object) => void {
    const rpc = this.requireRpc();
    const generation = this.generation;
    const wrapped = (value: Object): void => {
      if (rpc === this.rpc && generation === this.generation) onItem(value);
    };
    void rpc.request(method, payload, wrapped, 600000).then(() => {}).catch(() => {});
    return wrapped;
  }
  stopRpcStream(onItem: (value: Object) => void): void {
    this.rpc?.cancelStream(onItem);
  }
  async dispatchCommand(command: Object): Promise<Object> {
    return this.rpcRequest('orchestration.dispatchCommand', command);
  }
  async projectMutate(mutation: Object): Promise<Object> {
    return this.rpcRequest('projects.mutate', mutation);
  }
  async ensureScratch(): Promise<Object> {
    const payload: EmptyPayload = {};
    return this.rpcRequest('projects.ensureScratch', payload);
  }
  async createNewProject(name: string): Promise<Object> {
    const payload: NamePayload = { name };
    return this.rpcRequest('projects.createNew', payload);
  }
  async createProjectFromThread(threadId: string): Promise<Object> {
    const payload: ThreadIdPayload = { threadId };
    return this.rpcRequest('projects.createFromThread', payload);
  }
  async browseFilesystem(partialPath: string): Promise<Object> {
    const payload: PathPayload = { partialPath };
    return this.rpcRequest('filesystem.browse', payload, 10000, false);
  }
  async discoverSourceControl(): Promise<Object> {
    const payload: EmptyPayload = {};
    return this.rpcRequest('server.discoverSourceControl', payload, 8000, false);
  }
  async lookupRepository(provider: string, repository: string): Promise<Object> {
    const payload: RepositoryPayload = { provider, repository };
    return this.rpcRequest('sourceControl.lookupRepository', payload, 15000, false);
  }
  async publishRepository(payload: Object): Promise<Object> {
    return this.rpcRequest('sourceControl.publishRepository', payload);
  }
  async startProjectClone(payload: Object): Promise<Object> {
    return this.rpcRequest('projectClone.start', payload);
  }
  async cancelProjectClone(projectId: string): Promise<Object> {
    const payload: ProjectIdPayload = { projectId };
    return this.rpcRequest('projectClone.cancel', payload);
  }
  async retryProjectClone(projectId: string): Promise<Object> {
    const payload: ProjectIdPayload = { projectId };
    return this.rpcRequest('projectClone.retry', payload);
  }
  async archivedShellSnapshot(): Promise<Object> {
    const payload: EmptyPayload = {};
    return this.rpcRequest('orchestration.getArchivedShellSnapshot', payload, 15000, false);
  }
  async searchThreads(payload: Object): Promise<Object> {
    return this.rpcRequest('orchestration.searchThreads', payload, 8000, false);
  }

  suspend(): void {
    const wanted = this.resumeWanted;
    this.disconnect('后台已暂停连接，任务在服务端继续');
    this.resumeWanted = wanted;
  }

  async resume(): Promise<void> {
    if (!this.resumeWanted || this.ready) return;
    if (this.reconnectSavedRoutes) { await this.reconnectSavedRoutes(); return; }
    const saved = this.store ? await this.store.load() : this.saved;
    if (saved && saved.expiresAt > Date.now()) await this.connect(saved.base);
  }

  private retry(): void {
    if (!this.resumeWanted || (!this.reconnectSavedRoutes && (!this.saved || this.saved.expiresAt <= Date.now()))) return;
    this.retryTimer = setTimeout(() => {
      this.retryTimer = 0;
      void this.resume().catch(() => { this.status = '请解锁后安全重连'; this.onUpdate(); });
    }, this.retryDelay);
    this.retryDelay = Math.min(this.retryDelay * 2, 30000);
  }

  private async saveRecovery(): Promise<void> {
    if (this.recovery && this.recoveryStore) await this.recoveryStore.save(this.recovery);
  }

  async acknowledgeUnknown(): Promise<void> {
    if (this.mutating || !this.reconciled || !this.recovery) throw new Error('请先同步原会话并核对结果');
    const pending = this.recovery;
    this.recovery = { base: pending.base, environmentId: pending.environmentId, threadId: pending.threadId, pendingId: '', pendingKind: '' };
    try { await this.saveRecovery(); } catch (error) { this.recovery = pending; throw error as Error; }
    this.status = '已确认核对，允许手动提交新请求'; this.onUpdate();
  }

  private async mutate(method: string, payload: Object, id: string, kind: string): Promise<void> {
    const rpc = this.requireRpc();
    if (this.mutating || this.recovery?.pendingId) throw new Error('上次提交结果未知，请同步原会话并核对结果');
    if (!this.recovery) throw new Error('请先选择会话');
    this.mutating = true;
    this.reconciled = false;
    this.recovery.pendingId = id; this.recovery.pendingKind = kind;
    try {
      await this.saveRecovery(); // Commit the marker before any modifying request leaves the device.
      if (rpc !== this.rpc) throw new Error('连接已变更，请同步原会话核对');
      await rpc.request(method, payload);
      const pending = this.recovery;
      this.recovery = { base: pending.base, environmentId: pending.environmentId, threadId: pending.threadId, pendingId: '', pendingKind: '' };
      try { await this.saveRecovery(); } catch (error) { this.recovery = pending; throw error as Error; }
    } finally { this.mutating = false; this.onUpdate(); }
  }
  attachment: Attachment | undefined = undefined;
  private attachmentThread: string = '';
  recoveredMessageId: string = '';

  private async httpJson(base: string, path: string, method: http.RequestMethod,
    body: string = '', token: string = '', json: boolean = false,
    cloudAuth: boolean = false): Promise<Object> {
    if (cloudAuth && this.cloud) return this.cloud.requestJson(path, method, body, json);
    const request = http.createHttp();
    try {
      const headers: Record<string, string> = { 'Accept': 'application/json' };
      if (token) headers['Authorization'] = 'Bearer ' + token;
      if (body) headers['Content-Type'] = json ? 'application/json' : 'application/x-www-form-urlencoded';
      const options: http.HttpRequestOptions = {
        method, header: headers, connectTimeout: 10000, readTimeout: 10000,
        usingCache: false, maxRedirects: 0, expectDataType: http.HttpDataType.STRING
      };
      // NetworkKit rejects an explicitly empty POST extraData with parameter error 401.
      if (body) options.extraData = body;
      const response = await request.request(base + path, options);
      if (response.responseCode < 200 || response.responseCode >= 300) throw new HttpFailure(response.responseCode);
      return JSON.parse(response.result as string) as Object;
    } catch (error) {
      if (error instanceof HttpFailure) throw error as Error;
      const code = (error as BusinessError).code;
      const detail = typeof code === 'number' ? '，系统错误码 ' + code : '，响应格式无效';
      throw new Error('HTTP ' + path + ' 失败' + detail);
    } finally {
      request.destroy();
    }
  }

  private captureDirectAddresses(config: Record<string, Object>): void {
    const addresses: string[] = [];
    if (Array.isArray(config.directEndpoints)) {
      for (const value of config.directEndpoints as Object[]) {
        try { const base = serverBase(text(record(value).httpBaseUrl)); if (!addresses.includes(base)) addresses.push(base); }
        catch (_) {}
      }
    }
    this.directAddresses = addresses;
  }
  private activeBase(): string { return this.saved?.base || this.cloudBase; }
  private activeEnvironmentId(): string { return this.saved?.environmentId || this.cloudEnvironmentId; }
  canListPeerLinks(): boolean { return this.ready && this.offersPeerLinks && peerAccessGranted(this.peerAccessState, false); }
  async refreshPeerAccess(): Promise<void> {
    const rpc = this.requireRpc(); const saved = this.saved;
    const generation = ++this.peerAccessGeneration;
    if (!this.activeEnvironmentId()) throw new Error('环境凭据未加载');
    this.peerAccessState = undefined;
    const config = record(await rpc.request('server.getConfig', {}));
    if (rpc !== this.rpc) throw new Error('连接已变更');
    if (generation !== this.peerAccessGeneration) throw new Error('权限查询已更新');
    const environmentId = this.activeEnvironmentId();
    if (text(record(config.environment).environmentId) !== environmentId) throw new Error('环境身份不一致');
    this.captureDirectAddresses(config);
    const capabilities = record(config.environment).capabilities; const settings = config.settings;
    this.offersPeerLinks = !!capabilities && record(capabilities).peerLinks === true &&
      !!settings && record(settings).linkedEnvironmentsEnabled === true;
    const state = record(await this.httpJson(this.activeBase(), '/api/auth/session', http.RequestMethod.GET,
      '', saved?.token || '', false, !!this.cloud));
    if (rpc !== this.rpc) throw new Error('连接已变更');
    if (generation !== this.peerAccessGeneration) throw new Error('权限查询已更新');
    if (typeof state.authenticated !== 'boolean') throw new Error('环境权限响应无效');
    this.peerAccessState = state;
  }
  canManagePeerAccess(): boolean { return this.ready && peerAccessGranted(this.peerAccessState, true); }
  async mintPeerPairingCode(access: string): Promise<string> {
    const rpc = this.requireRpc(); await this.refreshPeerAccess();
    if (rpc !== this.rpc || !this.canManagePeerAccess() || !this.activeEnvironmentId()) throw new Error('此连接不能创建配对码，请粘贴该环境提供的配对码');
    const payload: PeerPairingPayload = { label: 'T3 Code link', scopes: peerPairingScopes(access) };
    const result = record(await this.httpJson(this.activeBase(), '/api/auth/pairing-token', http.RequestMethod.POST,
      JSON.stringify(payload), this.saved?.token || '', true, !!this.cloud));
    if (rpc !== this.rpc) throw new Error('连接已变更，请重新获取配对码');
    const code = text(result.credential);
    if (!code.trim() || code.length > 4096) throw new Error('配对码响应无效');
    return code;
  }
  async linkProof(payload: Object): Promise<string> {
    const rpc = this.requireRpc();
    const result = text(await this.httpJson(this.activeBase(), '/api/connect/link-proof',
      http.RequestMethod.POST, JSON.stringify(payload), this.saved?.token || '', true, !!this.cloud));
    if (rpc !== this.rpc || !result || result.length > 8192) throw new Error('环境链接证明无效');
    return result;
  }
  async configureRelay(payload: Object): Promise<void> {
    const rpc = this.requireRpc();
    await this.httpJson(this.activeBase(), '/api/connect/relay-config', http.RequestMethod.POST,
      JSON.stringify(payload), this.saved?.token || '', true, !!this.cloud);
    if (rpc !== this.rpc) throw new Error('连接已变更，请重新确认链接');
  }
  async unlinkRelay(): Promise<void> {
    const rpc = this.requireRpc();
    await this.httpJson(this.activeBase(), '/api/connect/unlink', http.RequestMethod.POST,
      '', this.saved?.token || '', false, !!this.cloud);
    if (rpc !== this.rpc) throw new Error('连接已变更');
  }
  async answerLinkRequest(id: string, answer: LinkAnswer): Promise<void> {
    const rpc = this.requireRpc(); await this.refreshPeerAccess();
    if (rpc !== this.rpc || !this.canManagePeerAccess()) throw new Error('只有管理此环境访问权限的连接才能答复');
    const item = this.thread?.items.find((row: Record<string, Object>) => row.id === id && row.type === 'link_request');
    if (!this.thread || !item || item.linkStatus !== 'pending' || item.threadId !== this.thread.threadId) throw new Error('链接请求已结束或不属于当前会话');
    await this.mutate('peerLinks.answerRequest', linkAnswerPayload(this.thread.threadId, id, answer), id, 'response');
  }
  async linkedEnvironments(): Promise<PeerLinkView[]> {
    const rpc = this.requireRpc();
    if (!this.canListPeerLinks()) throw new Error('无权查看已链接环境或环境未开启链接');
    const value = await rpc.request('peerLinks.list', {});
    if (rpc !== this.rpc) throw new Error('连接已变更');
    return peerLinkViews(value);
  }
  stopAuthAccess(): void {
    const rpc = this.rpc;
    const chunk = this.accessChunk;
    this.accessChunk = undefined;
    if (rpc && chunk) rpc.cancelStream(chunk);
  }
  watchAuthAccess(onUpdate: () => void): void {
    const rpc = this.requireRpc();
    if (!this.requireDeviceApproval) throw new Error('此环境未启用 T3 Connect 设备批准');
    if (!this.canManagePeerAccess()) throw new Error('无权管理此环境的 T3 Connect 设备');
    this.accessListener = onUpdate;
    this.stopAuthAccess();
    this.authAccessLoaded = false;
    const chunk = (value: Object): void => {
      if (rpc !== this.rpc) return;
      this.authAccess = applyAuthAccessEvent(this.authAccess, value);
      this.authAccessLoaded = true;
      onUpdate();
    };
    this.accessChunk = chunk;
    void rpc.request('subscribeAuthAccess', {}, chunk).then(() => {
      if (this.rpc === rpc && this.accessChunk === chunk) this.authAccessLoaded = false;
    }).catch(() => {
      if (this.rpc === rpc && this.accessChunk === chunk) {
        this.accessChunk = undefined;
        this.authAccessLoaded = false;
      }
    });
  }
  async approveDevice(pairingLinkId: string): Promise<void> {
    const rpc = this.requireRpc();
    if (!this.frameDeviceIdentity(pairingLinkId)) throw new Error('设备批准请求已失效');
    const result = record(await this.httpJson(this.activeBase(), '/api/auth/connect-devices/approve',
      http.RequestMethod.POST, JSON.stringify({ pairingLinkId }), this.saved?.token || '', true, !!this.cloud));
    if (rpc !== this.rpc) throw new Error('连接已变更');
    if (result.approved !== true) throw new Error('批准请求已过期或已被其他设备处理');
    this.authAccess.pairingLinks = this.authAccess.pairingLinks.filter((link) => link.id !== pairingLinkId);
    this.refreshAuthAccess();
  }
  async denyDevice(pairingLinkId: string): Promise<void> {
    const rpc = this.requireRpc();
    if (!this.frameDeviceIdentity(pairingLinkId)) throw new Error('设备批准请求已失效');
    const result = record(await this.httpJson(this.activeBase(), '/api/auth/pairing-links/revoke',
      http.RequestMethod.POST, JSON.stringify({ id: pairingLinkId }), this.saved?.token || '', true, !!this.cloud));
    if (rpc !== this.rpc) throw new Error('连接已变更');
    if (result.revoked !== true) throw new Error('拒绝请求已过期或已被处理');
    this.authAccess.pairingLinks = this.authAccess.pairingLinks.filter((link) => link.id !== pairingLinkId);
    this.refreshAuthAccess();
  }
  async revokeDevice(proofKeyThumbprint: string): Promise<void> {
    const rpc = this.requireRpc();
    if (!proofKeyThumbprint || proofKeyThumbprint.length > 256) throw new Error('设备密钥标识无效');
    const result = record(await this.httpJson(this.activeBase(), '/api/auth/connect-devices/revoke',
      http.RequestMethod.POST, JSON.stringify({ proofKeyThumbprint }), this.saved?.token || '', true, !!this.cloud));
    if (rpc !== this.rpc) throw new Error('连接已变更');
    if (result.revoked !== true) throw new Error('设备已撤销或不存在');
    this.authAccess.devices = this.authAccess.devices.filter((device) => device.proofKeyThumbprint !== proofKeyThumbprint);
    this.refreshAuthAccess();
  }
  private refreshAuthAccess(): void {
    const listener = this.accessListener;
    if (!listener || !this.ready || !this.requireDeviceApproval) return;
    try { this.watchAuthAccess(listener); } catch (_) {}
  }
  private frameDeviceIdentity(pairingLinkId: string): boolean {
    return !!pairingLinkId && pairingLinkId.length <= 256 &&
      this.authAccess.pairingLinks.some((link) => link.id === pairingLinkId && link.expiresAt > Date.now());
  }

  async verifyIdentity(address: string): Promise<void> {
    const descriptor = validateDescriptor(await this.httpJson(serverBase(address), '/.well-known/t3/environment', http.RequestMethod.GET));
    if (!this.expectedEnvironmentId || descriptor.environmentId !== this.expectedEnvironmentId) throw new Error('服务器身份不一致，未更新地址');
  }

  async connect(address: string, credential: string = ''): Promise<void> {
    if (this.cloud) return this.connectCloud();
    if (this.mutating) throw new Error('请求正在提交，请稍候再重连');
    this.disconnect();
    this.resumeWanted = true;
    const generation = this.generation;
    const base = serverBase(address);
    this.server = '';
    this.status = '正在鉴权';
    this.onUpdate();
    this.connectionsPending++;
    try {
      const descriptor = validateDescriptor(await this.httpJson(base, '/.well-known/t3/environment', http.RequestMethod.GET));
      if (generation !== this.generation) return;
      const environmentId = text(descriptor.environmentId);
      if (this.expectedEnvironmentId && environmentId !== this.expectedEnvironmentId) {
        throw new Error('服务器身份已变化，未发送配对凭据');
      }
      this.validateIdentity(environmentId);
      this.environmentLabel = text(descriptor.label);
      this.server = text(descriptor.label) + ' · ' + text(descriptor.serverVersion);
      let saved = this.store ? await this.store.load(base) : this.saved;
      if (generation !== this.generation) return;
      if (credential.trim()) {
        const auth = record(await this.httpJson(base, '/oauth/token', http.RequestMethod.POST, bootstrapForm(credential)));
        if (generation !== this.generation) return;
        if (auth.token_type !== 'Bearer') throw new Error('该服务要求 DPoP，当前仅支持直连 Bearer 鉴权');
        if (typeof auth.expires_in !== 'number' || auth.expires_in <= 0) throw new Error('无效凭据有效期');
        saved = { base, environmentId, token: text(auth.access_token), expiresAt: Date.now() + auth.expires_in * 1000 };
      }
      if (!saved || saved.base !== base || saved.environmentId !== environmentId || saved.expiresAt <= Date.now()) {
        throw new Error('没有此服务器的有效会话，请输入新配对凭据');
      }
      const token = saved.token;
      let ticket: Object;
      try {
        ticket = await this.httpJson(base, '/api/auth/websocket-ticket/rpc', http.RequestMethod.POST, '', token);
      } catch (error) {
        if (generation !== this.generation) return;
        if (!(error instanceof HttpFailure) || error.status !== 404) throw error as Error;
        ticket = await this.httpJson(base, '/api/auth/websocket-ticket', http.RequestMethod.POST, '', token);
      }
      if (generation !== this.generation) return;
      await this.finishConnection(socketUrl(base, text(record(ticket).ticket)),
        environmentId, base, saved, generation);
    } catch (error) {
      if (generation === this.generation) this.disconnect((error as Error).message,
        (!!this.saved || !!this.cloud) &&
        ((error as Error).message.startsWith('HTTP ') || (error as Error).message.startsWith('WebSocket') ||
          (error as Error).message.startsWith('T3 Connect')));
    } finally { this.connectionsPending--; }
  }

  private async connectCloud(): Promise<void> {
    const transport = this.cloud;
    if (!transport) throw new Error('T3 Connect 传输未就绪');
    if (this.mutating) throw new Error('请求正在提交，请稍候再重连');
    this.disconnect();
    this.resumeWanted = true;
    const generation = this.generation;
    this.server = '';
    this.status = '正在通过 T3 Connect 授权';
    this.onUpdate();
    this.connectionsPending++;
    try {
      const endpoint = await transport.endpoint();
      if (generation !== this.generation) return;
      const base = serverBase(endpoint.httpBaseUrl);
      const descriptor = validateDescriptor(await this.httpJson(base, '/.well-known/t3/environment', http.RequestMethod.GET));
      if (generation !== this.generation) return;
      const environmentId = text(descriptor.environmentId);
      if (environmentId !== transport.environmentId ||
        (this.expectedEnvironmentId && environmentId !== this.expectedEnvironmentId)) {
        throw new Error('中继服务器身份不一致，已中止连接');
      }
      this.validateIdentity(environmentId);
      this.environmentLabel = text(descriptor.label) || transport.label;
      this.server = text(descriptor.label) + ' · ' + text(descriptor.serverVersion);
      this.status = '正在连接中继环境';
      this.onUpdate();
      const target = await transport.socketUrl();
      if (generation !== this.generation) return;
      await this.finishConnection(target, environmentId, base, undefined, generation);
    } catch (error) {
      if (generation === this.generation) this.disconnect((error as Error).message, true);
    } finally { this.connectionsPending--; }
  }

  private async finishConnection(target: string, environmentId: string, base: string,
    saved: SavedSession | undefined, generation: number): Promise<void> {
    const socket = webSocket.createWebSocket();
    const rpc = new RpcClient(new NativeSender(socket));
    this.socket = socket;
    this.rpc = rpc;
    this.lastInbound = Date.now();
    rpc.onFailure = (message: string) => {
      if (generation !== this.generation) return;
      this.disconnect(message, true);
    };
    socket.on('message', (error, data: string | ArrayBuffer) => {
      if (generation !== this.generation) return;
      if ((error && error.code !== 0) || typeof data !== 'string') {
        rpc.fail('收到无效 WebSocket 消息');
        return;
      }
      this.lastInbound = Date.now();
      rpc.receive(data);
    });
    socket.on('error', () => rpc.fail('WebSocket 连接失败或中断；提交中的请求结果未知，请重连并核对会话'));
    socket.on('close', () => rpc.fail('连接已断开；提交中的任务结果未知，请重连并同步会话'));
    this.status = '正在连接与校验服务器';
    this.onUpdate();
    try {
      if (!await socket.connect(target)) throw new Error('连接失败');
    } catch (_) {
      throw new Error('WebSocket 连接失败，请检查网络和服务端版本');
    }
    if (generation !== this.generation) return;
    this.timer = setInterval(() => {
      if (Date.now() - this.lastInbound > 15000) rpc.fail('服务端响应超时；请重连并核对任务状态');
      else rpc.ping();
    }, 5000);
    const config = record(await rpc.request('server.getConfig', {}));
    if (text(record(config.environment).environmentId) !== environmentId) throw new Error('服务器身份不一致，已中止连接');
    if (generation !== this.generation) return;
    this.models = config.providers ? models(config) : [];
    const environment = record(config.environment);
    this.capabilities = environment.capabilities === undefined || environment.capabilities === null ?
      {} : record(environment.capabilities);
    const platform = environment.platform === undefined || environment.platform === null ? undefined : record(environment.platform);
    this.platform = platform === undefined ? '' : objectText(platform, 'os');
    this.serverSettings = config.settings === undefined || config.settings === null ? {} : record(config.settings);
    this.newProjectsRoot = objectText(config, 'newProjectsRoot');
    this.scratchWorkspaceRoot = objectText(config, 'scratchWorkspaceRoot');
    this.addProjectBaseDirectory = objectText(this.serverSettings, 'addProjectBaseDirectory');
    this.ghqCloneLayout = objectBool(this.serverSettings, 'ghqCloneLayout');
    this.snoozePresets = snoozeSettingsFrom(this.serverSettings.snoozePresets);
    this.offeredSourceControlProviders = offeredProvidersFrom(this.serverSettings.offeredSourceControlProviders);
    this.captureDirectAddresses(config);
    this.requireDeviceApproval = !!config.settings && record(config.settings).requireConnectDeviceApproval === true;
    if (saved) {
      if (this.store) await this.store.save(saved);
      if (generation !== this.generation) return;
      this.saved = saved;
    } else {
      this.saved = undefined;
    }
    this.cloudBase = base;
    this.cloudEnvironmentId = environmentId;
    const recovery = this.recoveryStore ? await this.recoveryStore.load() : this.recovery;
    if (generation !== this.generation) return;
    this.recovery = recovery ? recoveryState(recovery, this.recoveryBase || base, environmentId) : undefined;
    this.ready = true;
    this.subscribeShell();
    this.retryDelay = 1000;
    this.status = '已连接';
    this.onUpdate();
    this.sessionAccess = undefined;
    if (this.cloud) this.scheduleCloudRenewal(generation);
    if (this.recovery) await this.watch(this.recovery.threadId);
  }

  private scheduleCloudRenewal(generation: number): void {
    if (!this.cloud) return;
    clearTimeout(this.cloudRenewal); this.cloudRenewal = 0;
    const transport = this.cloud;
    const renew = (): void => {
      if (generation !== this.generation || this.cloud !== transport) return;
      void transport.renew().then((next: number) => {
        if (generation !== this.generation || this.cloud !== transport) return;
        this.cloudRenewal = setTimeout(renew, Math.max(5000, next - Date.now() - 30000));
      }).catch(() => {
        if (generation !== this.generation || this.cloud !== transport) return;
        this.status = 'T3 Connect 凭证续期失败，正在重试';
        this.onUpdate();
        this.cloudRenewal = setTimeout(renew, 30000);
      });
    };
    this.cloudRenewal = setTimeout(renew, 30000);
  }

  disconnect(message: string = '已断开；提交中的请求结果未知，请重连并同步会话', recover: boolean = false): void {
    this.resumeWanted = recover;
    clearTimeout(this.retryTimer); this.retryTimer = 0;
    clearTimeout(this.notifyTimer); this.notifyTimer = 0;
    clearTimeout(this.cloudRenewal); this.cloudRenewal = 0;
    this.generation++;
    this.ready = false; this.peerAccessState = undefined; this.offersPeerLinks = false;
    this.requireDeviceApproval = false;
    this.authAccessLoaded = false;
    this.accessChunk = undefined;
    this.accessListener = undefined;
    this.authAccess = { pairingLinks: [], devices: [] };
    this.threadChunk = undefined;
    this.shell = new ShellState();
    this.models = [];
    this.capabilities = {};
    this.serverSettings = {};
    this.platform = '';
    this.newProjectsRoot = '';
    this.scratchWorkspaceRoot = '';
    this.addProjectBaseDirectory = '';
    this.ghqCloneLayout = false;
    this.snoozePresets = snoozeSettingsFrom(undefined);
    this.offeredSourceControlProviders = {};
    this.sessionAccess = undefined;
    this.thread = undefined;
    this.cloudBase = '';
    this.cloudEnvironmentId = '';
    clearInterval(this.timer);
    this.timer = 0;
    const rpc = this.rpc;
    const socket = this.socket;
    this.rpc = undefined;
    this.socket = undefined;
    rpc?.fail(message);
    if (socket) void socket.close().catch(() => {});
    this.status = message;
    this.onUpdate();
    if (recover) this.retry();
  }

  async newThread(projectId: string, instanceId: string, model: string): Promise<string> {
    const rpc = this.requireRpc();
    if (this.mutating || this.recovery?.pendingId) throw new Error('请求正在提交，请稍候');
    const previousChunk = this.threadChunk;
    this.threadChunk = undefined;
    if (previousChunk) rpc.cancelStream(previousChunk);
    const threadId = util.generateRandomUUID();
    const command = createThread(util.generateRandomUUID(), threadId, projectId, instanceId, model);
    // Keep the allocated ID even if acknowledgement is lost, so the user can reconcile it.
    this.thread = new ThreadState(threadId);
    this.onUpdate();
    await this.selectRecovery(threadId);
    await this.mutate('orchestration.dispatchCommand', command, threadId, 'create');
    return threadId;
  }

  async watch(threadId: string): Promise<void> {
    if (!threadId.trim()) throw new Error('请输入会话 ID');
    const rpc = this.requireRpc();
    if (this.mutating) throw new Error('请求正在提交，请稍候');
    const previousChunk = this.threadChunk;
    this.threadChunk = undefined;
    if (previousChunk) rpc.cancelStream(previousChunk);
    this.recoveredMessageId = '';
    await this.selectRecovery(threadId.trim());
    if (rpc !== this.rpc) return;
    const state = new ThreadState(threadId.trim());
    this.thread = state;
    this.status = '正在同步会话';
    this.onUpdate();
    const chunk = (value: Object): void => {
      state.apply(value);
      this.status = state.notices || '会话已同步';
      if (record(value).kind === 'snapshot' && this.recovery?.pendingId && !this.mutating &&
        this.recovery.threadId === state.threadId) {
        this.reconciled = true;
        const found = this.recovery.pendingKind === 'message' && state.messages.some((m) => m.id === this.recovery?.pendingId);
        if (found) this.recoveredMessageId = this.recovery.pendingId;
        this.status = found ? '已核实上次指令已接收；请确认核对，不会重复发送' :
          '上次提交结果未知；已同步完整快照，请核对后确认，禁止自动重发';
      }
      this.notify();
    };
    this.threadChunk = chunk;
    void rpc.request('orchestration.subscribeThread', { threadId: state.threadId }, chunk).then(() => {
      if (this.threadChunk === chunk) this.disconnect('会话订阅已结束，请重新连接');
    }).catch((error: Error) => {
      if (this.rpc === rpc && this.threadChunk === chunk) this.disconnect(error.message, true);
    });
  }

  async send(prompt: string): Promise<void> {
    const rpc = this.requireRpc();
    if (!this.thread || this.thread.cursor < 0) throw new Error('请先同步会话');
    const threadId = this.thread.threadId;
    const messageId = util.generateRandomUUID();
    const command = record(sendMessage(util.generateRandomUUID(), threadId, messageId, prompt));
    if (this.attachment && this.attachmentThread === threadId) command.attachments = [this.attachment];

    this.status = '正在提交';
    this.onUpdate();
    await this.mutate('orchestration.dispatchCommand', command, messageId, 'message');
    this.attachment = undefined;
    this.status = '指令已确认，请等待回复';
    this.onUpdate();
  }

  private subscribeShell(): void {
    const rpc = this.requireRpc();
    void rpc.request('orchestration.subscribeShell', {}, (value: Object) => {
      this.shell.apply(value);
      this.onUpdate();
    }).catch(() => { if (this.rpc === rpc) this.disconnect('项目列表同步失败，请重新连接'); });
  }

  async forget(): Promise<void> {
    this.disconnect();
    this.saved = undefined;
    this.recovery = undefined;
    this.attachment = undefined;
    if (this.recoveryStore) await this.recoveryStore.clear();
    if (this.store) await this.store.clear();
  }

  async stop(): Promise<void> {
    if (!this.thread) throw new Error('请先选择会话');
    const id = util.generateRandomUUID();
    await this.mutate('orchestration.dispatchCommand', stopCommand(id, this.thread.threadId), id, 'stop');
  }

  async respond(requestId: string, decision: string, answers: Record<string, Object>): Promise<void> {
    if (!this.thread) throw new Error('请先选择会话');
    const request = this.thread.requests.find((row: Record<string, Object>) => row.id === requestId);
    if (!request || request.status !== 'pending' || record(request.responseCapability).type === 'not_resumable') {
      throw new Error('请求已失效，请同步状态');
    }
    const command = respondCommand(util.generateRandomUUID(), this.thread.threadId, requestId, decision, answers);
    await this.mutate('orchestration.dispatchCommand', command, requestId, 'response');
  }

  async secret(itemId: string, value: string, decline: boolean): Promise<void> {
    if (!this.thread) throw new Error('请先选择会话');
    const item = this.thread.items.find((row: Record<string, Object>) => row.id === itemId);
    if (!item || item.type !== 'secret_request' || item.secretStatus !== 'pending') throw new Error('敏感输入请求已失效');
    if (!decline && !value.trim()) throw new Error('请输入敏感值');
    await this.mutate('secrets.answerRequest', secretAnswer(this.thread.threadId, itemId, value, decline), itemId, 'secret');
  }

  async upload(name: string, bytes: ArrayBuffer): Promise<void> {
    const rpc = this.requireRpc();
    if (!this.thread || !this.activeEnvironmentId() || this.recovery?.pendingId) throw new Error('请先同步会话并核对未知提交');
    const threadId = this.thread.threadId;
    const base = this.activeBase();
    // Validate local metadata before requesting an upload capability.
    uploadTarget({ relativeUrl: '/api/attachments/upload/validation.token', attachmentId: 'validation', expiresAt: Date.now() + 1000 }, bytes.byteLength, name);
    const result = await rpc.request('attachments.createUploadUrl', { type: 'file', name,
      mimeType: 'application/octet-stream', sizeBytes: bytes.byteLength });
    const target = uploadTarget(result, bytes.byteLength, name);
    const request = http.createHttp();
    try {
      if (rpc !== this.rpc || threadId !== this.thread?.threadId) throw new Error('连接已变更，请重新选择附件');
      const response = await request.request(base + target.path, { method: http.RequestMethod.POST,
        header: { 'Content-Type': 'application/octet-stream' }, extraData: bytes,
        maxRedirects: 0, usingCache: false, connectTimeout: 10000, readTimeout: 60000 });
      if (response.responseCode !== 204) throw new Error('upload rejected');
      if (rpc !== this.rpc || threadId !== this.thread?.threadId) throw new Error('connection changed');
      this.attachment = target.attachment; this.attachmentThread = threadId;
    } catch (_) { throw new Error('附件上传未确认；可重新选择或手动重试，不会自动提交消息'); }
    finally { request.destroy(); }
  }

  private async selectRecovery(threadId: string): Promise<void> {
    if (!this.activeEnvironmentId()) throw new Error('请先连接服务器');
    if (this.recovery?.pendingId && this.recovery.threadId !== threadId) throw new Error('请先核对原会话的未知提交');
    if (this.recovery?.threadId === threadId) return;
    this.attachment = undefined;
    this.recovery = { base: this.recoveryBase || this.activeBase(), environmentId: this.activeEnvironmentId(), threadId,
      pendingId: '', pendingKind: '' };
    await this.saveRecovery();
  }

  private requireRpc(): RpcClient {
    if (!this.ready || !this.rpc) throw new Error('请先连接服务器');
    return this.rpc;
  }
}

const emptyClient = new T3Client();
export let client: T3Client = emptyClient;
export function bindClient(value: T3Client | undefined): void { client = value || emptyClient; }
