import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { createRequire } from 'node:module';
const ts = createRequire(import.meta.url)((process.env.DEVECO_HOME || '/Applications/DevEco-Studio.app/Contents') +
  '/sdk/default/openharmony/ets/build-tools/ets-loader/node_modules/typescript');
const source = (await readFile(new URL('../entry/src/main/ets/services/WorkspacePrefs.ets', import.meta.url), 'utf8'))
  .replace("import { fileIo } from '@kit.CoreFileKit';", 'const fileIo = {};')
  .replace("import { BusinessError } from '@kit.BasicServicesKit';", '');
const compiled = ts.transpileModule(source, { compilerOptions: { module: ts.ModuleKind.ES2022, target: ts.ScriptTarget.ES2022 } }).outputText;
const P = await import('data:text/javascript;base64,' + Buffer.from(compiled).toString('base64'));

test('R3 preferences validate grouping, sort, filter bounds and default omitted booleans', () => {
  assert.deepEqual(P.workspacePreferences({ schemaVersion: 1, projectGroupingMode: 'repository_path',
    environmentFilter: 'a', projectFilterKey: 'repo', threadSortOrder: 'created_at', archivedSortOrder: 'oldest',
    settledShelfExpanded: false }), {
    schemaVersion: 1, projectGroupingMode: 'repository_path', environmentFilter: 'a', projectFilterKey: 'repo',
    threadSortOrder: 'created_at', archivedSortOrder: 'oldest', workingShelfEnabled: true,
    workingShelfExpanded: false, snoozedShelfExpanded: false, settledShelfExpanded: false
  });
  assert.throws(() => P.workspacePreferences({ schemaVersion: 2 }), /版本/);
  assert.throws(() => P.workspacePreferences({ schemaVersion: 1, projectGroupingMode: 'bad',
    threadSortOrder: 'updated_at', archivedSortOrder: 'newest' }), /分组/);
  assert.throws(() => P.workspacePreferences({ schemaVersion: 1, projectGroupingMode: 'repository',
    threadSortOrder: 'bad', archivedSortOrder: 'newest' }), /排序/);
});
