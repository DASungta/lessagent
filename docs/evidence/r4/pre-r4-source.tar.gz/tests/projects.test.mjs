import test from 'node:test';
import assert from 'node:assert/strict';
import { projectsUrl } from './load-projects.mjs';
const P = await import(projectsUrl);

const repo = (key, root = '/work/repo', name = 'repo') => ({
  canonicalKey: key, displayName: name, name, rootPath: root,
  locator: { source: 'git-remote', remoteName: 'origin', remoteUrl: 'https://example.test/repo.git' }
});
const project = (id, title, root, extra = {}) => ({
  id, title, workspaceRoot: root, createdAt: '2026-01-01T00:00:00.000Z',
  updatedAt: '2026-01-02T00:00:00.000Z', scripts: [], ...extra
});
const thread = (id, projectId, title, extra = {}) => ({
  id, projectId, title, createdAt: '2026-01-01T00:00:00.000Z',
  updatedAt: '2026-01-02T00:00:00.000Z', latestUserMessageAt: '2026-01-02T00:00:00.000Z',
  status: 'idle', ...extra
});
const scopedProject = (localId, value, environmentLabel = localId) =>
  ({ ...P.projectView(value), localId, environmentId: 'env-' + localId, environmentLabel, isScratch: false });
const scopedThread = (localId, value, projectLabel = 'Repo', environmentLabel = localId) =>
  ({ ...P.threadView(value), localId, environmentId: 'env-' + localId, environmentLabel, projectLabel });
const caps = (extra = {}) => ({
  settlement: true, snooze: true, pinning: true, pinReorder: true,
  activeReorder: true, autoSettleOptOut: true, titleRegeneration: true, ...extra
});

test('projects group by repository across environments, keep monorepo paths apart when asked, and archive only when every checkout is archived', () => {
  const projects = [
    scopedProject('a', project('p1', 'Repo', '/work/repo', { repositoryIdentity: repo('github:org/repo') })),
    scopedProject('b', project('p1', 'Repo', '/work/repo', { repositoryIdentity: repo('github:org/repo') })),
    scopedProject('a', project('p2', 'API', '/work/repo/api', { repositoryIdentity: repo('github:org/repo') })),
    scopedProject('a', project('p3', 'Plain', '/work/plain'))
  ];
  const grouped = P.buildProjectGroups(projects, 'repository');
  const repoGroup = grouped.find(group => group.key === 'github:org/repo');
  assert.equal(repoGroup.projects.length, 3);
  assert.deepEqual(repoGroup.projectRefs.map(ref => ref.localId), ['a', 'b', 'a']);
  const byPath = P.buildProjectGroups(projects, 'repository_path');
  assert.equal(byPath.filter(group => group.key.startsWith('github:org/repo')).length, 2);
  const separate = P.buildProjectGroups(projects, 'separate');
  assert.equal(separate.length, 4);
  const halfArchived = P.buildProjectGroups([
    scopedProject('a', project('p1', 'Repo', '/work/repo', { repositoryIdentity: repo('github:org/repo'), archivedAt: '2026-01-03T00:00:00.000Z' })),
    scopedProject('b', project('p1', 'Repo', '/work/repo', { repositoryIdentity: repo('github:org/repo') }))
  ], 'repository')[0];
  assert.equal(halfArchived.archived, false);
  assert.equal(P.pickableProjectGroups([halfArchived]).length, 1);
});

test('scratch projects group as No project and are excluded from the project picker', () => {
  const scratch = { ...scopedProject('a', project('s1', 'No project', '/work/scratch')), isScratch: true };
  const normal = scopedProject('a', project('p1', 'Repo', '/work/repo'));
  const groups = P.buildProjectGroups([scratch, normal], 'repository');
  assert.equal(groups.find(group => group.key === '\u0000no-project').label, 'No project');
  assert.deepEqual(P.pickableProjectGroups(groups).map(group => group.label), ['Repo']);
});

test('active and pinned order keys decide list order; settled and snoozed use their own clocks', () => {
  const threads = [
    scopedThread('a', thread('t1', 'p', 'One', { activeOrderKey: 'f' })),
    scopedThread('a', thread('t2', 'p', 'Two', { activeOrderKey: 'b' })),
    scopedThread('a', thread('t3', 'p', 'Three', { activeOrderKey: 'd' })),
    scopedThread('a', thread('p1', 'p', 'Pinned B', { pinnedAt: '2026-01-01T00:00:00.000Z', pinOrderKey: 'd' })),
    scopedThread('a', thread('p2', 'p', 'Pinned A', { pinnedAt: '2026-01-01T00:00:00.000Z', pinOrderKey: 'b' })),
    scopedThread('a', thread('s1', 'p', 'Settled', { settledOverride: 'settled', settledAt: '2026-01-03T00:00:00.000Z' }))
  ];
  assert.deepEqual(P.sortActive(threads.slice(0, 3)).map(t => t.id), ['t2', 't3', 't1']);
  assert.deepEqual(P.sortPinned(threads.slice(3, 5)).map(t => t.id), ['p2', 'p1']);
  assert.equal(P.sortSettled([threads[5]])[0].id, 's1');
  assert.ok(P.pinOrderKeyBetween('b', 'c') > 'b');
  assert.ok(P.pinOrderKeyBetween('b', 'c') < 'c');
  assert.equal(P.topOfPinnedRun(threads.slice(3, 5)) < 'b', true);
  const payload = P.threadMovePayload([threads[1], threads[2], threads[0]], threads[2], true, 'active');
  assert.ok(payload.orderKey < 'b');
});

test('thread shelves isolate environments and project refs, and search hits can surface a non-title match', () => {
  const now = Date.parse('2026-01-05T00:00:00.000Z');
  const a = scopedThread('a', thread('same', 'p', 'A title'));
  const b = scopedThread('b', thread('same', 'p', 'B title'));
  const snoozed = scopedThread('a', thread('sleep', 'p', 'Sleep', { snoozedUntil: '2026-01-06T00:00:00.000Z', snoozedAt: '2026-01-04T00:00:00.000Z' }));
  const settled = scopedThread('a', thread('done', 'p', 'Done', { settledOverride: 'settled', settledAt: '2026-01-03T00:00:00.000Z' }));
  const working = scopedThread('a', thread('run', 'p', 'Run', { status: 'running' }));
  const shelves = P.buildThreadShelves({
    threads: [a, b, snoozed, settled, working], environmentId: 'a', projectRefs: ['a\u0000p'],
    query: '', searchHits: {}, nowMs: now, capabilities: { a: caps(), b: caps() }, sortOrder: 'updated_at', selectedKey: ''
  });
  assert.equal(shelves.active.length, 1);
  assert.equal(shelves.active[0].id, 'same');
  assert.equal(shelves.snoozed[0].id, 'sleep');
  assert.equal(shelves.settled[0].id, 'done');
  assert.equal(shelves.working[0].id, 'run');
  const searched = P.buildThreadShelves({
    threads: [a, b], environmentId: 'b', projectRefs: [], query: 'body text',
    searchHits: { 'b:same': 'body text' }, nowMs: now,
    capabilities: { a: caps(), b: caps() }, sortOrder: 'updated_at', selectedKey: ''
  });
  assert.equal(P.flattenSearchResults(searched, 'body text')[0].localId, 'b');
});

test('search ranking puts title matches before project and content-only matches', () => {
  const now = Date.now();
  const exact = scopedThread('a', thread('exact', 'p', 'Deploy'));
  const projectMatch = scopedThread('a', thread('project', 'p', 'Other', {}), 'Deploy project');
  const content = scopedThread('a', thread('content', 'p', 'Different', {}), 'Other');
  const result = P.buildThreadShelves({
    threads: [content, projectMatch, exact], environmentId: '', projectRefs: [], query: 'deploy',
    searchHits: { 'a:content': 'deploy output' }, nowMs: now,
    capabilities: { a: caps() }, sortOrder: 'updated_at', selectedKey: ''
  });
  assert.deepEqual(result.matches.map(thread => thread.id), ['exact', 'project', 'content']);
});

test('snooze presets are local-time based, deduplicated and reject expired custom times', () => {
  const now = new Date('2026-01-05T09:00:00+08:00');
  const presets = P.resolveSnoozePresets(now, [
    { kind: 'after', minutes: 60, day: '', time: '' },
    { kind: 'after', minutes: 60, day: '', time: '' },
    { kind: 'at', minutes: 0, day: 'today', time: '08:00' },
    { kind: 'at', minutes: 0, day: 'tomorrow', time: '09:00' }
  ]);
  assert.equal(presets.length, 2);
  assert.equal(new Date(presets[0].snoozedUntil).getHours(), 10);
  assert.equal(new Date(presets[1].snoozedUntil).getDate(), 6);
  assert.equal(P.resolveCustomSnooze({ mode: 'duration', date: '', time: '', amount: '2', unit: 'hours' }, now) !== '', true);
  assert.equal(P.resolveCustomSnooze({ mode: 'date', date: '2020-01-01', time: '09:00', amount: '', unit: '' }, now), '');
  assert.equal(P.resolveCustomSnooze({ mode: 'date', date: '2026-02-30', time: '09:00', amount: '', unit: '' }, now), '');
});

test('project, thread and clone commands carry only the original fields', () => {
  assert.deepEqual(P.projectCreateCommand('c', 'p', '/work/Repo'), {
    type: 'project.create', commandId: 'c', projectId: 'p', title: 'Repo', workspaceRoot: '/work/Repo',
    createWorkspaceRootIfMissing: true, defaultModelSelection: null
  });
  assert.deepEqual(P.projectUpdateCommand('c', 'p', { title: 'New' }), { type: 'project.update', commandId: 'c', projectId: 'p', title: 'New' });
  assert.deepEqual(P.projectDeleteCommand('c', 'p'), { type: 'project.delete', commandId: 'c', projectId: 'p', force: true });
  assert.deepEqual(P.threadMetadataCommand('c', 't', 'Name'), { type: 'thread.metadata.update', commandId: 'c', threadId: 't', title: 'Name' });
  assert.deepEqual(P.threadRegenerateCommand('c', 't'), { type: 'thread.metadata.update', commandId: 'c', threadId: 't', regenerateTitle: true });
  assert.equal(P.normalizeCloneUrl('org/repo'), 'https://github.com/org/repo.git');
  assert.equal(P.cloneDirectoryName('https://github.com/org/repo.git'), 'repo');
  assert.equal(P.cloneDirectoryPath('https://github.com/org/repo.git', true), 'github.com/org/repo');
  assert.equal(P.newProjectPathPreview('/work/new/', 'My App'), '/work/new/my-app');
  assert.throws(() => P.resolveProjectPath('../repo', 'darwin'), /完整路径/);
});

test('session scope fallback and capability gating do not treat unknown as denied', () => {
  assert.equal(P.sessionAllows(undefined, 'orchestration:operate'), undefined);
  assert.equal(P.sessionAllows({ authenticated: true, scopes: ['orchestration:operate'] }, 'source-control:write'), true);
  assert.equal(P.sessionAllows({ authenticated: true, permissions: [] }, 'orchestration:operate'), false);
  assert.equal(P.sessionAllows({ authenticated: true, permissions: ['filesystem:read'] }, 'filesystem:read'), true);
  assert.equal(P.capability({ capabilities: { threadSnooze: true } }, 'threadSnooze'), true);
  assert.equal(P.capability({ capabilities: {} }, 'threadSnooze'), false);
});

test('shell parser keeps archived rows separate and ignores stale snapshots', async () => {
  const { coreUrl } = await import('./load-core.mjs');
  const { ShellState } = await import(coreUrl);
  const state = new ShellState();
  state.apply({
    kind: 'snapshot', snapshot: {
      snapshotSequence: 4,
      projects: [project('p', 'Repo', '/work/repo', { repositoryIdentity: repo('github:org/repo') })],
      threads: [thread('t', 'p', 'Active')],
      archivedThreads: [thread('a', 'p', 'Archived', { archivedAt: '2026-01-03T00:00:00.000Z' })]
    }
  });
  assert.equal(state.threads[0].label, 'Active');
  assert.equal(state.archived[0].label, 'Archived');
  state.apply({ kind: 'snapshot', snapshot: { snapshotSequence: 3, projects: [], threads: [], archivedThreads: [] } });
  assert.equal(state.threads.length, 1);
  state.apply({ kind: 'thread.updated', sequence: 5, location: 'archive', thread: thread('t', 'p', 'Archived now', { archivedAt: '2026-01-04T00:00:00.000Z' }) });
  assert.equal(state.threads.length, 0);
  assert.equal(state.archived.find(row => row.id === 't').label, 'Archived now');
});

test('archived threads group per project, filter by environment, search project or title, and sort by archive date', () => {
  const snapshot = (threads, projects) => ({ projects, threads });
  const snapshots = {
    a: snapshot([
      { id: 'same', projectId: 'p', title: 'Alpha', archivedAt: '2026-01-02T00:00:00.000Z',
        createdAt: '2026-01-01T00:00:00.000Z', updatedAt: '2026-01-02T00:00:00.000Z' },
      { id: 'older', projectId: 'p', title: 'Old', archivedAt: '2026-01-01T00:00:00.000Z',
        createdAt: '2026-01-01T00:00:00.000Z', updatedAt: '2026-01-01T00:00:00.000Z' }
    ], [project('p', 'Repo', '/work/repo', { repositoryIdentity: repo('github:org/repo') })]),
    b: snapshot([
      { id: 'same', projectId: 'p', title: 'Beta', archivedAt: '2026-01-03T00:00:00.000Z',
        createdAt: '2026-01-01T00:00:00.000Z', updatedAt: '2026-01-03T00:00:00.000Z' }
    ], [project('p', 'Repo', '/work/repo-b', { repositoryIdentity: repo('github:org/repo') })])
  };
  const groups = P.buildArchiveGroups({
    snapshots, entries: [
      { localId: 'a', environmentId: 'env-a', label: 'A' },
      { localId: 'b', environmentId: 'env-b', label: 'B' }
    ], environmentId: 'env-b', query: '', sortOrder: 'newest', scratchRoots: {}
  });
  assert.equal(groups.length, 1);assert.equal(groups[0].threads[0].environmentLabel, 'B');
  const searched = P.buildArchiveGroups({
    snapshots, entries: [
      { localId: 'a', environmentId: 'env-a', label: 'A' },
      { localId: 'b', environmentId: 'env-b', label: 'B' }
    ], environmentId: '', query: 'alpha', sortOrder: 'oldest', scratchRoots: {}
  });
  assert.equal(searched.length, 1);assert.equal(searched[0].threads.length, 1);
  assert.equal(searched[0].threads[0].label, 'Alpha');
});
